-- Tabela de usuários (perfis)
CREATE TABLE IF NOT EXISTS usuarios (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  nome TEXT NOT NULL,
  telefone TEXT,
  avatar_url TEXT,
  tipo TEXT NOT NULL CHECK (tipo IN ('cliente', 'prestador', 'admin')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de clientes (estende usuários)
CREATE TABLE IF NOT EXISTS clientes (
  id UUID PRIMARY KEY REFERENCES usuarios(id) ON DELETE CASCADE,
  cpf TEXT UNIQUE,
  data_nascimento DATE,
  endereco TEXT,
  cidade TEXT,
  estado TEXT,
  cep TEXT,
  latitude FLOAT,
  longitude FLOAT
);

-- Tabela de prestadores (estende usuários)
CREATE TABLE IF NOT EXISTS prestadores (
  id UUID PRIMARY KEY REFERENCES usuarios(id) ON DELETE CASCADE,
  cpf_cnpj TEXT UNIQUE,
  descricao TEXT,
  horario_atendimento TEXT,
  raio_atendimento INTEGER DEFAULT 20,
  endereco TEXT,
  cidade TEXT,
  estado TEXT,
  cep TEXT,
  latitude FLOAT,
  longitude FLOAT,
  plano TEXT DEFAULT 'basico' CHECK (plano IN ('basico', 'premium', 'destaque')),
  plano_expira_em TIMESTAMP WITH TIME ZONE,
  status TEXT DEFAULT 'pendente' CHECK (status IN ('pendente', 'aprovado', 'rejeitado', 'suspenso')),
  media_avaliacao FLOAT DEFAULT 0,
  total_avaliacoes INTEGER DEFAULT 0
);

-- Tabela de categorias de serviços
CREATE TABLE IF NOT EXISTS categorias (
  id SERIAL PRIMARY KEY,
  nome TEXT UNIQUE NOT NULL,
  descricao TEXT,
  icone TEXT
);

-- Tabela de serviços oferecidos pelos prestadores
CREATE TABLE IF NOT EXISTS servicos (
  id SERIAL PRIMARY KEY,
  prestador_id UUID NOT NULL REFERENCES prestadores(id) ON DELETE CASCADE,
  categoria_id INTEGER NOT NULL REFERENCES categorias(id) ON DELETE CASCADE,
  titulo TEXT NOT NULL,
  descricao TEXT,
  preco_base DECIMAL(10, 2),
  unidade_preco TEXT, -- "hora", "diária", "serviço", etc.
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(prestador_id, titulo)
);

-- Tabela de imagens de serviços
CREATE TABLE IF NOT EXISTS servico_imagens (
  id SERIAL PRIMARY KEY,
  servico_id INTEGER NOT NULL REFERENCES servicos(id) ON DELETE CASCADE,
  url TEXT NOT NULL,
  ordem INTEGER DEFAULT 0
);

-- Tabela de avaliações
CREATE TABLE IF NOT EXISTS avaliacoes (
  id SERIAL PRIMARY KEY,
  cliente_id UUID NOT NULL REFERENCES clientes(id) ON DELETE CASCADE,
  prestador_id UUID NOT NULL REFERENCES prestadores(id) ON DELETE CASCADE,
  servico_id INTEGER REFERENCES servicos(id) ON DELETE SET NULL,
  nota INTEGER NOT NULL CHECK (nota BETWEEN 1 AND 5),
  comentario TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(cliente_id, prestador_id, servico_id)
);

-- Tabela de conversas
CREATE TABLE IF NOT EXISTS conversas (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  cliente_id UUID NOT NULL REFERENCES clientes(id) ON DELETE CASCADE,
  prestador_id UUID NOT NULL REFERENCES prestadores(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(cliente_id, prestador_id)
);

-- Tabela de mensagens
CREATE TABLE IF NOT EXISTS mensagens (
  id SERIAL PRIMARY KEY,
  conversa_id UUID NOT NULL REFERENCES conversas(id) ON DELETE CASCADE,
  remetente_id UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
  destinatario_id UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
  conteudo TEXT NOT NULL,
  lida BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de orçamentos
CREATE TABLE IF NOT EXISTS orcamentos (
  id SERIAL PRIMARY KEY,
  conversa_id UUID NOT NULL REFERENCES conversas(id) ON DELETE CASCADE,
  cliente_id UUID NOT NULL REFERENCES clientes(id) ON DELETE CASCADE,
  prestador_id UUID NOT NULL REFERENCES prestadores(id) ON DELETE CASCADE,
  servico_id INTEGER REFERENCES servicos(id) ON DELETE SET NULL,
  descricao TEXT NOT NULL,
  valor DECIMAL(10, 2),
  status TEXT DEFAULT 'pendente' CHECK (status IN ('pendente', 'aceito', 'recusado', 'cancelado', 'concluido')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de pagamentos
CREATE TABLE IF NOT EXISTS pagamentos (
  id SERIAL PRIMARY KEY,
  orcamento_id INTEGER NOT NULL REFERENCES orcamentos(id) ON DELETE CASCADE,
  cliente_id UUID NOT NULL REFERENCES clientes(id) ON DELETE CASCADE,
  prestador_id UUID NOT NULL REFERENCES prestadores(id) ON DELETE CASCADE,
  valor DECIMAL(10, 2) NOT NULL,
  taxa DECIMAL(10, 2) DEFAULT 0,
  metodo TEXT NOT NULL,
  status TEXT DEFAULT 'pendente' CHECK (status IN ('pendente', 'processando', 'concluido', 'falha', 'estornado')),
  referencia TEXT UNIQUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de planos
CREATE TABLE IF NOT EXISTS planos (
  id SERIAL PRIMARY KEY,
  nome TEXT UNIQUE NOT NULL,
  descricao TEXT,
  valor_mensal DECIMAL(10, 2) NOT NULL,
  valor_anual DECIMAL(10, 2) NOT NULL,
  recursos JSONB,
  ativo BOOLEAN DEFAULT TRUE
);

-- Tabela de assinaturas
CREATE TABLE IF NOT EXISTS assinaturas (
  id SERIAL PRIMARY KEY,
  prestador_id UUID NOT NULL REFERENCES prestadores(id) ON DELETE CASCADE,
  plano_id INTEGER NOT NULL REFERENCES planos(id) ON DELETE RESTRICT,
  inicio_em TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  expira_em TIMESTAMP WITH TIME ZONE NOT NULL,
  status TEXT DEFAULT 'ativa' CHECK (status IN ('ativa', 'cancelada', 'expirada')),
  metodo_pagamento TEXT,
  referencia_pagamento TEXT,
  renovacao_automatica BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Função para atualizar a média de avaliações do prestador
CREATE OR REPLACE FUNCTION atualizar_media_avaliacao()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE prestadores
  SET 
    media_avaliacao = (
      SELECT AVG(nota)::float
      FROM avaliacoes
      WHERE prestador_id = NEW.prestador_id
    ),
    total_avaliacoes = (
      SELECT COUNT(*)
      FROM avaliacoes
      WHERE prestador_id = NEW.prestador_id
    )
  WHERE id = NEW.prestador_id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger para atualizar a média de avaliações quando uma nova avaliação é adicionada
CREATE TRIGGER trigger_atualizar_media_avaliacao
AFTER INSERT OR UPDATE ON avaliacoes
FOR EACH ROW
EXECUTE FUNCTION atualizar_media_avaliacao();

-- Função para atualizar o timestamp de updated_at
CREATE OR REPLACE FUNCTION atualizar_timestamp_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers para atualizar o timestamp de updated_at
CREATE TRIGGER trigger_atualizar_timestamp_usuarios
BEFORE UPDATE ON usuarios
FOR EACH ROW
EXECUTE FUNCTION atualizar_timestamp_updated_at();

CREATE TRIGGER trigger_atualizar_timestamp_servicos
BEFORE UPDATE ON servicos
FOR EACH ROW
EXECUTE FUNCTION atualizar_timestamp_updated_at();

CREATE TRIGGER trigger_atualizar_timestamp_conversas
BEFORE UPDATE ON conversas
FOR EACH ROW
EXECUTE FUNCTION atualizar_timestamp_updated_at();

CREATE TRIGGER trigger_atualizar_timestamp_orcamentos
BEFORE UPDATE ON orcamentos
FOR EACH ROW
EXECUTE FUNCTION atualizar_timestamp_updated_at();

CREATE TRIGGER trigger_atualizar_timestamp_pagamentos
BEFORE UPDATE ON pagamentos
FOR EACH ROW
EXECUTE FUNCTION atualizar_timestamp_updated_at();

CREATE TRIGGER trigger_atualizar_timestamp_assinaturas
BEFORE UPDATE ON assinaturas
FOR EACH ROW
EXECUTE FUNCTION atualizar_timestamp_updated_at();

-- Inserir categorias iniciais
INSERT INTO categorias (nome, descricao, icone) VALUES
('Eletricista', 'Serviços de instalação e manutenção elétrica', 'zap'),
('Encanador', 'Serviços de instalação e manutenção hidráulica', 'droplet'),
('Diarista', 'Serviços de limpeza residencial', 'home'),
('Pedreiro', 'Serviços de construção e reforma', 'tool'),
('Pintor', 'Serviços de pintura residencial e comercial', 'brush'),
('Jardineiro', 'Serviços de jardinagem e paisagismo', 'flower'),
('Técnico de TI', 'Serviços de suporte e manutenção de computadores', 'cpu'),
('Cuidador', 'Serviços de cuidados para idosos e crianças', 'heart')
ON CONFLICT (nome) DO NOTHING;

-- Inserir planos iniciais
INSERT INTO planos (nome, descricao, valor_mensal, valor_anual, recursos, ativo) VALUES
('Básico', 'Plano básico para prestadores iniciantes', 0, 0, '{"destaque": false, "max_servicos": 5, "fotos_por_servico": 3}', true),
('Premium', 'Plano intermediário com mais recursos', 49.90, 479.00, '{"destaque": false, "max_servicos": 15, "fotos_por_servico": 10, "prioridade_busca": true}', true),
('Destaque', 'Plano completo com destaque nas buscas', 99.90, 999.00, '{"destaque": true, "max_servicos": 30, "fotos_por_servico": 20, "prioridade_busca": true, "selo_verificado": true}', true)
ON CONFLICT (nome) DO NOTHING;

-- Configurar políticas de segurança (RLS)
ALTER TABLE usuarios ENABLE ROW LEVEL SECURITY;
ALTER TABLE clientes ENABLE ROW LEVEL SECURITY;
ALTER TABLE prestadores ENABLE ROW LEVEL SECURITY;
ALTER TABLE servicos ENABLE ROW LEVEL SECURITY;
ALTER TABLE servico_imagens ENABLE ROW LEVEL SECURITY;
ALTER TABLE avaliacoes ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversas ENABLE ROW LEVEL SECURITY;
ALTER TABLE mensagens ENABLE ROW LEVEL SECURITY;
ALTER TABLE orcamentos ENABLE ROW LEVEL SECURITY;
ALTER TABLE pagamentos ENABLE ROW LEVEL SECURITY;
ALTER TABLE assinaturas ENABLE ROW LEVEL SECURITY;

-- Políticas para usuários
CREATE POLICY "Usuários podem ver seus próprios dados" ON usuarios
  FOR SELECT USING (auth.uid() = id);
  
CREATE POLICY "Usuários podem atualizar seus próprios dados" ON usuarios
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Admins podem ver todos os usuários" ON usuarios
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM usuarios WHERE id = auth.uid() AND tipo = 'admin'
    )
  );

CREATE POLICY "Admins podem atualizar todos os usuários" ON usuarios
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM usuarios WHERE id = auth.uid() AND tipo = 'admin'
    )
  );

-- Políticas para prestadores (perfis públicos)
CREATE POLICY "Qualquer um pode ver prestadores aprovados" ON prestadores
  FOR SELECT USING (status = 'aprovado');

CREATE POLICY "Prestadores podem ver e atualizar seus próprios dados" ON prestadores
  FOR ALL USING (auth.uid() = id);

CREATE POLICY "Admins podem gerenciar todos os prestadores" ON prestadores
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM usuarios WHERE id = auth.uid() AND tipo = 'admin'
    )
  );

-- Políticas para serviços
CREATE POLICY "Qualquer um pode ver serviços de prestadores aprovados" ON servicos
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM prestadores WHERE id = servicos.prestador_id AND status = 'aprovado'
    )
  );

CREATE POLICY "Prestadores podem gerenciar seus próprios serviços" ON servicos
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM prestadores WHERE id = servicos.prestador_id AND id = auth.uid()
    )
  );

CREATE POLICY "Admins podem gerenciar todos os serviços" ON servicos
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM usuarios WHERE id = auth.uid() AND tipo = 'admin'
    )
  );

-- Políticas para conversas e mensagens
CREATE POLICY "Usuários podem ver suas próprias conversas" ON conversas
  FOR SELECT USING (
    cliente_id = auth.uid() OR prestador_id = auth.uid()
  );

CREATE POLICY "Usuários podem ver mensagens de suas conversas" ON mensagens
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM conversas 
      WHERE id = mensagens.conversa_id 
      AND (cliente_id = auth.uid() OR prestador_id = auth.uid())
    )
  );

CREATE POLICY "Usuários podem enviar mensagens em suas conversas" ON mensagens
  FOR INSERT WITH CHECK (
    remetente_id = auth.uid() AND
    EXISTS (
      SELECT 1 FROM conversas 
      WHERE id = mensagens.conversa_id 
      AND (cliente_id = auth.uid() OR prestador_id = auth.uid())
    )
  );

-- Função para calcular distância entre dois pontos (em km)
CREATE OR REPLACE FUNCTION calcular_distancia(lat1 float, lon1 float, lat2 float, lon2 float)
RETURNS float AS $$
DECLARE
  R float := 6371; -- Raio da Terra em km
  dLat float := radians(lat2 - lat1);
  dLon float := radians(lon2 - lon1);
  a float;
  c float;
  d float;
BEGIN
  a := sin(dLat/2) * sin(dLat/2) + cos(radians(lat1)) * cos(radians(lat2)) * sin(dLon/2) * sin(dLon/2);
  c := 2 * atan2(sqrt(a), sqrt(1-a));
  d := R * c;
  RETURN d;
END;
$$ LANGUAGE plpgsql;

-- Função para buscar prestadores próximos
CREATE OR REPLACE FUNCTION buscar_prestadores_proximos(lat float, lon float, raio_km float, categoria_id_param integer DEFAULT NULL)
RETURNS TABLE (
  id UUID,
  nome TEXT,
  avatar_url TEXT,
  descricao TEXT,
  media_avaliacao FLOAT,
  total_avaliacoes INTEGER,
  distancia FLOAT,
  plano TEXT
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id,
    u.nome,
    u.avatar_url,
    p.descricao,
    p.media_avaliacao,
    p.total_avaliacoes,
    calcular_distancia(lat, lon, p.latitude, p.longitude) as distancia,
    p.plano
  FROM prestadores p
  JOIN usuarios u ON p.id = u.id
  WHERE 
    p.status = 'aprovado' AND
    p.latitude IS NOT NULL AND
    p.longitude IS NOT NULL AND
    calcular_distancia(lat, lon, p.latitude, p.longitude) <= LEAST(raio_km, p.raio_atendimento) AND
    (categoria_id_param IS NULL OR EXISTS (
      SELECT 1 FROM servicos s 
      WHERE s.prestador_id = p.id AND s.categoria_id = categoria_id_param
    ))
  ORDER BY 
    CASE WHEN p.plano = 'destaque' THEN 0
         WHEN p.plano = 'premium' THEN 1
         ELSE 2
    END,
    p.media_avaliacao DESC,
    distancia ASC;
END;
$$ LANGUAGE plpgsql;
