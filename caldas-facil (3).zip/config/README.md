# Configuração do Caldas Fácil

Este diretório contém arquivos de configuração para o projeto Caldas Fácil.

## Arquivos

- `.env.local`: Variáveis de ambiente para desenvolvimento local
- `schema.sql`: Script SQL para criar as tabelas no Supabase

## Instruções de Configuração

1. Copie o arquivo `.env.local` para a raiz do projeto
2. Execute o script `schema.sql` no SQL Editor do Supabase
3. Configure as variáveis de ambiente necessárias

## Variáveis de Ambiente Necessárias

- `NEXT_PUBLIC_SUPABASE_URL`: URL do seu projeto Supabase
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`: Chave anônima do Supabase
- `SUPABASE_SERVICE_ROLE_KEY`: Chave de serviço do Supabase
- `NEXTAUTH_URL`: URL do seu site
- `NEXTAUTH_SECRET`: Chave secreta para criptografar sessões
- `ADMIN_EMAIL`: Email do usuário administrador
- `ADMIN_PASSWORD`: Senha do usuário administrador
- `ALLOW_INIT`: Permite a execução da rota /api/init

## Inicialização do Sistema

Após configurar as variáveis de ambiente, acesse `/api/init` para criar o usuário administrador.
