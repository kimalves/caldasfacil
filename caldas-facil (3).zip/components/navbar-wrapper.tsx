"use client"

import { useState, useEffect, useRef } from "react"
import Navbar from "./navbar"

// Este componente garante que apenas um Navbar seja renderizado na página
export function NavbarWrapper() {
  const [shouldRender, setShouldRender] = useState(true)
  const navbarCountRef = useRef(0)

  useEffect(() => {
    // Incrementa o contador de Navbar
    navbarCountRef.current += 1

    // Se este for o segundo Navbar, não renderize
    if (navbarCountRef.current > 1) {
      setShouldRender(false)
    }

    // Limpa o contador quando o componente é desmontado
    return () => {
      navbarCountRef.current -= 1
    }
  }, [])

  if (!shouldRender) {
    return null
  }

  return <Navbar />
}
