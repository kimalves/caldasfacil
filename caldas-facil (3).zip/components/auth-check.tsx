"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { supabase } from "@/lib/supabase-client"
import { useToast } from "@/hooks/use-toast"

export function AuthCheck({
  children,
  redirectTo = "/login-cliente",
  allowedRoles = ["cliente", "prestador", "admin"],
}: {
  children: React.ReactNode
  redirectTo?: string
  allowedRoles?: string[]
}) {
  const [isLoading, setIsLoading] = useState(true)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const {
          data: { session },
        } = await supabase.auth.getSession()

        if (!session) {
          router.push(redirectTo)
          return
        }

        // Verificar o tipo de usuário se allowedRoles for fornecido
        if (allowedRoles.length > 0) {
          const { data: usuario } = await supabase.from("usuarios").select("tipo").eq("id", session.user.id).single()

          if (!usuario || !allowedRoles.includes(usuario.tipo)) {
            toast({
              variant: "destructive",
              title: "Acesso negado",
              description: "Você não tem permissão para acessar esta página.",
            })
            router.push(redirectTo)
            return
          }
        }

        setIsAuthenticated(true)
      } catch (error) {
        console.error("Erro ao verificar autenticação:", error)
        router.push(redirectTo)
      } finally {
        setIsLoading(false)
      }
    }

    checkAuth()
  }, [router, redirectTo, allowedRoles, toast])

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    )
  }

  return isAuthenticated ? <>{children}</> : null
}
