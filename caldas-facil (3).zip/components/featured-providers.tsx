"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Star } from "@/components/ui/star"

type Provider = {
  id: number
  name: string
  avatar: string
  rating: number
  services: string[]
  city: string
}

const mockProviders: Provider[] = [
  {
    id: 1,
    name: "João Silva",
    avatar: "/placeholder.svg?height=100&width=100",
    rating: 4.8,
    services: ["Eletricista", "Instalação"],
    city: "Caldas Novas",
  },
  {
    id: 2,
    name: "Maria Oliveira",
    avatar: "/placeholder.svg?height=100&width=100",
    rating: 4.9,
    services: ["Diarista", "Limpeza"],
    city: "Caldas Novas",
  },
  {
    id: 3,
    name: "Carlos Santos",
    avatar: "/placeholder.svg?height=100&width=100",
    rating: 4.7,
    services: ["Encanador", "Reparos"],
    city: "Caldas Novas",
  },
  {
    id: 4,
    name: "Ana Pereira",
    avatar: "/placeholder.svg?height=100&width=100",
    rating: 5.0,
    services: ["Jardinagem", "Paisagismo"],
    city: "Caldas Novas",
  },
]

export function FeaturedProviders() {
  const [providers, setProviders] = useState<Provider[]>([])

  useEffect(() => {
    // Em um cenário real, isso seria uma chamada de API
    setProviders(mockProviders)
  }, [])

  return (
    <div>
      <h3 className="text-2xl font-semibold mb-6">Prestadores em Destaque</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {providers.map((provider) => (
          <Link key={provider.id} href={`/prestador/${provider.id}`}>
            <Card className="h-full hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex flex-col items-center">
                  <div className="relative w-20 h-20 rounded-full overflow-hidden mb-4">
                    <Image
                      src={provider.avatar || "/placeholder.svg"}
                      alt={provider.name}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <h4 className="font-semibold text-lg mb-1">{provider.name}</h4>
                  <div className="flex items-center mb-2">
                    <Star filled className="text-yellow-400 w-4 h-4" />
                    <span className="ml-1 text-sm text-gray-600">{provider.rating}</span>
                  </div>
                  <div className="text-sm text-gray-500 text-center">{provider.services.join(", ")}</div>
                  <div className="text-xs text-gray-400 mt-2">{provider.city}</div>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  )
}
