"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"
import type { Session, User } from "@supabase/supabase-js"
import { getBrowserSupabase } from "@/lib/supabase"
import type { Database } from "@/types/supabase"

type UserProfile = Database["public"]["Tables"]["usuarios"]["Row"]

type AuthContextType = {
  session: Session | null
  user: User | null
  profile: UserProfile | null
  isAuthenticated: boolean
  isLoading: boolean
  signIn: (email: string, password: string) => Promise<{ error: any | null }>
  signUp: (
    email: string,
    password: string,
    userData: Partial<UserProfile>,
  ) => Promise<{ error: any | null; user: User | null }>
  signOut: () => Promise<void>
  refreshProfile: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null)
  const [user, setUser] = useState<User | null>(null)
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const supabase = getBrowserSupabase()

  useEffect(() => {
    // Inicializa a sessão e configura o listener para mudanças de autenticação
    const initializeAuth = async () => {
      setIsLoading(true)

      try {
        // Obtém a sessão atual
        const {
          data: { session: currentSession },
        } = await supabase.auth.getSession()

        if (currentSession) {
          setSession(currentSession)
          setUser(currentSession.user)
          await fetchUserProfile(currentSession.user.id)
        }
      } catch (error) {
        console.error("Erro ao inicializar autenticação:", error)
      } finally {
        setIsLoading(false)
      }

      // Configura o listener para mudanças de autenticação
      const {
        data: { subscription },
      } = await supabase.auth.onAuthStateChange(async (event, newSession) => {
        setSession(newSession)
        setUser(newSession?.user ?? null)

        if (newSession?.user) {
          await fetchUserProfile(newSession.user.id)
        } else {
          setProfile(null)
        }
      })

      // Limpa o listener quando o componente é desmontado
      return () => {
        subscription.unsubscribe()
      }
    }

    initializeAuth()
  }, [])

  // Busca o perfil do usuário no banco de dados
  const fetchUserProfile = async (userId: string) => {
    try {
      const { data, error } = await supabase.from("usuarios").select("*").eq("id", userId).single()

      if (error) {
        throw error
      }

      setProfile(data)
    } catch (error) {
      console.error("Erro ao buscar perfil do usuário:", error)
      setProfile(null)
    }
  }

  // Função para atualizar o perfil do usuário
  const refreshProfile = async () => {
    if (user) {
      await fetchUserProfile(user.id)
    }
  }

  // Função para fazer login
  const signIn = async (email: string, password: string) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) {
        return { error }
      }

      return { error: null }
    } catch (error) {
      console.error("Erro ao fazer login:", error)
      return { error }
    }
  }

  // Função para criar uma conta
  const signUp = async (email: string, password: string, userData: Partial<UserProfile>) => {
    try {
      // Cria o usuário na autenticação
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
      })

      if (error) {
        return { error, user: null }
      }

      if (!data.user) {
        return { error: new Error("Usuário não criado"), user: null }
      }

      // Cria o perfil do usuário
      const { error: profileError } = await supabase.from("usuarios").insert([
        {
          id: data.user.id,
          email: data.user.email!,
          nome: userData.nome || "",
          tipo: userData.tipo || "cliente",
          telefone: userData.telefone || null,
        },
      ])

      if (profileError) {
        return { error: profileError, user: data.user }
      }

      // Se for um cliente, cria o registro na tabela clientes
      if (userData.tipo === "cliente") {
        await supabase.from("clientes").insert([
          {
            usuario_id: data.user.id,
          },
        ])
      }

      // Se for um prestador, cria o registro na tabela prestadores
      if (userData.tipo === "prestador") {
        await supabase.from("prestadores").insert([
          {
            usuario_id: data.user.id,
            plano: "basico",
          },
        ])
      }

      return { error: null, user: data.user }
    } catch (error) {
      console.error("Erro ao criar conta:", error)
      return { error, user: null }
    }
  }

  // Função para fazer logout
  const signOut = async () => {
    await supabase.auth.signOut()
    setProfile(null)
  }

  const value = {
    session,
    user,
    profile,
    isAuthenticated: !!user,
    isLoading,
    signIn,
    signUp,
    signOut,
    refreshProfile,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth deve ser usado dentro de um AuthProvider")
  }
  return context
}
