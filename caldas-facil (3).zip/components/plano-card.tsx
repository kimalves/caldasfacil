"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Check } from "lucide-react"

type PlanoProps = {
  id: string
  nome: string
  preco: number
  descricao: string
  recursos: string[]
  popular?: boolean
  onSelect?: (id: string) => void
}

export function PlanoCard({ id, nome, preco, descricao, recursos, popular, onSelect }: PlanoProps) {
  return (
    <Card className={`flex flex-col h-full ${popular ? "border-primary shadow-lg" : ""}`}>
      {popular && <div className="bg-primary text-white text-center py-1 text-sm font-medium">Mais Popular</div>}

      <CardHeader>
        <CardTitle>{nome}</CardTitle>
        <CardDescription>{descricao}</CardDescription>
      </CardHeader>

      <CardContent className="flex-grow">
        <div className="mb-6">
          <span className="text-3xl font-bold">
            {preco === 0 ? "Grátis" : `R$ ${preco.toFixed(2).replace(".", ",")}`}
          </span>
          {preco > 0 && <span className="text-sm text-gray-500">/mês</span>}
        </div>

        <ul className="space-y-2">
          {recursos.map((recurso, index) => (
            <li key={index} className="flex items-start">
              <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
              <span className="text-sm">{recurso}</span>
            </li>
          ))}
        </ul>
      </CardContent>

      <CardFooter>
        <Button
          onClick={() => onSelect?.(id)}
          className={`w-full ${popular ? "bg-primary hover:bg-primary-dark" : ""}`}
        >
          {preco === 0 ? "Começar Agora" : "Assinar Plano"}
        </Button>
      </CardFooter>
    </Card>
  )
}
