"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, XCircle, AlertCircle, RefreshCw } from "lucide-react"

type ConnectionStatus = "checking" | "success" | "error" | "warning"

export function ConnectionStatus() {
  const [status, setStatus] = useState<ConnectionStatus>("checking")
  const [message, setMessage] = useState<string>("Verificando conexão com o Supabase...")
  const [details, setDetails] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)

  const checkConnection = async () => {
    setIsLoading(true)
    setStatus("checking")
    setMessage("Verificando conexão com o Supabase...")

    try {
      const response = await fetch("/api/teste-conexao")
      const data = await response.json()

      if (data.success) {
        setStatus("success")
        setMessage(data.message)
        setDetails(data)
      } else {
        setStatus("error")
        setMessage(data.message)
        setDetails(data)
      }
    } catch (error) {
      setStatus("error")
      setMessage("Erro ao verificar conexão")
      setDetails({ error: String(error) })
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    checkConnection()
  }, [])

  const getStatusIcon = () => {
    switch (status) {
      case "success":
        return <CheckCircle className="h-8 w-8 text-green-500" />
      case "error":
        return <XCircle className="h-8 w-8 text-red-500" />
      case "warning":
        return <AlertCircle className="h-8 w-8 text-yellow-500" />
      case "checking":
        return <RefreshCw className={`h-8 w-8 text-blue-500 ${isLoading ? "animate-spin" : ""}`} />
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center space-x-4">
          {getStatusIcon()}
          <div>
            <CardTitle>Status da Conexão</CardTitle>
            <CardDescription>Verificação da conexão com o Supabase</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <p className="mb-4">{message}</p>

        {details && details.tables && (
          <div className="mt-4">
            <h3 className="font-semibold mb-2">Tabelas encontradas:</h3>
            <ul className="list-disc pl-5">
              {details.tables.map((table: any, index: number) => (
                <li key={index}>{table.tablename}</li>
              ))}
            </ul>
          </div>
        )}

        {details && details.error && (
          <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-md">
            <h3 className="font-semibold text-red-700 mb-1">Erro:</h3>
            <code className="text-sm text-red-600">{details.error}</code>
          </div>
        )}
      </CardContent>
      <CardFooter>
        <Button onClick={checkConnection} disabled={isLoading} className="flex items-center space-x-2">
          <RefreshCw className={`h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
          <span>Verificar novamente</span>
        </Button>
      </CardFooter>
    </Card>
  )
}
