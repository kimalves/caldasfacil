import { CheckCircle } from "lucide-react"

interface SuccessMessageProps {
  message: string
  className?: string
}

export function SuccessMessage({ message, className = "" }: SuccessMessageProps) {
  if (!message) return null

  return (
    <div className={`flex items-center gap-2 text-green-500 text-sm mt-1 ${className}`}>
      <CheckCircle className="h-4 w-4" />
      <span>{message}</span>
    </div>
  )
}
