"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export function SearchBar() {
  const router = useRouter()
  const [searchTerm, setSearchTerm] = useState("")
  const [location, setLocation] = useState("Caldas Novas")

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchTerm.trim()) {
      router.push(`/servicos?q=${encodeURIComponent(searchTerm)}&location=${encodeURIComponent(location)}`)
    }
  }

  return (
    <form onSubmit={handleSearch} className="flex flex-col md:flex-row gap-4">
      <div className="flex-grow">
        <Input
          type="text"
          placeholder="O que você precisa? Ex: Eletricista, Encanador..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full h-12"
        />
      </div>
      <div className="w-full md:w-64">
        <Input
          type="text"
          placeholder="Localização"
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          className="w-full h-12"
        />
      </div>
      <Button type="submit" className="h-12 px-6 bg-primary hover:bg-primary-dark">
        <Search className="mr-2 h-5 w-5" />
        Buscar
      </Button>
    </form>
  )
}
