"use client"

import { useState } from "react"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { formatDistanceToNow } from "date-fns"
import { ptBR } from "date-fns/locale"

export type ChatContact = {
  id: string
  name: string
  avatar?: string
  lastMessage?: string
  timestamp?: Date
  unreadCount?: number
  online?: boolean
  type: "client" | "provider" | "support"
}

type ChatListProps = {
  contacts: ChatContact[]
  activeContactId?: string
  onSelectContact: (contactId: string) => void
  className?: string
}

export function ChatList({ contacts, activeContactId, onSelectContact, className = "" }: ChatListProps) {
  const [searchTerm, setSearchTerm] = useState("")

  const filteredContacts = contacts.filter((contact) => contact.name.toLowerCase().includes(searchTerm.toLowerCase()))

  return (
    <div className={`flex flex-col h-full border rounded-lg ${className}`}>
      <div className="p-3 border-b">
        <div className="relative">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Buscar conversas..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <ScrollArea className="flex-grow">
        <div className="divide-y">
          {filteredContacts.length > 0 ? (
            filteredContacts.map((contact) => (
              <div
                key={contact.id}
                className={`p-3 cursor-pointer hover:bg-gray-50 transition-colors ${
                  activeContactId === contact.id ? "bg-gray-100" : ""
                }`}
                onClick={() => onSelectContact(contact.id)}
              >
                <div className="flex items-center">
                  <div className="relative">
                    <Avatar className="h-12 w-12 mr-3">
                      <AvatarImage src={contact.avatar || "/placeholder.svg"} alt={contact.name} />
                      <AvatarFallback>{contact.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    {contact.online && (
                      <span className="absolute bottom-0 right-3 h-3 w-3 rounded-full bg-green-500 border-2 border-white"></span>
                    )}
                  </div>
                  <div className="flex-grow min-w-0">
                    <div className="flex justify-between items-center">
                      <h3 className="font-medium truncate">{contact.name}</h3>
                      {contact.timestamp && (
                        <span className="text-xs text-gray-500">
                          {formatDistanceToNow(contact.timestamp, { addSuffix: false, locale: ptBR })}
                        </span>
                      )}
                    </div>
                    {contact.lastMessage && <p className="text-sm text-gray-500 truncate">{contact.lastMessage}</p>}
                  </div>
                  {contact.unreadCount && contact.unreadCount > 0 && (
                    <div className="ml-2 bg-primary text-white text-xs font-medium rounded-full h-5 min-w-5 flex items-center justify-center px-1.5">
                      {contact.unreadCount}
                    </div>
                  )}
                </div>
                {contact.type === "support" && (
                  <div className="mt-1">
                    <span className="text-xs bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full">Suporte</span>
                  </div>
                )}
              </div>
            ))
          ) : (
            <div className="p-4 text-center text-gray-500">Nenhuma conversa encontrada</div>
          )}
        </div>
      </ScrollArea>
    </div>
  )
}
