"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { toast } from "@/hooks/use-toast"

type OrçamentoModalProps = {
  isOpen: boolean
  onClose: () => void
  onSubmit: (data: OrçamentoData) => void
  prestadorName: string
}

export type OrçamentoData = {
  descricao: string
  endereco: string
  data: string
  valor?: string
}

export function OrçamentoModal({ isOpen, onClose, onSubmit, prestadorName }: OrçamentoModalProps) {
  const [formData, setFormData] = useState<OrçamentoData>({
    descricao: "",
    endereco: "",
    data: "",
    valor: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.descricao || !formData.endereco || !formData.data) {
      toast({
        title: "Campos obrigatórios",
        description: "Por favor, preencha todos os campos obrigatórios.",
        variant: "destructive",
      })
      return
    }

    onSubmit(formData)
    setFormData({
      descricao: "",
      endereco: "",
      data: "",
      valor: "",
    })
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Solicitar Orçamento</DialogTitle>
          <DialogDescription>Preencha os detalhes para solicitar um orçamento de {prestadorName}</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="descricao">Descrição do Serviço *</Label>
              <Textarea
                id="descricao"
                name="descricao"
                placeholder="Descreva o serviço que você precisa..."
                rows={4}
                value={formData.descricao}
                onChange={handleChange}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="endereco">Endereço *</Label>
              <Input
                id="endereco"
                name="endereco"
                placeholder="Endereço completo onde o serviço será realizado"
                value={formData.endereco}
                onChange={handleChange}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="data">Data Preferencial *</Label>
              <Input id="data" name="data" type="date" value={formData.data} onChange={handleChange} required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="valor">Valor Estimado (opcional)</Label>
              <Input
                id="valor"
                name="valor"
                placeholder="Valor estimado para o serviço"
                value={formData.valor}
                onChange={handleChange}
              />
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" className="bg-primary hover:bg-primary-dark">
              Enviar Solicitação
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
