"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { toast } from "@/hooks/use-toast"
import { Star } from "lucide-react"

type FinalizarServicoModalProps = {
  isOpen: boolean
  onClose: () => void
  onSubmit: (data: FinalizarServicoData) => void
  prestadorName: string
  servicoInfo: string
}

export type FinalizarServicoData = {
  avaliacao: number
  comentario: string
  metodoPagamento: "app" | "externo"
}

export function FinalizarServicoModal({
  isOpen,
  onClose,
  onSubmit,
  prestadorName,
  servicoInfo,
}: FinalizarServicoModalProps) {
  const [formData, setFormData] = useState<FinalizarServicoData>({
    avaliacao: 5,
    comentario: "",
    metodoPagamento: "app",
  })

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleRatingChange = (rating: number) => {
    setFormData((prev) => ({ ...prev, avaliacao: rating }))
  }

  const handlePaymentMethodChange = (value: "app" | "externo") => {
    setFormData((prev) => ({ ...prev, metodoPagamento: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (formData.avaliacao === 0) {
      toast({
        title: "Avaliação obrigatória",
        description: "Por favor, avalie o serviço prestado.",
        variant: "destructive",
      })
      return
    }

    onSubmit(formData)
    setFormData({
      avaliacao: 5,
      comentario: "",
      metodoPagamento: "app",
    })
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Finalizar Serviço</DialogTitle>
          <DialogDescription>
            Avalie o serviço prestado por {prestadorName} e escolha o método de pagamento
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="bg-gray-50 p-3 rounded-md mb-2">
              <h3 className="font-medium text-sm mb-1">Detalhes do Serviço:</h3>
              <p className="text-sm text-gray-600">{servicoInfo}</p>
            </div>

            <div className="space-y-2">
              <Label>Avaliação</Label>
              <div className="flex items-center space-x-1">
                {[1, 2, 3, 4, 5].map((rating) => (
                  <button
                    key={rating}
                    type="button"
                    className="focus:outline-none"
                    onClick={() => handleRatingChange(rating)}
                  >
                    <Star
                      className={`h-8 w-8 ${
                        rating <= formData.avaliacao ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="comentario">Comentário (máx. 140 caracteres)</Label>
              <Textarea
                id="comentario"
                name="comentario"
                placeholder="Deixe um comentário sobre o serviço..."
                rows={3}
                maxLength={140}
                value={formData.comentario}
                onChange={handleChange}
              />
              <div className="text-xs text-right text-gray-500">{formData.comentario.length}/140 caracteres</div>
            </div>

            <div className="space-y-2">
              <Label>Método de Pagamento</Label>
              <RadioGroup
                value={formData.metodoPagamento}
                onValueChange={(value) => handlePaymentMethodChange(value as "app" | "externo")}
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="app" id="app" />
                  <Label htmlFor="app" className="cursor-pointer">
                    Pagar pelo aplicativo (ganhe 5 pontos)
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="externo" id="externo" />
                  <Label htmlFor="externo" className="cursor-pointer">
                    Já paguei diretamente ao prestador
                  </Label>
                </div>
              </RadioGroup>
            </div>

            {formData.metodoPagamento === "app" && (
              <div className="bg-green-50 p-3 rounded-md">
                <p className="text-sm text-green-700">
                  <strong>Bônus:</strong> Ao pagar pelo aplicativo, você ganhará 5 pontos que poderão ser usados em
                  descontos futuros!
                </p>
              </div>
            )}

            {formData.metodoPagamento === "externo" && (
              <div className="bg-yellow-50 p-3 rounded-md">
                <p className="text-sm text-yellow-700">
                  <strong>Nota:</strong> Você não receberá pontos ao escolher pagamento externo.
                </p>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" className="bg-primary hover:bg-primary-dark">
              Finalizar e Avaliar
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
