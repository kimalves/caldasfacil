"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Send, Paperclip } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { formatDistanceToNow } from "date-fns"
import { ptBR } from "date-fns/locale"

export type Message = {
  id: string
  content: string
  sender: "user" | "other"
  timestamp: Date
  status?: "sent" | "delivered" | "read"
  attachment?: {
    type: "image" | "file"
    url: string
    name: string
  }
}

type ChatWindowProps = {
  title: string
  recipient: {
    name: string
    avatar?: string
    online?: boolean
  }
  messages: Message[]
  onSendMessage: (content: string) => void
  onAttachFile?: (file: File) => void
  className?: string
  showOrçamentoButton?: boolean
  onOrçamentoClick?: () => void
  showFinalizarButton?: boolean
  onFinalizarClick?: () => void
}

export function ChatWindow({
  title,
  recipient,
  messages,
  onSendMessage,
  onAttachFile,
  className = "",
  showOrçamentoButton = false,
  onOrçamentoClick,
  showFinalizarButton = false,
  onFinalizarClick,
}: ChatWindowProps) {
  const [newMessage, setNewMessage] = useState("")
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      onSendMessage(newMessage)
      setNewMessage("")
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleSendMessage()
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file && onAttachFile) {
      onAttachFile(file)
      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = ""
      }
    }
  }

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  return (
    <Card className={`flex flex-col h-full ${className}`}>
      <CardHeader className="px-4 py-3 border-b">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <Avatar className="h-10 w-10 mr-3">
              <AvatarImage src={recipient.avatar || "/placeholder.svg"} alt={recipient.name} />
              <AvatarFallback>{recipient.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div>
              <CardTitle className="text-base">{title}</CardTitle>
              <div className="flex items-center">
                {recipient.online ? (
                  <Badge variant="outline" className="text-xs bg-green-50 text-green-700 border-green-200">
                    <span className="h-2 w-2 rounded-full bg-green-500 mr-1"></span>
                    Online
                  </Badge>
                ) : (
                  <span className="text-xs text-gray-500">Offline</span>
                )}
              </div>
            </div>
          </div>
          {(showOrçamentoButton || showFinalizarButton) && (
            <div className="flex gap-2">
              {showOrçamentoButton && (
                <Button size="sm" variant="outline" onClick={onOrçamentoClick}>
                  Solicitar Orçamento
                </Button>
              )}
              {showFinalizarButton && (
                <Button size="sm" className="bg-primary hover:bg-primary-dark" onClick={onFinalizarClick}>
                  Finalizar Serviço
                </Button>
              )}
            </div>
          )}
        </div>
      </CardHeader>

      <ScrollArea className="flex-grow p-4">
        <div className="space-y-4">
          {messages.map((message) => (
            <div key={message.id} className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-[80%] rounded-lg p-3 ${
                  message.sender === "user"
                    ? "bg-primary text-white rounded-br-none"
                    : "bg-gray-100 text-gray-800 rounded-bl-none"
                }`}
              >
                {message.attachment && (
                  <div className="mb-2">
                    {message.attachment.type === "image" ? (
                      <div className="relative rounded-md overflow-hidden">
                        <img
                          src={message.attachment.url || "/placeholder.svg"}
                          alt="Anexo"
                          className="max-w-full h-auto max-h-60 object-contain"
                        />
                      </div>
                    ) : (
                      <div className="flex items-center p-2 bg-white bg-opacity-10 rounded">
                        <Paperclip className="h-4 w-4 mr-2" />
                        <span className="text-sm truncate">{message.attachment.name}</span>
                      </div>
                    )}
                  </div>
                )}
                <div>{message.content}</div>
                <div
                  className={`text-xs mt-1 ${
                    message.sender === "user" ? "text-primary-foreground/70" : "text-gray-500"
                  }`}
                >
                  {formatDistanceToNow(message.timestamp, { addSuffix: true, locale: ptBR })}
                </div>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>

      <CardFooter className="p-3 border-t">
        <div className="flex w-full items-center space-x-2">
          {onAttachFile && (
            <>
              <Button
                type="button"
                size="icon"
                variant="ghost"
                onClick={() => fileInputRef.current?.click()}
                className="h-9 w-9"
              >
                <Paperclip className="h-5 w-5" />
              </Button>
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                className="hidden"
                accept="image/*,.pdf,.doc,.docx"
              />
            </>
          )}
          <Input
            placeholder="Digite sua mensagem..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyDown={handleKeyPress}
            className="flex-grow"
          />
          <Button
            type="button"
            size="icon"
            onClick={handleSendMessage}
            disabled={!newMessage.trim()}
            className="h-9 w-9 bg-primary hover:bg-primary-dark"
          >
            <Send className="h-5 w-5" />
          </Button>
        </div>
      </CardFooter>
    </Card>
  )
}
