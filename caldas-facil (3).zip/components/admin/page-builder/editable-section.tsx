"use client"

import type React from "react"

import { useEditor } from "./editor-context"
import { cn } from "@/lib/utils"

interface EditableSectionProps {
  id: string
  children: React.ReactNode
  className?: string
}

export function EditableSection({ id, children, className }: EditableSectionProps) {
  const { isEditing, selectedElement, selectElement } = useEditor()

  const isSelected = selectedElement === id

  const handleClick = (e: React.MouseEvent) => {
    if (isEditing) {
      e.stopPropagation()
      selectElement(id)
    }
  }

  if (!isEditing) {
    return <div className={className}>{children}</div>
  }

  return (
    <div
      className={cn(
        className,
        "relative transition-all",
        isEditing && "cursor-move hover:outline hover:outline-2 hover:outline-blue-400",
        isSelected && "outline outline-2 outline-blue-500",
      )}
      onClick={handleClick}
      data-editable-id={id}
    >
      {isSelected && (
        <div className="absolute -top-6 left-0 bg-blue-500 text-white text-xs py-1 px-2 rounded-t-md">{id}</div>
      )}
      {children}
    </div>
  )
}
