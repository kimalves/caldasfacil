"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

type EditorMode = "view" | "edit"

interface EditorContextType {
  mode: EditorMode
  setMode: (mode: EditorMode) => void
  isEditing: boolean
  toggleEditMode: () => void
  saveLayout: () => Promise<void>
  selectedElement: string | null
  selectElement: (id: string | null) => void
  moveElement: (id: string, direction: "up" | "down" | "left" | "right") => void
}

const EditorContext = createContext<EditorContextType | undefined>(undefined)

export function EditorProvider({ children }: { children: React.ReactNode }) {
  const [mode, setMode] = useState<EditorMode>("view")
  const [selectedElement, setSelectedElement] = useState<string | null>(null)

  const isEditing = mode === "edit"

  const toggleEditMode = () => {
    setMode(mode === "view" ? "edit" : "view")
    setSelectedElement(null)
  }

  const selectElement = (id: string | null) => {
    if (mode === "edit") {
      setSelectedElement(id)
    }
  }

  const moveElement = (id: string, direction: "up" | "down" | "left" | "right") => {
    // Em uma implementação real, isso modificaria o layout no estado
    console.log(`Moving element ${id} ${direction}`)

    // Aqui você implementaria a lógica para mover o elemento no layout
    // Isso dependeria de como você está armazenando o layout
  }

  const saveLayout = async () => {
    // Em uma implementação real, isso salvaria o layout no banco de dados
    console.log("Saving layout...")

    // Simulando uma chamada de API
    await new Promise((resolve) => setTimeout(resolve, 1000))

    console.log("Layout saved!")

    // Sair do modo de edição após salvar
    setMode("view")
    setSelectedElement(null)
  }

  // Detectar tecla ESC para sair do modo de edição
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && mode === "edit") {
        setMode("view")
        setSelectedElement(null)
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [mode])

  return (
    <EditorContext.Provider
      value={{
        mode,
        setMode,
        isEditing,
        toggleEditMode,
        saveLayout,
        selectedElement,
        selectElement,
        moveElement,
      }}
    >
      {children}
    </EditorContext.Provider>
  )
}

export function useEditor() {
  const context = useContext(EditorContext)
  if (context === undefined) {
    throw new Error("useEditor must be used within an EditorProvider")
  }
  return context
}
