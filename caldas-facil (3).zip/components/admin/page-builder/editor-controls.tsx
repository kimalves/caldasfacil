"use client"

import { useEditor } from "./editor-context"
import { Button } from "@/components/ui/button"
import { Edit, Save, X, ArrowUp, ArrowDown, ArrowLeft, ArrowRight } from "lucide-react"
import { useState } from "react"
import { toast } from "@/hooks/use-toast"

export function EditorControls() {
  const { isEditing, toggleEditMode, saveLayout, selectedElement, moveElement } = useEditor()
  const [isSaving, setIsSaving] = useState(false)

  const handleSave = async () => {
    setIsSaving(true)
    try {
      await saveLayout()
      toast({
        title: "Layout salvo com sucesso!",
        description: "As alterações foram aplicadas ao site.",
      })
    } catch (error) {
      toast({
        title: "Erro ao salvar layout",
        description: "Ocorreu um erro ao salvar as alterações.",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  if (!isEditing) {
    return (
      <div className="fixed bottom-4 right-4 z-50">
        <Button onClick={toggleEditMode} className="rounded-full w-12 h-12 shadow-lg">
          <Edit className="h-5 w-5" />
        </Button>
      </div>
    )
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg z-50 p-4">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <div className="flex items-center">
          <span className="text-sm font-medium text-gray-700 mr-4">Modo de Edição</span>
          {selectedElement && (
            <div className="flex space-x-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => moveElement(selectedElement, "up")}
                className="h-8 w-8 p-0"
              >
                <ArrowUp className="h-4 w-4" />
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => moveElement(selectedElement, "down")}
                className="h-8 w-8 p-0"
              >
                <ArrowDown className="h-4 w-4" />
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => moveElement(selectedElement, "left")}
                className="h-8 w-8 p-0"
              >
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => moveElement(selectedElement, "right")}
                className="h-8 w-8 p-0"
              >
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={toggleEditMode} className="flex items-center">
            <X className="h-4 w-4 mr-2" />
            Cancelar
          </Button>
          <Button onClick={handleSave} disabled={isSaving} className="flex items-center">
            <Save className="h-4 w-4 mr-2" />
            {isSaving ? "Salvando..." : "Salvar Layout"}
          </Button>
        </div>
      </div>
    </div>
  )
}
