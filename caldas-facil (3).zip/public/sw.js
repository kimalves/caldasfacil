// Service Worker para notificações push
self.addEventListener("push", (event) => {
  if (event.data) {
    const data = event.data.json()
    const options = data.notification

    event.waitUntil(
      self.registration.showNotification(options.title, {
        body: options.body,
        icon: options.icon,
        data: options.data,
      }),
    )
  }
})

self.addEventListener("notificationclick", (event) => {
  event.notification.close()

  if (event.notification.data && event.notification.data.url) {
    event.waitUntil(clients.openWindow(event.notification.data.url))
  }
})
