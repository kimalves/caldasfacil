# Guia de Configuração do Caldas Fácil

Este guia contém instruções detalhadas para configurar e inicializar o sistema Caldas Fácil.

## 1. Configuração do Supabase

### 1.1. Criar Projeto no Supabase

1. Acesse [supabase.com](https://supabase.com/) e faça login
2. Crie um novo projeto
3. Anote a URL e a chave anônima do projeto (encontradas em Configurações > API)
4. Anote também a chave de serviço (service_role key)

### 1.2. Executar Script SQL

1. No painel do Supabase, vá para "SQL Editor"
2. Crie um novo query
3. Cole o conteúdo do arquivo `supabase/schema.sql`
4. Execute o script

## 2. Configuração das Variáveis de Ambiente

Crie um arquivo `.env.local` na raiz do projeto com as seguintes variáveis:

\`\`\`
# Supabase
NEXT_PUBLIC_SUPABASE_URL=https://seu-projeto.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=sua-chave-anonima
SUPABASE_SERVICE_ROLE_KEY=sua-chave-de-servico

# Autenticação
NEXTAUTH_URL=https://caldasfacil.online
NEXTAUTH_SECRET=chave-secreta-gerada

# Admin
ADMIN_EMAIL=seu-email@exemplo.com
ADMIN_PASSWORD=senha-segura

# Inicialização
ALLOW_INIT=true
\`\`\`

### 2.1. Gerar NEXTAUTH_SECRET

Execute o seguinte comando para gerar uma chave segura:

\`\`\`bash
openssl rand -base64 32
\`\`\`

## 3. Inicialização do Sistema

1. Inicie o servidor de desenvolvimento:

\`\`\`bash
npm run dev
\`\`\`

2. Acesse `http://localhost:3000/teste-conexao` para verificar se a conexão com o Supabase está funcionando
3. Acesse `http://localhost:3000/api/init` para criar o usuário administrador
4. Após a inicialização, defina `ALLOW_INIT=false` no arquivo `.env.local`

## 4. Configurações Adicionais (Opcionais)

### 4.1. Geolocalização (Google Maps)

1. Crie um projeto no [Google Cloud Console](https://console.cloud.google.com/)
2. Ative as APIs: Maps JavaScript API, Geocoding API, Places API
3. Crie uma chave de API
4. Adicione ao `.env.local`:

\`\`\`
NEXT_PUBLIC_GOOGLE_MAPS_API_KEY=sua-chave-do-google-maps
\`\`\`

### 4.2. Notificações Push

1. Gere chaves VAPID:

\`\`\`bash
npx web-push generate-vapid-keys
\`\`\`

2. Adicione ao `.env.local`:

\`\`\`
NEXT_PUBLIC_VAPID_KEY=sua-chave-publica
PRIVATE_VAPID_KEY=sua-chave-privada
\`\`\`

### 4.3. Armazenamento de Imagens (Cloudinary)

1. Crie uma conta no [Cloudinary](https://cloudinary.com/)
2. Obtenha as credenciais no Dashboard
3. Adicione ao `.env.local`:

\`\`\`
NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME=seu-cloud-name
CLOUDINARY_API_KEY=sua-api-key
CLOUDINARY_API_SECRET=seu-api-secret
\`\`\`

## 5. Implantação em Produção

### 5.1. Vercel

1. Conecte seu repositório à Vercel
2. Configure as variáveis de ambiente
3. Implante o projeto

### 5.2. Configuração de Domínio

1. Adicione o domínio `caldasfacil.online` ao seu projeto na Vercel
2. Configure os registros DNS conforme instruções da Vercel
3. Atualize `NEXTAUTH_URL=https://caldasfacil.online` no `.env.local`

## 6. Verificação Final

1. Teste o login com o usuário administrador
2. Verifique se todas as funcionalidades estão operando corretamente
3. Crie alguns usuários de teste (clientes e prestadores)
4. Teste o fluxo completo de solicitação e resposta de orçamentos
