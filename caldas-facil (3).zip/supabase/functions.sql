-- Função para listar todas as tabelas do banco de dados
-- Útil para diagnóstico e verificação da configuração
CREATE OR REPLACE FUNCTION listar_tabelas()
RETURNS SETOF text AS $$
BEGIN
  RETURN QUERY
  SELECT table_name::text
  FROM information_schema.tables
  WHERE table_schema = 'public'
  ORDER BY table_name;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Função para verificar se o banco de dados está configurado corretamente
CREATE OR REPLACE FUNCTION verificar_configuracao()
RETURNS jsonb AS $$
DECLARE
  tabelas_necessarias text[] := ARRAY[
    'usuarios', 'clientes', 'prestadores', 'servicos', 
    'conversas', 'mensagens', 'avaliacoes', 'denuncias', 
    'pagamentos', 'notificacoes', 'notificacoes_subscriptions'
  ];
  tabela text;
  tabelas_faltando text[] := '{}';
  resultado jsonb;
BEGIN
  -- Verificar tabelas
  FOREACH tabela IN ARRAY tabelas_necessarias
  LOOP
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.tables 
      WHERE table_schema = 'public' AND table_name = tabela
    ) THEN
      tabelas_faltando := array_append(tabelas_faltando, tabela);
    END IF;
  END LOOP;
  
  -- Verificar funções
  resultado := jsonb_build_object(
    'tabelas_faltando', tabelas_faltando,
    'total_usuarios', (SELECT COUNT(*) FROM usuarios),
    'total_clientes', (SELECT COUNT(*) FROM clientes),
    'total_prestadores', (SELECT COUNT(*) FROM prestadores),
    'total_servicos', (SELECT COUNT(*) FROM servicos),
    'configuracao_completa', (array_length(tabelas_faltando, 1) IS NULL)
  );
  
  RETURN resultado;
EXCEPTION
  WHEN OTHERS THEN
    RETURN jsonb_build_object(
      'erro', SQLERRM,
      'configuracao_completa', false
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Função para inicializar dados básicos do sistema
CREATE OR REPLACE FUNCTION inicializar_dados_basicos(
  admin_email text,
  admin_senha text
)
RETURNS jsonb AS $$
DECLARE
  admin_id uuid;
  resultado jsonb;
BEGIN
  -- Verificar se já existe um admin
  IF EXISTS (SELECT 1 FROM usuarios WHERE tipo = 'admin') THEN
    RETURN jsonb_build_object(
      'sucesso', false,
      'mensagem', 'Já existe um administrador no sistema'
    );
  END IF;
  
  -- Criar usuário admin
  INSERT INTO auth.users (email, password, email_confirmed_at)
  VALUES (admin_email, admin_senha, now())
  RETURNING id INTO admin_id;
  
  -- Criar perfil admin
  INSERT INTO usuarios (id, email, nome, tipo)
  VALUES (admin_id, admin_email, 'Administrador', 'admin');
  
  RETURN jsonb_build_object(
    'sucesso', true,
    'mensagem', 'Dados básicos inicializados com sucesso',
    'admin_id', admin_id
  );
EXCEPTION
  WHEN OTHERS THEN
    RETURN jsonb_build_object(
      'sucesso', false,
      'mensagem', SQLERRM
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
