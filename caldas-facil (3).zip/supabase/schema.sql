-- Criação das tabelas principais

-- Tabela de usuários (perfis)
CREATE TABLE IF NOT EXISTS usuarios (
  id UUID PRIMARY KEY REFERENCES auth.users(id),
  email TEXT UNIQUE NOT NULL,
  nome TEXT NOT NULL,
  telefone TEXT,
  tipo TEXT NOT NULL CHECK (tipo IN ('cliente', 'prestador', 'admin')),
  avatar_url TEXT,
  data_cadastro TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  ultimo_acesso TIMESTAMP WITH TIME ZONE,
  ativo BOOLEAN DEFAULT TRUE,
  verificado BOOLEAN DEFAULT FALSE
);

-- Tabela de clientes
CREATE TABLE IF NOT EXISTS clientes (
  id UUID PRIMARY KEY REFERENCES usuarios(id),
  cpf TEXT UNIQUE,
  data_nascimento DATE,
  endereco TEXT,
  cidade TEXT,
  estado TEXT,
  cep TEXT,
  latitude FLOAT,
  longitude FLOAT
);

-- Tabela de prestadores
CREATE TABLE IF NOT EXISTS prestadores (
  id UUID PRIMARY KEY REFERENCES usuarios(id),
  cpf_cnpj TEXT UNIQUE,
  descricao TEXT,
  horario_atendimento TEXT,
  raio_atendimento INTEGER DEFAULT 20,
  endereco TEXT,
  cidade TEXT,
  estado TEXT,
  cep TEXT,
  latitude FLOAT,
  longitude FLOAT,
  plano TEXT DEFAULT 'basico' CHECK (plano IN ('basico', 'destaque', 'premium')),
  data_inicio_plano TIMESTAMP WITH TIME ZONE,
  data_fim_plano TIMESTAMP WITH TIME ZONE,
  media_avaliacao FLOAT DEFAULT 0,
  total_avaliacoes INTEGER DEFAULT 0,
  verificado BOOLEAN DEFAULT FALSE,
  destaque BOOLEAN DEFAULT FALSE
);

-- Tabela de categorias de serviços
CREATE TABLE IF NOT EXISTS categorias (
  id SERIAL PRIMARY KEY,
  nome TEXT NOT NULL UNIQUE,
  descricao TEXT,
  icone TEXT,
  ativo BOOLEAN DEFAULT TRUE
);

-- Tabela de serviços oferecidos pelos prestadores
CREATE TABLE IF NOT EXISTS servicos_prestador (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  prestador_id UUID NOT NULL REFERENCES prestadores(id),
  categoria_id INTEGER NOT NULL REFERENCES categorias(id),
  titulo TEXT NOT NULL,
  descricao TEXT,
  preco_base DECIMAL(10,2),
  unidade_preco TEXT, -- "por hora", "por serviço", etc.
  disponivel BOOLEAN DEFAULT TRUE,
  destaque BOOLEAN DEFAULT FALSE,
  data_cadastro TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(prestador_id, categoria_id, titulo)
);

-- Tabela de imagens de serviços
CREATE TABLE IF NOT EXISTS imagens_servico (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  servico_id UUID NOT NULL REFERENCES servicos_prestador(id) ON DELETE CASCADE,
  url TEXT NOT NULL,
  ordem INTEGER DEFAULT 0,
  data_upload TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de avaliações
CREATE TABLE IF NOT EXISTS avaliacoes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  cliente_id UUID NOT NULL REFERENCES clientes(id),
  prestador_id UUID NOT NULL REFERENCES prestadores(id),
  servico_id UUID REFERENCES servicos_prestador(id),
  nota INTEGER NOT NULL CHECK (nota BETWEEN 1 AND 5),
  comentario TEXT,
  data_avaliacao TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  resposta TEXT,
  data_resposta TIMESTAMP WITH TIME ZONE,
  UNIQUE(cliente_id, prestador_id, servico_id)
);

-- Tabela de conversas
CREATE TABLE IF NOT EXISTS conversas (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  cliente_id UUID NOT NULL REFERENCES clientes(id),
  prestador_id UUID NOT NULL REFERENCES prestadores(id),
  servico_id UUID REFERENCES servicos_prestador(id),
  data_inicio TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  ultima_mensagem TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  status TEXT DEFAULT 'ativa' CHECK (status IN ('ativa', 'arquivada', 'finalizada')),
  UNIQUE(cliente_id, prestador_id, servico_id)
);

-- Tabela de mensagens
CREATE TABLE IF NOT EXISTS mensagens (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversa_id UUID NOT NULL REFERENCES conversas(id) ON DELETE CASCADE,
  remetente_id UUID NOT NULL REFERENCES usuarios(id),
  destinatario_id UUID NOT NULL REFERENCES usuarios(id),
  conteudo TEXT NOT NULL,
  data_envio TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  lida BOOLEAN DEFAULT FALSE,
  data_leitura TIMESTAMP WITH TIME ZONE
);

-- Tabela de orçamentos
CREATE TABLE IF NOT EXISTS orcamentos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversa_id UUID NOT NULL REFERENCES conversas(id),
  cliente_id UUID NOT NULL REFERENCES clientes(id),
  prestador_id UUID NOT NULL REFERENCES prestadores(id),
  servico_id UUID REFERENCES servicos_prestador(id),
  descricao TEXT NOT NULL,
  valor DECIMAL(10,2) NOT NULL,
  data_orcamento TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  validade TIMESTAMP WITH TIME ZONE,
  status TEXT DEFAULT 'pendente' CHECK (status IN ('pendente', 'aceito', 'recusado', 'expirado', 'cancelado')),
  data_resposta TIMESTAMP WITH TIME ZONE
);

-- Tabela de serviços contratados
CREATE TABLE IF NOT EXISTS servicos_contratados (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  orcamento_id UUID REFERENCES orcamentos(id),
  cliente_id UUID NOT NULL REFERENCES clientes(id),
  prestador_id UUID NOT NULL REFERENCES prestadores(id),
  servico_id UUID REFERENCES servicos_prestador(id),
  data_contratacao TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  data_agendada TIMESTAMP WITH TIME ZONE,
  valor DECIMAL(10,2) NOT NULL,
  status TEXT DEFAULT 'agendado' CHECK (status IN ('agendado', 'em_andamento', 'concluido', 'cancelado')),
  observacoes TEXT,
  data_conclusao TIMESTAMP WITH TIME ZONE,
  avaliado BOOLEAN DEFAULT FALSE
);

-- Tabela de pagamentos
CREATE TABLE IF NOT EXISTS pagamentos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  servico_contratado_id UUID NOT NULL REFERENCES servicos_contratados(id),
  valor DECIMAL(10,2) NOT NULL,
  metodo TEXT NOT NULL,
  status TEXT DEFAULT 'pendente' CHECK (status IN ('pendente', 'processando', 'aprovado', 'recusado', 'estornado')),
  data_pagamento TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  data_processamento TIMESTAMP WITH TIME ZONE,
  referencia_externa TEXT,
  detalhes JSONB
);

-- Tabela de notificações
CREATE TABLE IF NOT EXISTS notificacoes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  usuario_id UUID NOT NULL REFERENCES usuarios(id),
  titulo TEXT NOT NULL,
  conteudo TEXT NOT NULL,
  tipo TEXT NOT NULL,
  lida BOOLEAN DEFAULT FALSE,
  data_envio TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  data_leitura TIMESTAMP WITH TIME ZONE,
  link TEXT,
  dados_adicionais JSONB
);

-- Tabela de planos
CREATE TABLE IF NOT EXISTS planos (
  id SERIAL PRIMARY KEY,
  nome TEXT NOT NULL UNIQUE,
  descricao TEXT,
  valor_mensal DECIMAL(10,2) NOT NULL,
  valor_trimestral DECIMAL(10,2),
  valor_anual DECIMAL(10,2),
  recursos JSONB,
  ativo BOOLEAN DEFAULT TRUE
);

-- Tabela de assinaturas
CREATE TABLE IF NOT EXISTS assinaturas (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  prestador_id UUID NOT NULL REFERENCES prestadores(id),
  plano_id INTEGER NOT NULL REFERENCES planos(id),
  data_inicio TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  data_fim TIMESTAMP WITH TIME ZONE,
  valor_pago DECIMAL(10,2) NOT NULL,
  status TEXT DEFAULT 'ativa' CHECK (status IN ('ativa', 'cancelada', 'expirada', 'pendente')),
  renovacao_automatica BOOLEAN DEFAULT TRUE,
  metodo_pagamento TEXT,
  referencia_pagamento TEXT
);

-- Tabela de cidades atendidas
CREATE TABLE IF NOT EXISTS cidades_atendidas (
  id SERIAL PRIMARY KEY,
  nome TEXT NOT NULL,
  estado TEXT NOT NULL,
  ativo BOOLEAN DEFAULT TRUE,
  latitude FLOAT,
  longitude FLOAT,
  UNIQUE(nome, estado)
);

-- Tabela de ajuda/suporte
CREATE TABLE IF NOT EXISTS tickets_suporte (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  usuario_id UUID NOT NULL REFERENCES usuarios(id),
  assunto TEXT NOT NULL,
  descricao TEXT NOT NULL,
  status TEXT DEFAULT 'aberto' CHECK (status IN ('aberto', 'em_andamento', 'resolvido', 'fechado')),
  prioridade TEXT DEFAULT 'normal' CHECK (prioridade IN ('baixa', 'normal', 'alta', 'urgente')),
  data_abertura TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  data_fechamento TIMESTAMP WITH TIME ZONE,
  responsavel_id UUID REFERENCES usuarios(id)
);

-- Tabela de respostas de tickets
CREATE TABLE IF NOT EXISTS respostas_ticket (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id UUID NOT NULL REFERENCES tickets_suporte(id) ON DELETE CASCADE,
  usuario_id UUID NOT NULL REFERENCES usuarios(id),
  conteudo TEXT NOT NULL,
  data_resposta TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  anexos JSONB
);

-- Função para atualizar a média de avaliações de um prestador
CREATE OR REPLACE FUNCTION atualizar_media_avaliacao()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE prestadores
  SET 
    media_avaliacao = (
      SELECT AVG(nota)::FLOAT
      FROM avaliacoes
      WHERE prestador_id = NEW.prestador_id
    ),
    total_avaliacoes = (
      SELECT COUNT(*)
      FROM avaliacoes
      WHERE prestador_id = NEW.prestador_id
    )
  WHERE id = NEW.prestador_id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger para atualizar a média de avaliações quando uma nova avaliação é inserida
CREATE TRIGGER trigger_atualizar_media_avaliacao
AFTER INSERT OR UPDATE ON avaliacoes
FOR EACH ROW
EXECUTE FUNCTION atualizar_media_avaliacao();

-- Função para listar tabelas (útil para diagnóstico)
CREATE OR REPLACE FUNCTION list_tables()
RETURNS TABLE (table_name text) AS $$
BEGIN
  RETURN QUERY
  SELECT tablename::text
  FROM pg_tables
  WHERE schemaname = 'public'
  ORDER BY tablename;
END;
$$ LANGUAGE plpgsql;

-- Políticas de segurança (RLS)
ALTER TABLE usuarios ENABLE ROW LEVEL SECURITY;
ALTER TABLE clientes ENABLE ROW LEVEL SECURITY;
ALTER TABLE prestadores ENABLE ROW LEVEL SECURITY;
ALTER TABLE servicos_prestador ENABLE ROW LEVEL SECURITY;
ALTER TABLE avaliacoes ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversas ENABLE ROW LEVEL SECURITY;
ALTER TABLE mensagens ENABLE ROW LEVEL SECURITY;
ALTER TABLE orcamentos ENABLE ROW LEVEL SECURITY;
ALTER TABLE servicos_contratados ENABLE ROW LEVEL SECURITY;
ALTER TABLE pagamentos ENABLE ROW LEVEL SECURITY;
ALTER TABLE notificacoes ENABLE ROW LEVEL SECURITY;

-- Política para usuários (apenas o próprio usuário e admins podem ver/editar)
CREATE POLICY usuarios_policy ON usuarios
  USING (auth.uid() = id OR EXISTS (SELECT 1 FROM usuarios WHERE id = auth.uid() AND tipo = 'admin'));

-- Política para clientes (apenas o próprio cliente e admins podem ver/editar)
CREATE POLICY clientes_policy ON clientes
  USING (auth.uid() = id OR EXISTS (SELECT 1 FROM usuarios WHERE id = auth.uid() AND tipo = 'admin'));

-- Política para prestadores (visível para todos, editável apenas pelo próprio e admins)
CREATE POLICY prestadores_select_policy ON prestadores FOR SELECT
  USING (TRUE);

CREATE POLICY prestadores_update_policy ON prestadores FOR UPDATE
  USING (auth.uid() = id OR EXISTS (SELECT 1 FROM usuarios WHERE id = auth.uid() AND tipo = 'admin'));

-- Política para serviços (visível para todos, editável apenas pelo prestador e admins)
CREATE POLICY servicos_select_policy ON servicos_prestador FOR SELECT
  USING (TRUE);

CREATE POLICY servicos_update_policy ON servicos_prestador FOR UPDATE
  USING (auth.uid() = prestador_id OR EXISTS (SELECT 1 FROM usuarios WHERE id = auth.uid() AND tipo = 'admin'));

-- Política para avaliações (visível para todos, editável apenas pelo cliente que avaliou)
CREATE POLICY avaliacoes_select_policy ON avaliacoes FOR SELECT
  USING (TRUE);

CREATE POLICY avaliacoes_update_policy ON avaliacoes FOR UPDATE
  USING (auth.uid() = cliente_id OR EXISTS (SELECT 1 FROM usuarios WHERE id = auth.uid() AND tipo = 'admin'));

-- Política para conversas (visível e editável apenas pelos participantes)
CREATE POLICY conversas_policy ON conversas
  USING (auth.uid() = cliente_id OR auth.uid() = prestador_id OR EXISTS (SELECT 1 FROM usuarios WHERE id = auth.uid() AND tipo = 'admin'));

-- Política para mensagens (visível e editável apenas pelos participantes)
CREATE POLICY mensagens_policy ON mensagens
  USING (auth.uid() = remetente_id OR auth.uid() = destinatario_id OR EXISTS (SELECT 1 FROM usuarios WHERE id = auth.uid() AND tipo = 'admin'));

-- Política para orçamentos (visível e editável apenas pelos participantes)
CREATE POLICY orcamentos_policy ON orcamentos
  USING (auth.uid() = cliente_id OR auth.uid() = prestador_id OR EXISTS (SELECT 1 FROM usuarios WHERE id = auth.uid() AND tipo = 'admin'));

-- Política para serviços contratados (visível e editável apenas pelos participantes)
CREATE POLICY servicos_contratados_policy ON servicos_contratados
  USING (auth.uid() = cliente_id OR auth.uid() = prestador_id OR EXISTS (SELECT 1 FROM usuarios WHERE id = auth.uid() AND tipo = 'admin'));

-- Política para pagamentos (visível e editável apenas pelos participantes)
CREATE POLICY pagamentos_policy ON pagamentos
  USING (EXISTS (
    SELECT 1 FROM servicos_contratados sc
    WHERE sc.id = servico_contratado_id
    AND (sc.cliente_id = auth.uid() OR sc.prestador_id = auth.uid())
  ) OR EXISTS (SELECT 1 FROM usuarios WHERE id = auth.uid() AND tipo = 'admin'));

-- Política para notificações (visível e editável apenas pelo destinatário)
CREATE POLICY notificacoes_policy ON notificacoes
  USING (auth.uid() = usuario_id OR EXISTS (SELECT 1 FROM usuarios WHERE id = auth.uid() AND tipo = 'admin'));

-- Inserir dados iniciais para categorias
INSERT INTO categorias (nome, descricao, icone, ativo)
VALUES
  ('Limpeza', 'Serviços de limpeza residencial e comercial', 'cleaning', true),
  ('Encanamento', 'Serviços de encanamento e hidráulica', 'plumbing', true),
  ('Eletricista', 'Serviços de instalação e manutenção elétrica', 'electric', true),
  ('Pintura', 'Serviços de pintura residencial e comercial', 'paint', true),
  ('Jardinagem', 'Serviços de jardinagem e paisagismo', 'garden', true),
  ('Ar Condicionado', 'Instalação e manutenção de ar condicionado', 'ac', true),
  ('Marcenaria', 'Serviços de marcenaria e carpintaria', 'carpentry', true),
  ('Pedreiro', 'Serviços de alvenaria e construção', 'bricklayer', true),
  ('Serralheria', 'Serviços de serralheria e metalurgia', 'metalwork', true),
  ('Vidraceiro', 'Serviços de instalação e reparo de vidros', 'glass', true)
ON CONFLICT (nome) DO NOTHING;

-- Inserir dados iniciais para planos
INSERT INTO planos (nome, descricao, valor_mensal, valor_trimestral, valor_anual, recursos, ativo)
VALUES
  ('Básico', 'Plano básico para prestadores de serviço', 0.00, 0.00, 0.00, '{"limite_servicos": 3, "destaque": false, "prioridade_busca": "baixa"}', true),
  ('Destaque', 'Plano com destaque para prestadores de serviço', 49.90, 134.90, 479.90, '{"limite_servicos": 10, "destaque": true, "prioridade_busca": "média"}', true),
  ('Premium', 'Plano premium para prestadores de serviço', 99.90, 269.90, 959.90, '{"limite_servicos": -1, "destaque": true, "prioridade_busca": "alta", "selo_verificado": true}', true)
ON CONFLICT (nome) DO NOTHING;

-- Inserir dados iniciais para cidades atendidas
INSERT INTO cidades_atendidas (nome, estado, ativo, latitude, longitude)
VALUES
  ('Caldas Novas', 'GO', true, -17.7414, -48.6246),
  ('Rio Quente', 'GO', true, -17.7744, -48.7725),
  ('Morrinhos', 'GO', true, -17.7334, -49.1058),
  ('Piracanjuba', 'GO', true, -17.3022, -49.0168),
  ('Goiânia', 'GO', true, -16.6864, -49.2643)
ON CONFLICT (nome, estado) DO NOTHING;
