export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      usuarios: {
        Row: {
          id: string
          email: string
          nome: string
          tipo: "cliente" | "prestador" | "admin"
          telefone: string | null
          avatar_url: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          email: string
          nome: string
          tipo: "cliente" | "prestador" | "admin"
          telefone?: string | null
          avatar_url?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string
          nome?: string
          tipo?: "cliente" | "prestador" | "admin"
          telefone?: string | null
          avatar_url?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      clientes: {
        Row: {
          id: string
          usuario_id: string
          endereco: string | null
          cidade: string | null
          estado: string | null
          cep: string | null
          latitude: number | null
          longitude: number | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          usuario_id: string
          endereco?: string | null
          cidade?: string | null
          estado?: string | null
          cep?: string | null
          latitude?: number | null
          longitude?: number | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          usuario_id?: string
          endereco?: string | null
          cidade?: string | null
          estado?: string | null
          cep?: string | null
          latitude?: number | null
          longitude?: number | null
          created_at?: string
          updated_at?: string
        }
      }
      prestadores: {
        Row: {
          id: string
          usuario_id: string
          descricao: string | null
          categoria_id: number | null
          subcategoria_id: number | null
          endereco: string | null
          cidade: string | null
          estado: string | null
          cep: string | null
          latitude: number | null
          longitude: number | null
          plano: "basico" | "destaque" | null
          plano_expira_em: string | null
          avaliacao_media: number | null
          total_avaliacoes: number | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          usuario_id: string
          descricao?: string | null
          categoria_id?: number | null
          subcategoria_id?: number | null
          endereco?: string | null
          cidade?: string | null
          estado?: string | null
          cep?: string | null
          latitude?: number | null
          longitude?: number | null
          plano?: "basico" | "destaque" | null
          plano_expira_em?: string | null
          avaliacao_media?: number | null
          total_avaliacoes?: number | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          usuario_id?: string
          descricao?: string | null
          categoria_id?: number | null
          subcategoria_id?: number | null
          endereco?: string | null
          cidade?: string | null
          estado?: string | null
          cep?: string | null
          latitude?: number | null
          longitude?: number | null
          plano?: "basico" | "destaque" | null
          plano_expira_em?: string | null
          avaliacao_media?: number | null
          total_avaliacoes?: number | null
          created_at?: string
          updated_at?: string
        }
      }
      categorias: {
        Row: {
          id: number
          nome: string
          icone: string | null
          created_at: string
        }
        Insert: {
          id?: number
          nome: string
          icone?: string | null
          created_at?: string
        }
        Update: {
          id?: number
          nome?: string
          icone?: string | null
          created_at?: string
        }
      }
      subcategorias: {
        Row: {
          id: number
          categoria_id: number
          nome: string
          created_at: string
        }
        Insert: {
          id?: number
          categoria_id: number
          nome: string
          created_at?: string
        }
        Update: {
          id?: number
          categoria_id?: number
          nome?: string
          created_at?: string
        }
      }
      mensagens: {
        Row: {
          id: string
          remetente_id: string
          destinatario_id: string
          conteudo: string
          lida: boolean
          created_at: string
        }
        Insert: {
          id?: string
          remetente_id: string
          destinatario_id: string
          conteudo: string
          lida?: boolean
          created_at?: string
        }
        Update: {
          id?: string
          remetente_id?: string
          destinatario_id?: string
          conteudo?: string
          lida?: boolean
          created_at?: string
        }
      }
      orcamentos: {
        Row: {
          id: string
          cliente_id: string
          prestador_id: string
          servico: string
          descricao: string
          valor: number | null
          status: "pendente" | "aceito" | "recusado" | "concluido"
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          cliente_id: string
          prestador_id: string
          servico: string
          descricao: string
          valor?: number | null
          status?: "pendente" | "aceito" | "recusado" | "concluido"
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          cliente_id?: string
          prestador_id?: string
          servico?: string
          descricao?: string
          valor?: number | null
          status?: "pendente" | "aceito" | "recusado" | "concluido"
          created_at?: string
          updated_at?: string
        }
      }
      avaliacoes: {
        Row: {
          id: string
          cliente_id: string
          prestador_id: string
          orcamento_id: string | null
          nota: number
          comentario: string | null
          created_at: string
        }
        Insert: {
          id?: string
          cliente_id: string
          prestador_id: string
          orcamento_id?: string | null
          nota: number
          comentario?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          cliente_id?: string
          prestador_id?: string
          orcamento_id?: string | null
          nota?: number
          comentario?: string | null
          created_at?: string
        }
      }
      pagamentos: {
        Row: {
          id: string
          orcamento_id: string | null
          usuario_id: string
          tipo: "orcamento" | "plano"
          valor: number
          status: "pendente" | "pago" | "cancelado"
          metodo: "pix" | "cartao" | "picpay" | null
          referencia_externa: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          orcamento_id?: string | null
          usuario_id: string
          tipo: "orcamento" | "plano"
          valor: number
          status?: "pendente" | "pago" | "cancelado"
          metodo?: "pix" | "cartao" | "picpay" | null
          referencia_externa?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          orcamento_id?: string | null
          usuario_id?: string
          tipo?: "orcamento" | "plano"
          valor?: number
          status?: "pendente" | "pago" | "cancelado"
          metodo?: "pix" | "cartao" | "picpay" | null
          referencia_externa?: string | null
          created_at?: string
          updated_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      listar_tabelas: {
        Args: Record<PropertyKey, never>
        Returns: string[]
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}
