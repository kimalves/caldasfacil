import { createClient } from "@supabase/supabase-js"

export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      usuarios: {
        Row: {
          id: string
          email: string
          nome: string
          tipo: "cliente" | "prestador" | "admin"
          telefone: string | null
        }
        Insert: {
          id: string
          email: string
          nome: string
          tipo: "cliente" | "prestador" | "admin"
          telefone?: string | null
        }
        Update: {
          id?: string
          email?: string
          nome?: string
          tipo?: "cliente" | "prestador" | "admin"
          telefone?: string | null
        }
      }
      clientes: {
        Row: {
          id: string
          usuario_id: string
        }
        Insert: {
          id?: string
          usuario_id: string
        }
        Update: {
          id?: string
          usuario_id?: string
        }
      }
      prestadores: {
        Row: {
          id: string
          usuario_id: string
          empresa: string
          servico: string
          descricao: string | null
          documento: string
          tipo_documento: string
          plano: string
          avaliacao: number
          total_avaliacoes: number
          verificado: boolean
          status: string
          is_premium: boolean
          is_top_rated: boolean
        }
        Insert: {
          id?: string
          usuario_id: string
          empresa: string
          servico: string
          descricao?: string | null
          documento: string
          tipo_documento: string
          plano: string
          avaliacao: number
          total_avaliacoes: number
          verificado: boolean
          status: string
          is_premium: boolean
          is_top_rated: boolean
        }
        Update: {
          id?: string
          usuario_id?: string
          empresa?: string
          servico?: string
          descricao?: string | null
          documento?: string
          tipo_documento?: string
          plano?: string
          avaliacao?: number
          total_avaliacoes?: number
          verificado?: boolean
          status?: string
          is_premium?: boolean
          is_top_rated?: boolean
        }
      }
      servicos: {
        Row: {
          id: string
          cliente_id: string
          prestador_id: string
          titulo: string
          descricao: string
          endereco: string
          data: string
          valor: number | null
          status: string
        }
        Insert: {
          id?: string
          cliente_id: string
          prestador_id: string
          titulo: string
          descricao: string
          endereco: string
          data: string
          valor: number | null
          status: string
        }
        Update: {
          id?: string
          cliente_id?: string
          prestador_id?: string
          titulo?: string
          descricao?: string
          endereco?: string
          data?: string
          valor?: number | null
          status?: string
        }
      }
      denuncias: {
        Row: {
          id: string
          denunciante_id: string
          denunciado_id: string
          tipo: string
          descricao: string
          status: string
        }
        Insert: {
          id?: string
          denunciante_id: string
          denunciado_id: string
          tipo: string
          descricao: string
          status: string
        }
        Update: {
          id?: string
          denunciante_id?: string
          denunciado_id?: string
          tipo?: string
          descricao?: string
          status?: string
        }
      }
      pagamentos: {
        Row: {
          id: string
          servico_id: string
          valor: number
          desconto_pontos: number | null
          valor_final: number
          metodo: string
          status: string
        }
        Insert: {
          id?: string
          servico_id: string
          valor: number
          desconto_pontos: number | null
          valor_final: number
          metodo: string
          status: string
        }
        Update: {
          id?: string
          servico_id?: string
          valor?: number
          desconto_pontos?: number | null
          valor_final?: number
          metodo?: string
          status?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

export type Prestador = Database["public"]["Tables"]["prestadores"]["Row"]
export type Cliente = Database["public"]["Tables"]["clientes"]["Row"]
export type Servico = Database["public"]["Tables"]["servicos"]["Row"]
export type Denuncia = Database["public"]["Tables"]["denuncias"]["Row"]
export type Pagamento = Database["public"]["Tables"]["pagamentos"]["Row"]
export type Usuario = Database["public"]["Tables"]["usuarios"]["Row"]

// Cria uma instância do cliente Supabase para uso no cliente (browser)
export const supabase = createClient<Database>(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
)

// Cria uma instância do cliente Supabase com a chave de serviço para uso no servidor
// IMPORTANTE: Esta função só deve ser usada em código do servidor (Server Components, API Routes, etc.)
export const getServiceSupabase = () => {
  return createClient<Database>(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  })
}

// Singleton para o cliente Supabase no navegador
// Isso evita múltiplas instâncias do cliente Supabase no cliente
let browserSupabase: ReturnType<typeof createClient<Database>> | null = null

export const getBrowserSupabase = () => {
  if (browserSupabase === null) {
    browserSupabase = createClient<Database>(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    )
  }
  return browserSupabase
}
