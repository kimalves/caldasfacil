import { createClient } from "@supabase/supabase-js"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error("Supabase URL and Anon Key must be defined")
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Cria uma instância do cliente Supabase com a chave de serviço para uso no servidor
// IMPORTANTE: Esta função só deve ser usada em código do servidor (Server Components, API Routes, etc.)
export const getServiceSupabase = () => {
  const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY
  if (!supabaseServiceKey) {
    throw new Error("Supabase Service Role Key must be defined for admin operations")
  }
  return createClient(supabaseUrl, supabaseServiceKey, {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  })
}

// Singleton para o cliente Supabase no navegador
// Isso evita múltiplas instâncias do cliente Supabase no cliente
let browserSupabase

export const getBrowserSupabase = () => {
  if (!browserSupabase) {
    browserSupabase = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
    )
  }
  return browserSupabase
}

export const getSupabase = () => {
  return supabase
}
