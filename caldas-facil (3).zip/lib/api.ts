import { supabase, getServiceSupabase } from "./supabase"
import type { Prestador, Cliente, Servico, Denuncia, Pagamento } from "./supabase"

// API para prestadores
export const prestadoresApi = {
  // Buscar todos os prestadores
  getAll: async (filtros?: {
    servico?: string
    avaliacao_min?: number
    distancia_max?: number
    busca?: string
    plano?: string
    verificado?: boolean
    status?: string
  }) => {
    let query = supabase.from("prestadores").select(`
        *,
        usuarios (*)
      `)

    // Aplicar filtros
    if (filtros?.servico) {
      query = query.ilike("servico", `%${filtros.servico}%`)
    }

    if (filtros?.avaliacao_min) {
      query = query.gte("avaliacao", filtros.avaliacao_min)
    }

    if (filtros?.busca) {
      query = query.or(
        `empresa.ilike.%${filtros.busca}%,usuarios.nome.ilike.%${filtros.busca}%,servico.ilike.%${filtros.busca}%,descricao.ilike.%${filtros.busca}%`,
      )
    }

    if (filtros?.plano) {
      query = query.eq("plano", filtros.plano)
    }

    if (filtros?.verificado !== undefined) {
      query = query.eq("verificado", filtros.verificado)
    }

    if (filtros?.status) {
      query = query.eq("status", filtros.status)
    }

    const { data, error } = await query

    if (error) throw error
    return data
  },

  // Buscar prestador por ID
  getById: async (id: string) => {
    const { data, error } = await supabase
      .from("prestadores")
      .select(`
        *,
        usuarios (*),
        avaliacoes (*)
      `)
      .eq("id", id)
      .single()

    if (error) throw error
    return data
  },

  // Buscar prestadores próximos (usando geolocalização)
  getNearby: async (latitude: number, longitude: number, raio_km = 10) => {
    // Implementar busca por proximidade
    // Esta é uma implementação simplificada que pode ser melhorada com PostGIS
    const { data, error } = await supabase.rpc("prestadores_proximos", {
      lat: latitude,
      lng: longitude,
      raio: raio_km,
    })

    if (error) throw error
    return data
  },

  // Atualizar perfil de prestador
  update: async (id: string, dados: Partial<Prestador>) => {
    const { data, error } = await supabase.from("prestadores").update(dados).eq("id", id).select()

    if (error) throw error
    return data
  },

  // Adicionar foto ao prestador
  addPhoto: async (prestadorId: string, file: File) => {
    const fileExt = file.name.split(".").pop()
    const fileName = `${prestadorId}/${Date.now()}.${fileExt}`

    const { error: uploadError } = await supabase.storage.from("fotos_prestadores").upload(fileName, file)

    if (uploadError) throw uploadError

    const { data: urlData } = supabase.storage.from("fotos_prestadores").getPublicUrl(fileName)

    // Adicionar URL à tabela de fotos
    const { error: dbError } = await supabase.from("fotos_prestadores").insert({
      prestador_id: prestadorId,
      url: urlData.publicUrl,
      nome_arquivo: fileName,
    })

    if (dbError) throw dbError

    return urlData.publicUrl
  },

  // Remover foto do prestador
  removePhoto: async (fotoId: string) => {
    // Primeiro buscar a foto para obter o nome do arquivo
    const { data: foto, error: fetchError } = await supabase
      .from("fotos_prestadores")
      .select("*")
      .eq("id", fotoId)
      .single()

    if (fetchError) throw fetchError

    // Remover do storage
    const { error: storageError } = await supabase.storage.from("fotos_prestadores").remove([foto.nome_arquivo])

    if (storageError) throw storageError

    // Remover da tabela
    const { error: dbError } = await supabase.from("fotos_prestadores").delete().eq("id", fotoId)

    if (dbError) throw dbError

    return true
  },
}

// API para clientes
export const clientesApi = {
  // Buscar cliente por ID
  getById: async (id: string) => {
    const { data, error } = await supabase
      .from("clientes")
      .select(`
        *,
        usuarios (*)
      `)
      .eq("id", id)
      .single()

    if (error) throw error
    return data
  },

  // Atualizar perfil de cliente
  update: async (id: string, dados: Partial<Cliente>) => {
    const { data, error } = await supabase.from("clientes").update(dados).eq("id", id).select()

    if (error) throw error
    return data
  },

  // Adicionar pontos ao cliente
  addPoints: async (id: string, pontos: number) => {
    const { data, error } = await supabase.rpc("adicionar_pontos", {
      cliente_id: id,
      pontos_adicionar: pontos,
    })

    if (error) throw error
    return data
  },

  // Usar pontos do cliente
  usePoints: async (id: string, pontos: number) => {
    const { data, error } = await supabase.rpc("usar_pontos", {
      cliente_id: id,
      pontos_usar: pontos,
    })

    if (error) throw error
    return data
  },
}

// API para serviços
export const servicosApi = {
  // Criar novo serviço
  create: async (dados: Omit<Servico, "id" | "created_at">) => {
    const { data, error } = await supabase.from("servicos").insert(dados).select()

    if (error) throw error
    return data
  },

  // Buscar serviços do cliente
  getByCliente: async (clienteId: string) => {
    const { data, error } = await supabase
      .from("servicos")
      .select(`
        *,
        prestadores (*, usuarios (*))
      `)
      .eq("cliente_id", clienteId)
      .order("created_at", { ascending: false })

    if (error) throw error
    return data
  },

  // Buscar serviços do prestador
  getByPrestador: async (prestadorId: string) => {
    const { data, error } = await supabase
      .from("servicos")
      .select(`
        *,
        clientes (*, usuarios (*))
      `)
      .eq("prestador_id", prestadorId)
      .order("created_at", { ascending: false })

    if (error) throw error
    return data
  },

  // Atualizar status do serviço
  updateStatus: async (id: string, status: Servico["status"]) => {
    const { data, error } = await supabase.from("servicos").update({ status }).eq("id", id).select()

    if (error) throw error
    return data
  },

  // Finalizar serviço
  finalize: async (id: string, avaliacao: number, comentario?: string) => {
    // Iniciar transação para finalizar serviço e criar avaliação
    // Implementar lógica de transação

    // 1. Atualizar status do serviço
    const { data: servico, error: servicoError } = await supabase
      .from("servicos")
      .update({ status: "concluido" })
      .eq("id", id)
      .select()

    if (servicoError) throw servicoError

    // 2. Criar avaliação
    const { error: avaliacaoError } = await supabase.from("avaliacoes").insert({
      cliente_id: servico.cliente_id,
      prestador_id: servico.prestador_id,
      servico_id: id,
      avaliacao,
      comentario,
    })

    if (avaliacaoError) throw avaliacaoError

    // 3. Atualizar média de avaliações do prestador
    const { error: updateError } = await supabase.rpc("atualizar_avaliacao_prestador", {
      prestador_id: servico.prestador_id,
    })

    if (updateError) throw updateError

    return servico
  },
}

// API para mensagens
export const mensagensApi = {
  // Buscar ou criar conversa
  getOrCreateConversa: async (usuario1Id: string, usuario2Id: string) => {
    // Verificar se já existe conversa
    const { data: conversaExistente, error: searchError } = await supabase
      .from("conversas")
      .select("*")
      .or(
        `and(usuario1_id.eq.${usuario1Id},usuario2_id.eq.${usuario2Id}),and(usuario1_id.eq.${usuario2Id},usuario2_id.eq.${usuario1Id})`,
      )
      .single()

    if (!searchError && conversaExistente) {
      return conversaExistente
    }

    // Criar nova conversa
    const { data: novaConversa, error: createError } = await supabase
      .from("conversas")
      .insert({
        usuario1_id: usuario1Id,
        usuario2_id: usuario2Id,
        ultima_atualizacao: new Date().toISOString(),
      })
      .select()
      .single()

    if (createError) throw createError
    return novaConversa
  },

  // Enviar mensagem
  sendMessage: async (conversaId: string, remetenteId: string, conteudo: string, anexo?: File) => {
    let anexoUrl, anexoTipo, anexoNome

    // Upload de anexo, se houver
    if (anexo) {
      const fileExt = anexo.name.split(".").pop()
      const fileName = `${conversaId}/${Date.now()}.${fileExt}`

      const { error: uploadError } = await supabase.storage.from("anexos_mensagens").upload(fileName, anexo)

      if (uploadError) throw uploadError

      const { data: urlData } = supabase.storage.from("anexos_mensagens").getPublicUrl(fileName)

      anexoUrl = urlData.publicUrl
      anexoTipo = anexo.type
      anexoNome = anexo.name
    }

    // Inserir mensagem
    const { data: mensagem, error: messageError } = await supabase
      .from("mensagens")
      .insert({
        conversa_id: conversaId,
        remetente_id: remetenteId,
        conteudo,
        anexo_url: anexoUrl,
        anexo_tipo: anexoTipo,
        anexo_nome: anexoNome,
        lida: false,
      })
      .select()
      .single()

    if (messageError) throw messageError

    // Atualizar última mensagem da conversa
    const { error: updateError } = await supabase
      .from("conversas")
      .update({
        ultima_mensagem: conteudo,
        ultima_atualizacao: new Date().toISOString(),
      })
      .eq("id", conversaId)

    if (updateError) throw updateError

    return mensagem
  },

  // Buscar mensagens de uma conversa
  getMessages: async (conversaId: string) => {
    const { data, error } = await supabase
      .from("mensagens")
      .select("*")
      .eq("conversa_id", conversaId)
      .order("created_at", { ascending: true })

    if (error) throw error
    return data
  },

  // Marcar mensagens como lidas
  markAsRead: async (conversaId: string, usuarioId: string) => {
    const { error } = await supabase
      .from("mensagens")
      .update({ lida: true })
      .eq("conversa_id", conversaId)
      .neq("remetente_id", usuarioId)
      .eq("lida", false)

    if (error) throw error
    return true
  },

  // Buscar conversas de um usuário
  getConversas: async (usuarioId: string) => {
    const { data, error } = await supabase
      .from("conversas")
      .select(`
        *,
        usuario1:usuarios!usuario1_id (*),
        usuario2:usuarios!usuario2_id (*)
      `)
      .or(`usuario1_id.eq.${usuarioId},usuario2_id.eq.${usuarioId}`)
      .order("ultima_atualizacao", { ascending: false })

    if (error) throw error

    // Formatar dados para exibição
    return data.map((conversa) => {
      const outroUsuario = conversa.usuario1_id === usuarioId ? conversa.usuario2 : conversa.usuario1
      return {
        ...conversa,
        outroUsuario,
      }
    })
  },

  // Contar mensagens não lidas
  countUnread: async (usuarioId: string) => {
    const { data, error } = await supabase
      .from("mensagens")
      .select("id", { count: "exact" })
      .neq("remetente_id", usuarioId)
      .eq("lida", false)
      .in(
        "conversa_id",
        supabase.from("conversas").select("id").or(`usuario1_id.eq.${usuarioId},usuario2_id.eq.${usuarioId}`),
      )

    if (error) throw error
    return data.length
  },
}

// API para avaliações
export const avaliacoesApi = {
  // Buscar avaliações de um prestador
  getByPrestador: async (prestadorId: string) => {
    const { data, error } = await supabase
      .from("avaliacoes")
      .select(`
        *,
        clientes (*, usuarios (*))
      `)
      .eq("prestador_id", prestadorId)
      .order("created_at", { ascending: false })

    if (error) throw error
    return data
  },

  // Responder a uma avaliação
  responder: async (avaliacaoId: string, resposta: string) => {
    const { data, error } = await supabase.from("avaliacoes").update({ resposta }).eq("id", avaliacaoId).select()

    if (error) throw error
    return data
  },
}

// API para denúncias
export const denunciasApi = {
  // Criar denúncia
  create: async (dados: Omit<Denuncia, "id" | "created_at" | "status">) => {
    const { data, error } = await supabase
      .from("denuncias")
      .insert({
        ...dados,
        status: "pendente",
      })
      .select()

    if (error) throw error
    return data
  },

  // Buscar denúncias (admin)
  getAll: async (filtros?: { status?: string }) => {
    let query = supabase
      .from("denuncias")
      .select(`
        *,
        denunciante:usuarios!denunciante_id (*),
        denunciado:usuarios!denunciado_id (*)
      `)
      .order("created_at", { ascending: false })

    if (filtros?.status) {
      query = query.eq("status", filtros.status)
    }

    const { data, error } = await query

    if (error) throw error
    return data
  },

  // Atualizar status da denúncia (admin)
  updateStatus: async (id: string, status: Denuncia["status"]) => {
    const { data, error } = await supabase.from("denuncias").update({ status }).eq("id", id).select()

    if (error) throw error
    return data
  },
}

// API para pagamentos
export const pagamentosApi = {
  // Criar pagamento
  create: async (dados: Omit<Pagamento, "id" | "created_at" | "status">) => {
    const { data, error } = await supabase
      .from("pagamentos")
      .insert({
        ...dados,
        status: "pendente",
      })
      .select()

    if (error) throw error
    return data
  },

  // Confirmar pagamento
  confirm: async (id: string) => {
    // Iniciar transação para confirmar pagamento e adicionar pontos
    // Implementar lógica de transação

    // 1. Buscar dados do pagamento
    const { data: pagamento, error: fetchError } = await supabase
      .from("pagamentos")
      .select(`
        *,
        servicos (cliente_id)
      `)
      .eq("id", id)
      .single()

    if (fetchError) throw fetchError

    // 2. Atualizar status do pagamento
    const { error: updateError } = await supabase.from("pagamentos").update({ status: "concluido" }).eq("id", id)

    if (updateError) throw updateError

    // 3. Adicionar pontos ao cliente (5 pontos por pagamento)
    const { error: pointsError } = await supabase.rpc("adicionar_pontos", {
      cliente_id: pagamento.servicos.cliente_id,
      pontos_adicionar: 5,
    })

    if (pointsError) throw pointsError

    return true
  },

  // Buscar pagamentos por serviço
  getByServico: async (servicoId: string) => {
    const { data, error } = await supabase
      .from("pagamentos")
      .select("*")
      .eq("servico_id", servicoId)
      .order("created_at", { ascending: false })

    if (error) throw error
    return data
  },
}

// API para administração
export const adminApi = {
  // Verificar prestador
  verificarPrestador: async (id: string, verificado: boolean) => {
    const serviceSupabase = getServiceSupabase()

    const { data, error } = await serviceSupabase.from("prestadores").update({ verificado }).eq("id", id).select()

    if (error) throw error
    return data
  },

  // Atualizar status do prestador
  atualizarStatusPrestador: async (id: string, status: Prestador["status"]) => {
    const serviceSupabase = getServiceSupabase()

    const { data, error } = await serviceSupabase.from("prestadores").update({ status }).eq("id", id).select()

    if (error) throw error
    return data
  },

  // Atualizar status do cliente
  atualizarStatusCliente: async (id: string, status: Cliente["status"]) => {
    const serviceSupabase = getServiceSupabase()

    const { data, error } = await serviceSupabase.from("clientes").update({ status }).eq("id", id).select()

    if (error) throw error
    return data
  },

  // Obter estatísticas da plataforma
  getEstatisticas: async () => {
    const serviceSupabase = getServiceSupabase()

    const { data, error } = await serviceSupabase.rpc("obter_estatisticas_plataforma")

    if (error) throw error
    return data
  },
}
