import { getServiceSupabase } from "./supabase"

/**
 * Função para criar o usuário administrador inicial
 * Esta função deve ser chamada apenas uma vez, na primeira execução do sistema
 */
export async function initializeAdmin() {
  try {
    // Verificar se as variáveis de ambiente estão definidas
    const adminEmail = process.env.ADMIN_EMAIL
    const adminPassword = process.env.ADMIN_PASSWORD

    if (!adminEmail || !adminPassword) {
      console.warn("Variáveis de ambiente ADMIN_EMAIL e ADMIN_PASSWORD não definidas. Pulando criação do admin.")
      return
    }

    const serviceSupabase = getServiceSupabase()

    // Verificar se já existe um usuário admin
    const { data: existingAdmins, error: checkError } = await serviceSupabase
      .from("usuarios")
      .select("*")
      .eq("tipo", "admin")

    if (checkError) {
      console.error("Erro ao verificar admins existentes:", checkError)
      return
    }

    // Se já existir um admin, não criar outro
    if (existingAdmins && existingAdmins.length > 0) {
      console.log("Usuário admin já existe. Pulando criação.")
      return
    }

    // Criar usuário na autenticação
    const { data: authData, error: authError } = await serviceSupabase.auth.admin.createUser({
      email: adminEmail,
      password: adminPassword,
      email_confirm: true,
    })

    if (authError) {
      console.error("Erro ao criar usuário admin na autenticação:", authError)
      return
    }

    if (!authData.user) {
      console.error("Erro ao criar usuário admin: usuário não retornado")
      return
    }

    // Criar perfil do usuário admin
    const { error: profileError } = await serviceSupabase.from("usuarios").insert([
      {
        id: authData.user.id,
        email: authData.user.email,
        nome: "Administrador",
        tipo: "admin",
      },
    ])

    if (profileError) {
      console.error("Erro ao criar perfil do admin:", profileError)
      return
    }

    console.log("Usuário administrador criado com sucesso!")
  } catch (error) {
    console.error("Erro ao inicializar admin:", error)
  }
}
