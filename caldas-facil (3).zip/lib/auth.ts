import { supabase } from "./supabase"
import type { Usuario } from "./supabase"

export async function signIn(email: string, password: string) {
  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) throw error

    // Buscar dados adicionais do usuário
    const { data: usuario, error: userError } = await supabase
      .from("usuarios")
      .select("*")
      .eq("id", data.user?.id)
      .single()

    if (userError) throw userError

    return { user: data.user, profile: usuario }
  } catch (error) {
    console.error("Erro ao fazer login:", error)
    throw error
  }
}

export async function signUp(email: string, password: string, userData: Partial<Usuario>) {
  try {
    // Criar usuário na autenticação
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
    })

    if (error) throw error

    if (data.user) {
      // Criar perfil do usuário
      const { error: profileError } = await supabase.from("usuarios").insert([
        {
          id: data.user.id,
          email: data.user.email,
          nome: userData.nome,
          tipo: userData.tipo,
          telefone: userData.telefone,
        },
      ])

      if (profileError) throw profileError

      // Se for prestador, criar registro na tabela de prestadores
      if (userData.tipo === "prestador") {
        // Implementar criação de prestador
      }

      // Se for cliente, criar registro na tabela de clientes
      if (userData.tipo === "cliente") {
        // Implementar criação de cliente
      }
    }

    return data
  } catch (error) {
    console.error("Erro ao criar conta:", error)
    throw error
  }
}

export async function signOut() {
  try {
    const { error } = await supabase.auth.signOut()
    if (error) throw error
  } catch (error) {
    console.error("Erro ao fazer logout:", error)
    throw error
  }
}

export async function resetPassword(email: string) {
  try {
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/redefinir-senha`,
    })
    if (error) throw error
    return true
  } catch (error) {
    console.error("Erro ao solicitar redefinição de senha:", error)
    throw error
  }
}

export async function updatePassword(password: string) {
  try {
    const { error } = await supabase.auth.updateUser({
      password,
    })
    if (error) throw error
    return true
  } catch (error) {
    console.error("Erro ao atualizar senha:", error)
    throw error
  }
}

export async function getCurrentUser() {
  try {
    const {
      data: { session },
      error,
    } = await supabase.auth.getSession()

    if (error) throw error

    if (!session) return null

    // Buscar dados adicionais do usuário
    const { data: usuario, error: userError } = await supabase
      .from("usuarios")
      .select("*")
      .eq("id", session.user.id)
      .single()

    if (userError) throw userError

    return { user: session.user, profile: usuario }
  } catch (error) {
    console.error("Erro ao obter usuário atual:", error)
    return null
  }
}
