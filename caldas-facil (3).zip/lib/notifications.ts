// Verificar se o navegador suporta notificações
export const checkNotificationSupport = (): boolean => {
  return "Notification" in window
}

// Solicitar permissão para notificações
export const requestNotificationPermission = async (): Promise<NotificationPermission> => {
  if (!checkNotificationSupport()) {
    throw new Error("Este navegador não suporta notificações")
  }

  return await Notification.requestPermission()
}

// Enviar notificação
export const sendNotification = (title: string, options?: NotificationOptions): Notification | null => {
  if (!checkNotificationSupport()) {
    console.warn("Este navegador não suporta notificações")
    return null
  }

  if (Notification.permission !== "granted") {
    console.warn("Permissão para notificações não concedida")
    return null
  }

  return new Notification(title, options)
}

// Registrar service worker para notificações push
export const registerPushNotifications = async (): Promise<PushSubscription | null> => {
  if (!("serviceWorker" in navigator) || !("PushManager" in window)) {
    console.warn("Push notifications não são suportadas")
    return null
  }

  try {
    const registration = await navigator.serviceWorker.register("/sw.js")
    const subscription = await registration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(process.env.NEXT_PUBLIC_VAPID_KEY || ""),
    })

    // Enviar a subscription para o servidor
    await fetch("/api/notifications/register", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(subscription),
    })

    return subscription
  } catch (error) {
    console.error("Erro ao registrar para notificações push:", error)
    return null
  }
}

// Converter chave VAPID para o formato correto
const urlBase64ToUint8Array = (base64String: string): Uint8Array => {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4)
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/")

  const rawData = window.atob(base64)
  const outputArray = new Uint8Array(rawData.length)

  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i)
  }

  return outputArray
}
