// Função para obter a localização atual do usuário
export const getCurrentLocation = (): Promise<GeolocationPosition> => {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error("Geolocalização não é suportada pelo seu navegador"))
      return
    }

    navigator.geolocation.getCurrentPosition(resolve, reject, {
      enableHighAccuracy: true,
      timeout: 5000,
      maximumAge: 0,
    })
  })
}

// Calcular distância entre dois pontos (fórmula de Haversine)
export const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
  const R = 6371 // Raio da Terra em km
  const dLat = deg2rad(lat2 - lat1)
  const dLon = deg2rad(lon2 - lon1)
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
  const distance = R * c // Distância em km
  return distance
}

// Converter graus para radianos
const deg2rad = (deg: number): number => {
  return deg * (Math.PI / 180)
}

// Obter endereço a partir de coordenadas (geocodificação reversa)
export const getAddressFromCoordinates = async (latitude: number, longitude: number): Promise<string> => {
  try {
    const apiKey = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY
    const response = await fetch(
      `https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=${apiKey}`,
    )
    const data = await response.json()

    if (data.status === "OK" && data.results.length > 0) {
      return data.results[0].formatted_address
    }

    throw new Error("Não foi possível obter o endereço")
  } catch (error) {
    console.error("Erro ao obter endereço:", error)
    throw error
  }
}

// Obter coordenadas a partir de um endereço (geocodificação)
export const getCoordinatesFromAddress = async (address: string): Promise<{ latitude: number; longitude: number }> => {
  try {
    const apiKey = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY
    const encodedAddress = encodeURIComponent(address)
    const response = await fetch(
      `https://maps.googleapis.com/maps/api/geocode/json?address=${encodedAddress}&key=${apiKey}`,
    )
    const data = await response.json()

    if (data.status === "OK" && data.results.length > 0) {
      const location = data.results[0].geometry.location
      return {
        latitude: location.lat,
        longitude: location.lng,
      }
    }

    throw new Error("Não foi possível obter as coordenadas")
  } catch (error) {
    console.error("Erro ao obter coordenadas:", error)
    throw error
  }
}
