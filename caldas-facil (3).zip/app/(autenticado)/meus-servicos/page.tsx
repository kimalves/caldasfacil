"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Star } from "lucide-react"
import { supabase } from "@/lib/supabase-client"
import { useToast } from "@/hooks/use-toast"
// Remover a importação incorreta
// import { Navbar } from "@/components/navbar"

interface Service {
  id: string
  created_at: string
  title: string
  description: string
  price: number
  images: string[]
  category: string
  user_id: string
  rating: number
  rating_count: number
}

const MeusServicos = () => {
  const [services, setServices] = useState<Service[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    const fetchServices = async () => {
      setIsLoading(true)
      try {
        const { data, error } = await supabase
          .from("services")
          .select("*")
          .eq(
            "user_id",
            supabase.auth.getUser().then((res) => res.data.user?.id),
          )

        if (error) {
          console.error("Error fetching services:", error)
          toast({
            title: "Erro ao carregar serviços",
            description: "Ocorreu um erro ao buscar seus serviços. Por favor, tente novamente.",
            variant: "destructive",
          })
        }

        if (data) {
          const userIdPromise = supabase.auth.getUser().then((res) => res.data.user?.id)
          const userId = await userIdPromise
          const filteredServices = data.filter((service) => service.user_id === userId)
          setServices(filteredServices as Service[])
        }
      } catch (error) {
        console.error("Unexpected error fetching services:", error)
        toast({
          title: "Erro inesperado",
          description: "Ocorreu um erro inesperado. Por favor, tente novamente mais tarde.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchServices()
  }, [toast])

  return (
    <div className="bg-background py-8">
      <div className="caldas-container">
        <h1 className="text-3xl font-bold mb-6">Meus Serviços</h1>

        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
          </div>
        ) : (
          <>
            {services.length === 0 ? (
              <div className="text-center py-12">
                <h2 className="text-xl font-semibold mb-4">Nenhum serviço cadastrado ainda.</h2>
                <p className="text-muted-foreground mb-6">Comece a oferecer seus serviços e alcance mais clientes.</p>
                <Link href="/novo-servico">
                  <Button>Cadastrar Novo Serviço</Button>
                </Link>
              </div>
            ) : (
              <Tabs defaultValue="pendentes" className="w-full">
                <TabsList>
                  <TabsTrigger value="pendentes">Pendentes</TabsTrigger>
                  <TabsTrigger value="aprovados">Aprovados</TabsTrigger>
                  <TabsTrigger value="reprovados">Reprovados</TabsTrigger>
                </TabsList>
                <TabsContent value="pendentes">
                  <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
                    {services.map((service) => (
                      <Card key={service.id}>
                        <CardHeader>
                          <CardTitle>{service.title}</CardTitle>
                        </CardHeader>
                        <CardContent className="flex flex-col gap-2">
                          <Image
                            src={service.images[0] || "/placeholder.svg"}
                            alt={service.title}
                            width={300}
                            height={200}
                            className="rounded-md object-cover h-48 w-full"
                          />
                          <p className="text-sm text-muted-foreground">{service.description}</p>
                          <div className="flex items-center justify-between">
                            <span className="text-lg font-semibold">R$ {service.price}</span>
                            <Badge className="uppercase">Pendente</Badge>
                          </div>
                          <div className="flex items-center gap-1">
                            <Star className="h-4 w-4 text-yellow-500" />
                            <span>{service.rating.toFixed(1)}</span>
                            <span className="text-muted-foreground">({service.rating_count})</span>
                          </div>
                          <Link href={`/servico/${service.id}`}>
                            <Button variant="outline">Ver Detalhes</Button>
                          </Link>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
                <TabsContent value="aprovados">
                  <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
                    {services.map((service) => (
                      <Card key={service.id}>
                        <CardHeader>
                          <CardTitle>{service.title}</CardTitle>
                        </CardHeader>
                        <CardContent className="flex flex-col gap-2">
                          <Image
                            src={service.images[0] || "/placeholder.svg"}
                            alt={service.title}
                            width={300}
                            height={200}
                            className="rounded-md object-cover h-48 w-full"
                          />
                          <p className="text-sm text-muted-foreground">{service.description}</p>
                          <div className="flex items-center justify-between">
                            <span className="text-lg font-semibold">R$ {service.price}</span>
                            <Badge className="uppercase">Aprovado</Badge>
                          </div>
                          <div className="flex items-center gap-1">
                            <Star className="h-4 w-4 text-yellow-500" />
                            <span>{service.rating.toFixed(1)}</span>
                            <span className="text-muted-foreground">({service.rating_count})</span>
                          </div>
                          <Link href={`/servico/${service.id}`}>
                            <Button variant="outline">Ver Detalhes</Button>
                          </Link>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
                <TabsContent value="reprovados">
                  <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
                    {services.map((service) => (
                      <Card key={service.id}>
                        <CardHeader>
                          <CardTitle>{service.title}</CardTitle>
                        </CardHeader>
                        <CardContent className="flex flex-col gap-2">
                          <Image
                            src={service.images[0] || "/placeholder.svg"}
                            alt={service.title}
                            width={300}
                            height={200}
                            className="rounded-md object-cover h-48 w-full"
                          />
                          <p className="text-sm text-muted-foreground">{service.description}</p>
                          <div className="flex items-center justify-between">
                            <span className="text-lg font-semibold">R$ {service.price}</span>
                            <Badge className="uppercase">Reprovado</Badge>
                          </div>
                          <div className="flex items-center gap-1">
                            <Star className="h-4 w-4 text-yellow-500" />
                            <span>{service.rating.toFixed(1)}</span>
                            <span className="text-muted-foreground">({service.rating_count})</span>
                          </div>
                          <Link href={`/servico/${service.id}`}>
                            <Button variant="outline">Ver Detalhes</Button>
                          </Link>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            )}
          </>
        )}
      </div>
    </div>
  )
}

export default MeusServicos
