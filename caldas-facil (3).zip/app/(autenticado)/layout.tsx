import Navbar from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Providers } from "@/components/providers"
import type { ReactNode } from "react"

export default function AuthenticatedLayout({ children }: { children: ReactNode }) {
  return (
    <Providers>
      <Navbar />
      <main className="min-h-screen pt-16">{children}</main>
      <Footer />
    </Providers>
  )
}
