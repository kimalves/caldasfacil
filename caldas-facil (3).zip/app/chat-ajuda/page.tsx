"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Navbar from "@/components/navbar"
import { ChatWindow, type Message } from "@/components/chat/chat-window"
import { Button } from "@/components/ui/button"
import { ArrowLeft, HelpCircle } from "lucide-react"
import { v4 as uuidv4 } from "uuid"

// Mensagens iniciais do suporte
const initialMessages: Message[] = [
  {
    id: "welcome",
    content:
      "Olá! Bem-vindo ao Chat de Ajuda do Caldas Fácil. Como podemos ajudar você hoje? Estamos aqui para responder suas dúvidas sobre a plataforma.",
    sender: "other",
    timestamp: new Date(),
  },
]

// Respostas automáticas baseadas em palavras-chave
const autoResponses: Record<string, string> = {
  pontos:
    "O sistema de pontos funciona assim: a cada serviço contratado pelo aplicativo, você ganha 5 pontos. Cada 5 pontos equivalem a R$ 5,00 de desconto em serviços futuros. Os pontos são acumulativos até o limite de 50 reais (50 pontos). Para usar os pontos, basta selecionar a opção 'Usar Pontos' na hora de finalizar um serviço com valor mínimo de R$ 101,00.",
  planos:
    "Temos três planos para prestadores: Gratuito (básico), Básico (R$ 29,90/mês) e Premium (R$ 299,00/ano). O plano Básico permite que você apareça no topo da página de serviços, tenha perfil verificado e possa adicionar até 5 fotos. O plano Premium inclui uma página exclusiva para sua empresa, posição em destaque na página inicial, suporte prioritário e até 10 fotos.",
  "top avaliado":
    "O plano Básico Top Avaliado oferece 50% de desconto no plano Básico (R$ 14,95/mês) para prestadores que mantêm uma avaliação de 4.5 estrelas ou mais. O desconto é renovado mensalmente, desde que a avaliação seja mantida. Além disso, prestadores com 4.7 estrelas ou mais aparecem em destaque sem custo adicional.",
  pagamento:
    "Aceitamos pagamentos via PIX e PicPay. Quando o serviço é finalizado pelo aplicativo, o prestador recebe o valor quando o cliente marca o serviço como finalizado. O Caldas Fácil cobra uma taxa de 10% sobre o valor do serviço quando o pagamento é feito pela plataforma.",
  cadastro:
    "Para se cadastrar como cliente, basta clicar em 'Cliente' no menu superior e depois em 'Cadastre-se'. Para prestadores, clique em 'Prestador' e depois em 'Cadastre-se'. Você precisará fornecer algumas informações básicas como nome, e-mail e senha. Prestadores também precisam informar o tipo de serviço prestado e documentos como CPF ou CNPJ.",
  avaliação:
    "O sistema de avaliação permite que clientes avaliem os prestadores de serviços com 1 a 5 estrelas e deixem comentários de até 140 caracteres. Os prestadores podem responder aos comentários também com até 140 caracteres. As avaliações são importantes para manter a qualidade dos serviços e para que outros clientes possam escolher os melhores prestadores.",
  contato:
    "Você pode entrar em contato conosco pelo e-mail contato@caldasfacil.shop ou pelo telefone (XX) XXXX-XXXX. Também estamos disponíveis neste chat de ajuda durante o horário comercial.",
}

export default function ChatAjuda() {
  const router = useRouter()
  const [messages, setMessages] = useState<Message[]>(initialMessages)
  const [isTyping, setIsTyping] = useState(false)

  const handleSendMessage = (content: string) => {
    // Adicionar mensagem do usuário
    const userMessage: Message = {
      id: uuidv4(),
      content,
      sender: "user",
      timestamp: new Date(),
      status: "sent",
    }

    setMessages((prev) => [...prev, userMessage])

    // Simular digitação
    setIsTyping(true)

    // Verificar se há resposta automática para palavras-chave
    setTimeout(
      () => {
        setIsTyping(false)

        let responseContent = ""
        const contentLower = content.toLowerCase()

        // Verificar palavras-chave
        for (const [keyword, response] of Object.entries(autoResponses)) {
          if (contentLower.includes(keyword.toLowerCase())) {
            responseContent = response
            break
          }
        }

        // Se não encontrou resposta específica, usar resposta genérica
        if (!responseContent) {
          const genericResponses = [
            "Obrigado pela sua mensagem. Vou verificar essa informação e retorno em breve.",
            "Entendi sua dúvida. Deixe-me consultar nossa base de conhecimento para te ajudar melhor.",
            "Agradeço seu contato. Estamos trabalhando para resolver sua questão o mais rápido possível.",
            "Compreendo sua pergunta. Vou encaminhar para nossa equipe especializada e logo retornaremos.",
          ]
          responseContent = genericResponses[Math.floor(Math.random() * genericResponses.length)]
        }

        const botResponse: Message = {
          id: uuidv4(),
          content: responseContent,
          sender: "other",
          timestamp: new Date(),
        }

        setMessages((prev) => [...prev, botResponse])
      },
      1000 + Math.random() * 2000,
    )
  }

  // Efeito para simular mensagem de acompanhamento após 10 segundos
  useEffect(() => {
    const timer = setTimeout(() => {
      if (messages.length === 1) {
        const followUpMessage: Message = {
          id: uuidv4(),
          content:
            "Você pode perguntar sobre o sistema de pontos, planos para prestadores, pagamentos, cadastro, avaliações ou qualquer outra dúvida que tenha sobre a plataforma.",
          sender: "other",
          timestamp: new Date(),
        }
        setMessages((prev) => [...prev, followUpMessage])
      }
    }, 10000)

    return () => clearTimeout(timer)
  }, [messages])

  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />

      <div className="flex-grow bg-background py-8">
        <div className="caldas-container max-w-4xl">
          <div className="flex items-center mb-6">
            <Button variant="ghost" onClick={() => router.back()} className="mr-2">
              <ArrowLeft className="h-5 w-5 mr-1" />
              Voltar
            </Button>
            <h1 className="text-2xl font-bold flex items-center">
              <HelpCircle className="h-6 w-6 mr-2 text-primary" />
              Chat de Ajuda
            </h1>
          </div>

          <div className="h-[calc(100vh-200px)]">
            <ChatWindow
              title="Suporte Caldas Fácil"
              recipient={{
                name: "Suporte",
                avatar: "/placeholder.svg?height=40&width=40",
                online: true,
              }}
              messages={messages}
              onSendMessage={handleSendMessage}
            />
          </div>

          <div className="mt-6 bg-white p-4 rounded-lg border">
            <h2 className="text-lg font-semibold mb-2">Perguntas Frequentes</h2>
            <div className="space-y-3">
              <div>
                <h3 className="font-medium">Como funciona o sistema de pontos?</h3>
                <p className="text-sm text-gray-600">
                  A cada serviço contratado pelo aplicativo, você ganha 5 pontos. Cada 5 pontos equivalem a R$ 5,00 de
                  desconto em serviços futuros.
                </p>
              </div>
              <div>
                <h3 className="font-medium">Quais são os planos disponíveis para prestadores?</h3>
                <p className="text-sm text-gray-600">
                  Temos três planos: Gratuito, Básico (R$ 29,90/mês) e Premium (R$ 299,00/ano).
                </p>
              </div>
              <div>
                <h3 className="font-medium">Como funciona o pagamento na plataforma?</h3>
                <p className="text-sm text-gray-600">
                  Aceitamos pagamentos via PIX e PicPay. O prestador recebe quando o cliente marca o serviço como
                  finalizado.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
