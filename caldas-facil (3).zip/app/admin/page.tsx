"use client"

import { useState } from "react"
import Navbar from "@/components/navbar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Users,
  Settings,
  MessageSquare,
  Flag,
  MoreVertical,
  CheckCircle,
  XCircle,
  Eye,
  Edit,
  Trash,
  Search,
  Star,
} from "lucide-react"
import { toast } from "@/hooks/use-toast"

// Dados simulados
const prestadoresData = [
  {
    id: "1",
    nome: "João Silva",
    empresa: "Silva Jardinagem",
    servico: "Paisagismo e Jardinagem",
    email: "joao@silvajardinagem.com.br",
    plano: "Premium",
    avaliacao: 4.8,
    status: "ativo",
    verificado: true,
    dataCadastro: "10/01/2025",
  },
  {
    id: "2",
    nome: "Maria Oliveira",
    empresa: "Transportes Rápidos",
    servico: "Transporte de Pessoas e Móveis",
    email: "maria@transportesrapidos.com.br",
    plano: "Básico",
    avaliacao: 4.7,
    status: "ativo",
    verificado: true,
    dataCadastro: "15/01/2025",
  },
  {
    id: "3",
    nome: "Carlos Santos",
    empresa: "TechSupport",
    servico: "Formatação e Instalação",
    email: "carlos@techsupport.com.br",
    plano: "Básico Top Avaliado",
    avaliacao: 4.5,
    status: "ativo",
    verificado: true,
    dataCadastro: "20/01/2025",
  },
  {
    id: "4",
    nome: "Ana Pereira",
    empresa: "Hidráulica Express",
    servico: "Serviços de Hidráulica",
    email: "ana@hidraulicaexpress.com.br",
    plano: "Gratuito",
    avaliacao: 4.6,
    status: "pendente",
    verificado: false,
    dataCadastro: "25/01/2025",
  },
  {
    id: "5",
    nome: "Roberto Almeida",
    empresa: "Montagem Profissional",
    servico: "Montagem de Móveis",
    email: "roberto@montagemprofissional.com.br",
    plano: "Gratuito",
    avaliacao: 4.4,
    status: "ativo",
    verificado: true,
    dataCadastro: "30/01/2025",
  },
]

const clientesData = [
  {
    id: "1",
    nome: "Ana Souza",
    email: "ana.souza@email.com",
    pontos: 25,
    servicosContratados: 5,
    status: "ativo",
    dataCadastro: "05/01/2025",
  },
  {
    id: "2",
    nome: "Pedro Mendes",
    email: "pedro.mendes@email.com",
    pontos: 15,
    servicosContratados: 3,
    status: "ativo",
    dataCadastro: "08/01/2025",
  },
  {
    id: "3",
    nome: "Carla Ferreira",
    email: "carla.ferreira@email.com",
    pontos: 10,
    servicosContratados: 2,
    status: "ativo",
    dataCadastro: "12/01/2025",
  },
  {
    id: "4",
    nome: "Lucas Oliveira",
    email: "lucas.oliveira@email.com",
    pontos: 5,
    servicosContratados: 1,
    status: "inativo",
    dataCadastro: "15/01/2025",
  },
  {
    id: "5",
    nome: "Mariana Costa",
    email: "mariana.costa@email.com",
    pontos: 30,
    servicosContratados: 6,
    status: "ativo",
    dataCadastro: "20/01/2025",
  },
]

const denunciasData = [
  {
    id: "1",
    tipo: "Conteúdo Inadequado",
    denunciante: "Ana Souza",
    denunciado: "Silva Jardinagem",
    descricao: "Foto com conteúdo inadequado no perfil",
    status: "pendente",
    data: "01/05/2025",
  },
  {
    id: "2",
    tipo: "Serviço Não Realizado",
    denunciante: "Pedro Mendes",
    denunciado: "Transportes Rápidos",
    descricao: "Prestador não compareceu na data agendada",
    status: "em análise",
    data: "02/05/2025",
  },
  {
    id: "3",
    tipo: "Comportamento Inadequado",
    denunciante: "Carla Ferreira",
    denunciado: "TechSupport",
    descricao: "Prestador foi rude durante o atendimento",
    status: "resolvido",
    data: "03/05/2025",
  },
]

export default function AdminPage() {
  const [searchPrestadores, setSearchPrestadores] = useState("")
  const [searchClientes, setSearchClientes] = useState("")
  const [searchDenuncias, setSearchDenuncias] = useState("")

  const filteredPrestadores = prestadoresData.filter(
    (prestador) =>
      prestador.nome.toLowerCase().includes(searchPrestadores.toLowerCase()) ||
      prestador.empresa.toLowerCase().includes(searchPrestadores.toLowerCase()) ||
      prestador.email.toLowerCase().includes(searchPrestadores.toLowerCase()),
  )

  const filteredClientes = clientesData.filter(
    (cliente) =>
      cliente.nome.toLowerCase().includes(searchClientes.toLowerCase()) ||
      cliente.email.toLowerCase().includes(searchClientes.toLowerCase()),
  )

  const filteredDenuncias = denunciasData.filter(
    (denuncia) =>
      denuncia.denunciante.toLowerCase().includes(searchDenuncias.toLowerCase()) ||
      denuncia.denunciado.toLowerCase().includes(searchDenuncias.toLowerCase()) ||
      denuncia.tipo.toLowerCase().includes(searchDenuncias.toLowerCase()),
  )

  const handleVerificarPrestador = (id: string) => {
    toast({
      title: "Prestador verificado",
      description: "O prestador foi verificado com sucesso.",
    })
  }

  const handleBloquearPrestador = (id: string) => {
    toast({
      title: "Prestador bloqueado",
      description: "O prestador foi bloqueado com sucesso.",
    })
  }

  const handleBloquearCliente = (id: string) => {
    toast({
      title: "Cliente bloqueado",
      description: "O cliente foi bloqueado com sucesso.",
    })
  }

  const handleResolverDenuncia = (id: string) => {
    toast({
      title: "Denúncia resolvida",
      description: "A denúncia foi marcada como resolvida.",
    })
  }

  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />

      <div className="flex-grow bg-background py-8">
        <div className="caldas-container">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h1 className="text-3xl font-bold">Painel Administrativo</h1>
              <p className="text-gray-600">Gerencie prestadores, clientes e denúncias</p>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="outline" className="flex items-center">
                <Settings className="h-4 w-4 mr-2" />
                Configurações
              </Button>
              <div className="flex items-center space-x-2">
                <div className="relative w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white">
                  <span className="text-sm font-medium">A</span>
                </div>
                <span className="font-medium">Admin</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card>
              <CardContent className="p-6 flex items-center">
                <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mr-4">
                  <Users className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">Total de Prestadores</p>
                  <h3 className="text-2xl font-bold">{prestadoresData.length}</h3>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 flex items-center">
                <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mr-4">
                  <Users className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">Total de Clientes</p>
                  <h3 className="text-2xl font-bold">{clientesData.length}</h3>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 flex items-center">
                <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center mr-4">
                  <Flag className="h-6 w-6 text-red-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">Denúncias Pendentes</p>
                  <h3 className="text-2xl font-bold">{denunciasData.filter((d) => d.status !== "resolvido").length}</h3>
                </div>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="prestadores">
            <TabsList className="grid grid-cols-3 mb-8">
              <TabsTrigger value="prestadores" className="flex items-center">
                <Users className="h-4 w-4 mr-2" />
                Prestadores
              </TabsTrigger>
              <TabsTrigger value="clientes" className="flex items-center">
                <Users className="h-4 w-4 mr-2" />
                Clientes
              </TabsTrigger>
              <TabsTrigger value="denuncias" className="flex items-center">
                <Flag className="h-4 w-4 mr-2" />
                Denúncias
              </TabsTrigger>
            </TabsList>

            <TabsContent value="prestadores">
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle>Gerenciar Prestadores</CardTitle>
                      <CardDescription>Lista de todos os prestadores cadastrados na plataforma</CardDescription>
                    </div>
                    <div className="relative">
                      <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
                      <Input
                        placeholder="Buscar prestadores..."
                        className="pl-8 w-[300px]"
                        value={searchPrestadores}
                        onChange={(e) => setSearchPrestadores(e.target.value)}
                      />
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Prestador</TableHead>
                        <TableHead>Serviço</TableHead>
                        <TableHead>Plano</TableHead>
                        <TableHead>Avaliação</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Verificado</TableHead>
                        <TableHead>Data de Cadastro</TableHead>
                        <TableHead className="text-right">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredPrestadores.map((prestador) => (
                        <TableRow key={prestador.id}>
                          <TableCell>
                            <div className="flex items-center">
                              <div className="font-medium">{prestador.empresa}</div>
                              <div className="text-sm text-gray-500 ml-2">({prestador.nome})</div>
                            </div>
                            <div className="text-xs text-gray-500">{prestador.email}</div>
                          </TableCell>
                          <TableCell>{prestador.servico}</TableCell>
                          <TableCell>
                            <Badge
                              className={`${
                                prestador.plano === "Premium"
                                  ? "bg-secondary"
                                  : prestador.plano === "Básico Top Avaliado"
                                    ? "bg-primary"
                                    : prestador.plano === "Básico"
                                      ? "bg-blue-500"
                                      : "bg-gray-500"
                              }`}
                            >
                              {prestador.plano}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center">
                              <Star className="h-4 w-4 text-yellow-500 mr-1" />
                              {prestador.avaliacao}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant={prestador.status === "ativo" ? "default" : "secondary"}
                              className={`${
                                prestador.status === "ativo" ? "bg-green-500" : "bg-yellow-500"
                              } text-white`}
                            >
                              {prestador.status === "ativo" ? "Ativo" : "Pendente"}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {prestador.verificado ? (
                              <CheckCircle className="h-5 w-5 text-green-500" />
                            ) : (
                              <XCircle className="h-5 w-5 text-red-500" />
                            )}
                          </TableCell>
                          <TableCell>{prestador.dataCadastro}</TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" className="h-8 w-8 p-0">
                                  <span className="sr-only">Abrir menu</span>
                                  <MoreVertical className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Ações</DropdownMenuLabel>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem onClick={() => window.open(`/prestador/${prestador.id}`, "_blank")}>
                                  <Eye className="h-4 w-4 mr-2" />
                                  Ver Perfil
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleVerificarPrestador(prestador.id)}>
                                  <CheckCircle className="h-4 w-4 mr-2" />
                                  {prestador.verificado ? "Remover Verificação" : "Verificar"}
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleBloquearPrestador(prestador.id)}>
                                  <XCircle className="h-4 w-4 mr-2" />
                                  {prestador.status === "ativo" ? "Bloquear" : "Ativar"}
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Edit className="h-4 w-4 mr-2" />
                                  Editar
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem className="text-red-600">
                                  <Trash className="h-4 w-4 mr-2" />
                                  Excluir
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="clientes">
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle>Gerenciar Clientes</CardTitle>
                      <CardDescription>Lista de todos os clientes cadastrados na plataforma</CardDescription>
                    </div>
                    <div className="relative">
                      <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
                      <Input
                        placeholder="Buscar clientes..."
                        className="pl-8 w-[300px]"
                        value={searchClientes}
                        onChange={(e) => setSearchClientes(e.target.value)}
                      />
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Nome</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Pontos</TableHead>
                        <TableHead>Serviços Contratados</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Data de Cadastro</TableHead>
                        <TableHead className="text-right">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredClientes.map((cliente) => (
                        <TableRow key={cliente.id}>
                          <TableCell className="font-medium">{cliente.nome}</TableCell>
                          <TableCell>{cliente.email}</TableCell>
                          <TableCell>{cliente.pontos}</TableCell>
                          <TableCell>{cliente.servicosContratados}</TableCell>
                          <TableCell>
                            <Badge
                              variant={cliente.status === "ativo" ? "default" : "secondary"}
                              className={`${cliente.status === "ativo" ? "bg-green-500" : "bg-red-500"} text-white`}
                            >
                              {cliente.status === "ativo" ? "Ativo" : "Inativo"}
                            </Badge>
                          </TableCell>
                          <TableCell>{cliente.dataCadastro}</TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" className="h-8 w-8 p-0">
                                  <span className="sr-only">Abrir menu</span>
                                  <MoreVertical className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Ações</DropdownMenuLabel>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem>
                                  <Eye className="h-4 w-4 mr-2" />
                                  Ver Detalhes
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleBloquearCliente(cliente.id)}>
                                  <XCircle className="h-4 w-4 mr-2" />
                                  {cliente.status === "ativo" ? "Bloquear" : "Ativar"}
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Edit className="h-4 w-4 mr-2" />
                                  Editar
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem className="text-red-600">
                                  <Trash className="h-4 w-4 mr-2" />
                                  Excluir
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="denuncias">
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle>Gerenciar Denúncias</CardTitle>
                      <CardDescription>Lista de todas as denúncias recebidas na plataforma</CardDescription>
                    </div>
                    <div className="relative">
                      <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
                      <Input
                        placeholder="Buscar denúncias..."
                        className="pl-8 w-[300px]"
                        value={searchDenuncias}
                        onChange={(e) => setSearchDenuncias(e.target.value)}
                      />
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Tipo</TableHead>
                        <TableHead>Denunciante</TableHead>
                        <TableHead>Denunciado</TableHead>
                        <TableHead>Descrição</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Data</TableHead>
                        <TableHead className="text-right">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredDenuncias.map((denuncia) => (
                        <TableRow key={denuncia.id}>
                          <TableCell>{denuncia.tipo}</TableCell>
                          <TableCell>{denuncia.denunciante}</TableCell>
                          <TableCell>{denuncia.denunciado}</TableCell>
                          <TableCell className="max-w-xs truncate">{denuncia.descricao}</TableCell>
                          <TableCell>
                            <Badge
                              className={`${
                                denuncia.status === "pendente"
                                  ? "bg-yellow-500"
                                  : denuncia.status === "em análise"
                                    ? "bg-blue-500"
                                    : "bg-green-500"
                              } text-white`}
                            >
                              {denuncia.status}
                            </Badge>
                          </TableCell>
                          <TableCell>{denuncia.data}</TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" className="h-8 w-8 p-0">
                                  <span className="sr-only">Abrir menu</span>
                                  <MoreVertical className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Ações</DropdownMenuLabel>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem>
                                  <Eye className="h-4 w-4 mr-2" />
                                  Ver Detalhes
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleResolverDenuncia(denuncia.id)}>
                                  <CheckCircle className="h-4 w-4 mr-2" />
                                  Marcar como Resolvido
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <MessageSquare className="h-4 w-4 mr-2" />
                                  Enviar Mensagem
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </main>
  )
}
