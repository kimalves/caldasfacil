import { Skeleton } from "@/components/ui/skeleton"

export default function DivulgueAquiLoading() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section Skeleton */}
      <section className="bg-gradient-to-r from-primary to-primary-dark text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <Skeleton className="h-10 w-3/4 mx-auto mb-6 bg-white/20" />
            <Skeleton className="h-6 w-full mx-auto mb-8 bg-white/20" />
            <Skeleton className="h-12 w-40 mx-auto bg-white/20" />
          </div>
        </div>
      </section>

      {/* Benefícios Skeleton */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <Skeleton className="h-10 w-64 mx-auto mb-12" />

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="text-center p-6 rounded-lg border border-gray-100 shadow-sm">
                <Skeleton className="w-16 h-16 rounded-full mx-auto mb-4" />
                <Skeleton className="h-6 w-40 mx-auto mb-2" />
                <Skeleton className="h-4 w-full mx-auto" />
                <Skeleton className="h-4 w-5/6 mx-auto mt-2" />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Planos Skeleton */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <Skeleton className="h-10 w-64 mx-auto mb-4" />
          <Skeleton className="h-6 w-96 mx-auto mb-12" />

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="border rounded-lg p-6 flex flex-col">
                <Skeleton className="h-8 w-32 mb-4" />
                <Skeleton className="h-10 w-24 mb-6" />

                <div className="space-y-2 mb-8">
                  {[...Array(4)].map((_, j) => (
                    <div key={j} className="flex items-start">
                      <Skeleton className="h-5 w-5 mr-2 flex-shrink-0" />
                      <Skeleton className="h-5 w-full" />
                    </div>
                  ))}
                </div>

                <Skeleton className="h-10 w-full mt-auto" />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Anúncios Skeleton */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <Skeleton className="h-10 w-64 mx-auto mb-4" />
          <Skeleton className="h-6 w-96 mx-auto mb-12" />

          <div className="max-w-5xl mx-auto">
            <Skeleton className="h-12 w-full mb-8" />

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="border rounded-lg overflow-hidden">
                  <Skeleton className="h-48 w-full" />
                  <div className="p-6">
                    <Skeleton className="h-6 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-1/2 mb-4" />
                    <Skeleton className="h-4 w-full mb-2" />
                    <Skeleton className="h-4 w-5/6 mb-6" />
                    <Skeleton className="h-10 w-full" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
