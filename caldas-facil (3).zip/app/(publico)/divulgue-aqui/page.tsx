import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Check, Star } from "lucide-react"

// Componente para exibir um anúncio
function Anuncio({
  empresa,
  descricao,
  imagem,
  telefone,
  destaque = false,
}: {
  empresa: string
  descricao: string
  imagem: string
  telefone: string
  destaque?: boolean
}) {
  return (
    <Card className={`overflow-hidden ${destaque ? "border-primary shadow-lg" : ""}`}>
      {destaque && (
        <div className="bg-primary text-white text-center py-1 text-xs font-medium">ANÚNCIO EM DESTAQUE</div>
      )}
      <div className="relative h-48 w-full">
        <Image src={imagem || "/placeholder.svg"} alt={empresa} fill className="object-cover" />
      </div>
      <CardHeader>
        <CardTitle>{empresa}</CardTitle>
        <CardDescription>{telefone}</CardDescription>
      </CardHeader>
      <CardContent>
        <p>{descricao}</p>
      </CardContent>
      <CardFooter>
        <Button className="w-full">Contatar</Button>
      </CardFooter>
    </Card>
  )
}

// Dados fictícios para anúncios
const anuncios = [
  {
    id: 1,
    empresa: "Elétrica Raio",
    descricao: "Serviços elétricos residenciais e comerciais com qualidade e segurança.",
    imagem: "/placeholder.svg?height=400&width=600",
    telefone: "(35) 99876-5432",
    destaque: true,
  },
  {
    id: 2,
    empresa: "Encanador 24h",
    descricao: "Atendimento emergencial para problemas hidráulicos a qualquer hora.",
    imagem: "/placeholder.svg?height=400&width=600",
    telefone: "(35) 99765-4321",
    destaque: false,
  },
  {
    id: 3,
    empresa: "Pinturas Artísticas",
    descricao: "Transforme sua casa com pinturas decorativas e acabamentos especiais.",
    imagem: "/placeholder.svg?height=400&width=600",
    telefone: "(35) 99654-3210",
    destaque: false,
  },
  {
    id: 4,
    empresa: "Jardinagem Verde Vida",
    descricao: "Cuidamos do seu jardim com dedicação e conhecimento técnico.",
    imagem: "/placeholder.svg?height=400&width=600",
    telefone: "(35) 99543-2109",
    destaque: true,
  },
  {
    id: 5,
    empresa: "Marido de Aluguel",
    descricao: "Pequenos reparos domésticos com agilidade e preço justo.",
    imagem: "/placeholder.svg?height=400&width=600",
    telefone: "(35) 99432-1098",
    destaque: false,
  },
  {
    id: 6,
    empresa: "Limpeza Total",
    descricao: "Serviços de limpeza residencial e comercial com produtos ecológicos.",
    imagem: "/placeholder.svg?height=400&width=600",
    telefone: "(35) 99321-0987",
    destaque: false,
  },
]

// Planos de anúncio
const planosAnuncio = [
  {
    id: "basico",
    nome: "Básico",
    preco: 19.9,
    periodo: "mensal",
    recursos: [
      "Anúncio na página Divulgue Aqui",
      "Visibilidade por 30 dias",
      "Contato direto com clientes",
      "Até 3 fotos",
    ],
  },
  {
    id: "destaque",
    nome: "Destaque",
    preco: 39.9,
    periodo: "mensal",
    popular: true,
    recursos: [
      "Todos os recursos do plano Básico",
      "Posição destacada na página",
      "Tag de 'Anúncio em Destaque'",
      "Até 10 fotos",
      "Destaque nas buscas por 15 dias",
    ],
  },
  {
    id: "premium-light",
    nome: "Premium Light",
    preco: 69.9,
    periodo: "mensal",
    recursos: [
      "Todos os recursos do plano Destaque",
      "Banner rotativo na página inicial",
      "Destaque nas buscas por 30 dias",
      "Relatório de visualizações",
      "Suporte prioritário",
    ],
  },
]

export default function DivulgueAquiPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary to-primary-dark text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl font-bold mb-6">Divulgue Seu Negócio</h1>
            <p className="text-xl mb-8">
              Aumente sua visibilidade e conquiste mais clientes com anúncios no Caldas Fácil
            </p>
            <Button size="lg" className="bg-secondary hover:bg-secondary-dark text-white">
              Anuncie Agora
            </Button>
          </div>
        </div>
      </section>

      {/* Benefícios */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Por que anunciar no Caldas Fácil?</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6 rounded-lg border border-gray-100 shadow-sm">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4 mx-auto">
                <Star className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Visibilidade Local</h3>
              <p className="text-gray-600">
                Alcance clientes que estão buscando exatamente os serviços que você oferece em Caldas.
              </p>
            </div>

            <div className="text-center p-6 rounded-lg border border-gray-100 shadow-sm">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4 mx-auto">
                <Star className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Custo Acessível</h3>
              <p className="text-gray-600">
                Planos a partir de R$ 19,90 por mês, muito mais barato que anúncios tradicionais.
              </p>
            </div>

            <div className="text-center p-6 rounded-lg border border-gray-100 shadow-sm">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4 mx-auto">
                <Star className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Contato Direto</h3>
              <p className="text-gray-600">Os clientes entram em contato diretamente com você, sem intermediários.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Planos de Anúncio */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-4">Escolha seu plano</h2>
          <p className="text-center text-gray-600 mb-12 max-w-2xl mx-auto">
            Temos opções para todos os tipos de negócios. Escolha o plano que melhor se adapta às suas necessidades.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {planosAnuncio.map((plano) => (
              <Card key={plano.id} className={`flex flex-col ${plano.popular ? "border-primary shadow-lg" : ""}`}>
                {plano.popular && (
                  <div className="bg-primary text-white text-center py-1 text-sm font-medium">Mais Popular</div>
                )}
                <CardHeader>
                  <CardTitle>{plano.nome}</CardTitle>
                  <CardDescription>
                    <div className="mt-2">
                      <span className="text-3xl font-bold">R$ {plano.preco.toFixed(2).replace(".", ",")}</span>
                      <span className="text-sm text-gray-500">/{plano.periodo}</span>
                    </div>
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex-grow">
                  <ul className="space-y-2">
                    {plano.recursos.map((recurso, index) => (
                      <li key={index} className="flex items-start">
                        <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                        <span className="text-sm">{recurso}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button className={`w-full ${plano.popular ? "bg-primary hover:bg-primary-dark" : ""}`}>
                    Contratar
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Anúncios em Exibição */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-4">Anúncios em Destaque</h2>
          <p className="text-center text-gray-600 mb-12 max-w-2xl mx-auto">
            Veja como seu negócio pode aparecer para milhares de potenciais clientes
          </p>

          <Tabs defaultValue="todos" className="max-w-5xl mx-auto">
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger value="todos">Todos</TabsTrigger>
              <TabsTrigger value="destaque">Em Destaque</TabsTrigger>
              <TabsTrigger value="basico">Básicos</TabsTrigger>
            </TabsList>

            <TabsContent value="todos">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {anuncios.map((anuncio) => (
                  <Anuncio
                    key={anuncio.id}
                    empresa={anuncio.empresa}
                    descricao={anuncio.descricao}
                    imagem={anuncio.imagem}
                    telefone={anuncio.telefone}
                    destaque={anuncio.destaque}
                  />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="destaque">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {anuncios
                  .filter((anuncio) => anuncio.destaque)
                  .map((anuncio) => (
                    <Anuncio
                      key={anuncio.id}
                      empresa={anuncio.empresa}
                      descricao={anuncio.descricao}
                      imagem={anuncio.imagem}
                      telefone={anuncio.telefone}
                      destaque={anuncio.destaque}
                    />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="basico">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {anuncios
                  .filter((anuncio) => !anuncio.destaque)
                  .map((anuncio) => (
                    <Anuncio
                      key={anuncio.id}
                      empresa={anuncio.empresa}
                      descricao={anuncio.descricao}
                      imagem={anuncio.imagem}
                      telefone={anuncio.telefone}
                      destaque={anuncio.destaque}
                    />
                  ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Formulário de Contato */}
      <section className="py-16 bg-primary text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6">Pronto para anunciar?</h2>
            <p className="text-xl mb-8">
              Entre em contato conosco e um de nossos consultores entrará em contato para ajudá-lo a escolher o melhor
              plano para o seu negócio.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link href="/contato">
                <Button size="lg" className="bg-white text-primary hover:bg-gray-100 w-full sm:w-auto">
                  Fale Conosco
                </Button>
              </Link>
              <Link href="/cadastro-prestador">
                <Button size="lg" className="bg-secondary hover:bg-secondary-dark text-white w-full sm:w-auto">
                  Cadastre-se como Prestador
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
