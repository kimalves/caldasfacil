"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { PlanoCard } from "@/components/plano-card"
import { siteConfig } from "@/config/site"
import { useToast } from "@/hooks/use-toast"

export default function PlanosPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null)

  const handleSelectPlan = (id: string) => {
    setSelectedPlan(id)

    // Verificar se o usuário está logado
    // Em um cenário real, verificaríamos a sessão do usuário
    const isLoggedIn = false

    if (!isLoggedIn) {
      toast({
        title: "Login necessário",
        description: "Faça login como prestador para assinar um plano",
      })

      // Redirecionar para a página de login com o plano selecionado como parâmetro
      router.push(`/login-prestador?plano=${id}`)
      return
    }

    // Se estiver logado, redirecionar para a página de pagamento
    router.push(`/pagamento?plano=${id}`)
  }

  return (
    <div className="py-16">
      <div className="caldas-container">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Nossos Planos</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Escolha o plano ideal para o seu negócio e aumente sua visibilidade na plataforma
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {siteConfig.planos.map((plano, index) => (
            <PlanoCard
              key={plano.id}
              id={plano.id}
              nome={plano.nome}
              preco={plano.preco}
              descricao={plano.descricao}
              recursos={plano.recursos}
              popular={index === 1} // O plano do meio (Premium) é marcado como popular
              onSelect={handleSelectPlan}
            />
          ))}
        </div>

        <div className="mt-16 text-center">
          <h2 className="text-2xl font-semibold mb-6">Perguntas Frequentes</h2>

          <div className="max-w-3xl mx-auto space-y-6 text-left">
            <div>
              <h3 className="text-lg font-medium mb-2">Como funciona o plano Premium?</h3>
              <p className="text-gray-600">
                O plano Premium oferece destaque na plataforma, aparecendo primeiro nas buscas e com um badge especial
                no seu perfil, aumentando a visibilidade e as chances de ser contratado.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-medium mb-2">Posso mudar de plano depois?</h3>
              <p className="text-gray-600">
                Sim, você pode fazer upgrade ou downgrade do seu plano a qualquer momento. As mudanças entram em vigor
                no próximo ciclo de cobrança.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-medium mb-2">Como é feito o pagamento?</h3>
              <p className="text-gray-600">
                Aceitamos pagamentos via cartão de crédito, boleto bancário e PIX. O pagamento é processado de forma
                segura através da nossa plataforma.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-medium mb-2">Existe período de teste?</h3>
              <p className="text-gray-600">
                Sim, oferecemos 7 dias de teste gratuito para os planos Premium e Profissional. Você pode cancelar a
                qualquer momento durante esse período sem ser cobrado.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
