import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Users, Award, Clock, MapPin } from "lucide-react"

export default function QuemSomosPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary to-primary-dark text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl font-bold mb-6">Quem Somos</h1>
            <p className="text-xl mb-8">
              Conheça a história e a missão do Caldas Fácil, conectando pessoas e serviços desde 2023
            </p>
          </div>
        </div>
      </section>

      {/* Nossa História */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">Nossa História</h2>
              <p className="text-gray-700 mb-4">
                O Caldas Fácil nasceu da necessidade de conectar prestadores de serviços qualificados com clientes que
                precisam de soluções rápidas e confiáveis em Caldas.
              </p>
              <p className="text-gray-700 mb-4">
                Fundado em 2023 por um grupo de empreendedores locais, nossa plataforma surgiu para resolver um problema
                comum: a dificuldade de encontrar bons profissionais para serviços do dia a dia.
              </p>
              <p className="text-gray-700">
                Desde então, temos trabalhado para criar um ecossistema que beneficia tanto os prestadores de serviços
                quanto os clientes, promovendo a economia local e facilitando o acesso a serviços de qualidade.
              </p>
            </div>
            <div className="relative h-80 w-full rounded-lg overflow-hidden shadow-lg">
              <Image
                src="/placeholder.svg?height=600&width=800"
                alt="Equipe Caldas Fácil"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Missão, Visão e Valores */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Missão, Visão e Valores</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card>
              <CardContent className="pt-6">
                <h3 className="text-xl font-semibold mb-4 text-primary">Nossa Missão</h3>
                <p className="text-gray-700">
                  Conectar pessoas a serviços de qualidade, promovendo o desenvolvimento econômico local e facilitando o
                  dia a dia dos moradores de Caldas.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <h3 className="text-xl font-semibold mb-4 text-primary">Nossa Visão</h3>
                <p className="text-gray-700">
                  Ser a principal plataforma de conexão entre prestadores de serviços e clientes em Caldas, reconhecida
                  pela qualidade, confiança e facilidade de uso.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <h3 className="text-xl font-semibold mb-4 text-primary">Nossos Valores</h3>
                <ul className="text-gray-700 space-y-2">
                  <li>• Transparência em todas as relações</li>
                  <li>• Compromisso com a qualidade</li>
                  <li>• Valorização dos profissionais locais</li>
                  <li>• Foco na satisfação do cliente</li>
                  <li>• Inovação constante</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Números */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Caldas Fácil em Números</h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center p-6 rounded-lg border border-gray-100 shadow-sm">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4 mx-auto">
                <Users className="h-8 w-8 text-primary" />
              </div>
              <div className="text-4xl font-bold text-gray-800 mb-2">500+</div>
              <p className="text-gray-600">Prestadores Cadastrados</p>
            </div>

            <div className="text-center p-6 rounded-lg border border-gray-100 shadow-sm">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4 mx-auto">
                <Award className="h-8 w-8 text-primary" />
              </div>
              <div className="text-4xl font-bold text-gray-800 mb-2">2000+</div>
              <p className="text-gray-600">Serviços Realizados</p>
            </div>

            <div className="text-center p-6 rounded-lg border border-gray-100 shadow-sm">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4 mx-auto">
                <Clock className="h-8 w-8 text-primary" />
              </div>
              <div className="text-4xl font-bold text-gray-800 mb-2">15min</div>
              <p className="text-gray-600">Tempo Médio de Resposta</p>
            </div>

            <div className="text-center p-6 rounded-lg border border-gray-100 shadow-sm">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4 mx-auto">
                <MapPin className="h-8 w-8 text-primary" />
              </div>
              <div className="text-4xl font-bold text-gray-800 mb-2">100%</div>
              <p className="text-gray-600">Cobertura em Caldas</p>
            </div>
          </div>
        </div>
      </section>

      {/* Equipe */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Nossa Equipe</h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { nome: "Carlos Silva", cargo: "CEO & Fundador", foto: "/placeholder.svg?height=300&width=300" },
              { nome: "Ana Oliveira", cargo: "Diretora de Operações", foto: "/placeholder.svg?height=300&width=300" },
              { nome: "Marcos Santos", cargo: "Desenvolvedor Chefe", foto: "/placeholder.svg?height=300&width=300" },
              { nome: "Juliana Costa", cargo: "Marketing", foto: "/placeholder.svg?height=300&width=300" },
            ].map((membro, index) => (
              <div key={index} className="text-center">
                <div className="relative h-64 w-64 rounded-full overflow-hidden mx-auto mb-4">
                  <Image src={membro.foto || "/placeholder.svg"} alt={membro.nome} fill className="object-cover" />
                </div>
                <h3 className="text-xl font-semibold mb-1">{membro.nome}</h3>
                <p className="text-gray-600">{membro.cargo}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
