import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { FeaturedProviders } from "@/components/featured-providers"
import { SearchBar } from "@/components/search-bar"
import { Car, Wrench, Tv, Palette, Droplet, Package, Cpu } from "lucide-react"
// Remover os componentes Navbar e Footer, pois eles já estão no layout

const services = [
  {
    id: 1,
    name: "Transporte",
    description: "Transporte de pessoas e pequenos móveis",
    icon: Car,
  },
  {
    id: 2,
    name: "Informática",
    description: "Formatação e instalação de drivers",
    icon: Cpu,
  },
  {
    id: 3,
    name: "Paisagismo",
    description: "Paisagismo e jardinagem",
    icon: Palette,
  },
  {
    id: 4,
    name: "Mecânica",
    description: "Troca de óleo e pequenos reparos",
    icon: Wrench,
  },
  {
    id: 5,
    name: "Reparos Domésticos",
    description: "Pequenos reparos em casa",
    icon: Wrench, // Changed from Home to avoid redeclaration
  },
  {
    id: 6,
    name: "Montagem",
    description: "Montagem e desmontagem de móveis",
    icon: Package,
  },
  {
    id: 7,
    name: "Instalação",
    description: "Instalação de suporte para televisores",
    icon: Tv,
  },
  {
    id: 8,
    name: "Marketing",
    description: "Marketing digital e identidade visual",
    icon: Palette,
  },
  {
    id: 9,
    name: "Hidráulica",
    description: "Serviços de hidráulica básica",
    icon: Droplet,
  },
]

// Modificar o retorno da função para remover Navbar e Footer
export default function HomePage() {
  return (
    <div className="flex-grow bg-background">
      {/* Hero Section */}
      <section className="py-16 md:py-24">
        <div className="caldas-container text-center">
          <div className="mx-auto mb-12">
            <Image src="/logo.png" alt="Caldas Fácil" width={120} height={120} className="mx-auto" />
          </div>

          <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">Bem-vindo ao Caldas Fácil</h1>

          <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto mb-12">
            Conectamos clientes a prestadores de serviços de forma rápida e eficiente. Escolha como deseja acessar:
          </p>

          <div className="flex flex-col sm:flex-row justify-center gap-4 max-w-md mx-auto">
            <Link href="/login-cliente" className="w-full">
              <Button className="w-full bg-secondary hover:bg-secondary-dark text-white py-6 text-lg">
                Login Cliente <span className="ml-2">→</span>
              </Button>
            </Link>

            <Link href="/login-prestador" className="w-full">
              <Button className="w-full bg-primary hover:bg-primary-dark text-white py-6 text-lg">
                Login Prestador <span className="ml-2">→</span>
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Search Section */}
      <section className="py-12 bg-white">
        <div className="caldas-container">
          <h2 className="text-3xl font-bold text-center mb-8">Encontre o serviço que você precisa</h2>

          <SearchBar />

          <div className="mt-12">
            <FeaturedProviders />
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16">
        <div className="caldas-container">
          <h2 className="text-3xl font-bold text-center mb-12">Serviços Disponíveis</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((service) => (
              <div key={service.id} className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4 mx-auto">
                  <service.icon className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold text-center mb-2">{service.name}</h3>
                <p className="text-gray-600 text-center">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-white">
        <div className="caldas-container">
          <h2 className="text-3xl font-bold text-center mb-12">Como Funciona</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-secondary/20 rounded-full flex items-center justify-center mb-4 mx-auto">
                <span className="text-2xl font-bold text-secondary">1</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Busque</h3>
              <p className="text-gray-600">Encontre o serviço que você precisa através da nossa busca inteligente</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-secondary/20 rounded-full flex items-center justify-center mb-4 mx-auto">
                <span className="text-2xl font-bold text-secondary">2</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Conecte</h3>
              <p className="text-gray-600">Entre em contato com o prestador e solicite um orçamento</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-secondary/20 rounded-full flex items-center justify-center mb-4 mx-auto">
                <span className="text-2xl font-bold text-secondary">3</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Avalie</h3>
              <p className="text-gray-600">Após o serviço, avalie o prestador e ganhe pontos para descontos</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-white">
        <div className="caldas-container text-center">
          <h2 className="text-3xl font-bold mb-6">Pronto para começar?</h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            Cadastre-se agora e tenha acesso a diversos serviços de qualidade ou ofereça seus serviços para milhares de
            clientes.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4 max-w-md mx-auto">
            <Link href="/cadastro-cliente" className="w-full">
              <Button className="w-full bg-white text-primary hover:bg-gray-100 py-6 text-lg">
                Cadastrar como Cliente
              </Button>
            </Link>

            <Link href="/cadastro-prestador" className="w-full">
              <Button className="w-full bg-secondary hover:bg-secondary-dark text-white py-6 text-lg">
                Cadastrar como Prestador
              </Button>
            </Link>
          </div>
          <div className="mt-4">
            <Link href="/meus-servicos" className="text-white hover:underline">
              Já tem cadastro? Acesse seus serviços
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
