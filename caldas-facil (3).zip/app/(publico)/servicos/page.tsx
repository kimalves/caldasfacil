"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Star, MapPin, Filter, Search } from "lucide-react"
import { Badge } from "@/components/ui/badge"
// Importar o componente Footer
import { Footer } from "@/components/footer"

// Dados simulados de prestadores
const prestadoresData = [
  {
    id: 1,
    nome: "João Silva",
    empresa: "Silva Jardinagem",
    servico: "Paisagismo e Jardinagem",
    descricao: "Oferecemos serviços completos de jardinagem e paisagismo para residências e empresas.",
    avaliacao: 4.8,
    distancia: 2.5,
    imagem: "/placeholder.svg?height=80&width=80",
    isPremium: true,
    isTopRated: true,
  },
  {
    id: 2,
    nome: "Maria Oliveira",
    empresa: "Transportes Rápidos",
    servico: "Transporte de Pessoas e Móveis",
    descricao: "Transporte seguro e eficiente para pessoas e pequenos móveis.",
    avaliacao: 4.7,
    distancia: 3.2,
    imagem: "/placeholder.svg?height=80&width=80",
    isPremium: false,
    isTopRated: true,
  },
  {
    id: 3,
    nome: "Carlos Santos",
    empresa: "TechSupport",
    servico: "Formatação e Instalação",
    descricao: "Serviços de informática, formatação de computadores e instalação de drivers.",
    avaliacao: 4.5,
    distancia: 5.0,
    imagem: "/placeholder.svg?height=80&width=80",
    isPremium: true,
    isTopRated: false,
  },
  {
    id: 4,
    nome: "Ana Pereira",
    empresa: "Hidráulica Express",
    servico: "Serviços de Hidráulica",
    descricao: "Serviços de hidráulica básica, consertos e instalações.",
    avaliacao: 4.6,
    distancia: 1.8,
    imagem: "/placeholder.svg?height=80&width=80",
    isPremium: false,
    isTopRated: true,
  },
  {
    id: 5,
    nome: "Roberto Almeida",
    empresa: "Montagem Profissional",
    servico: "Montagem de Móveis",
    descricao: "Montagem e desmontagem de móveis com qualidade e rapidez.",
    avaliacao: 4.4,
    distancia: 4.3,
    imagem: "/placeholder.svg?height=80&width=80",
    isPremium: false,
    isTopRated: false,
  },
  {
    id: 6,
    nome: "Fernanda Lima",
    empresa: "Marketing Digital",
    servico: "Identidade Visual",
    descricao: "Criação de identidade visual, logotipos e materiais de marketing.",
    avaliacao: 4.9,
    distancia: 6.1,
    imagem: "/placeholder.svg?height=80&width=80",
    isPremium: true,
    isTopRated: true,
  },
  {
    id: 7,
    nome: "Paulo Mendes",
    empresa: "Reparos Domésticos",
    servico: "Pequenos Reparos",
    descricao: "Serviços de pequenos reparos domésticos e manutenções.",
    avaliacao: 4.3,
    distancia: 3.7,
    imagem: "/placeholder.svg?height=80&width=80",
    isPremium: false,
    isTopRated: false,
  },
  {
    id: 8,
    nome: "Luciana Costa",
    empresa: "Instalações Elétricas",
    servico: "Troca de Chuveiro",
    descricao: "Especialista em instalações elétricas e troca de chuveiros.",
    avaliacao: 4.7,
    distancia: 2.9,
    imagem: "/placeholder.svg?height=80&width=80",
    isPremium: false,
    isTopRated: true,
  },
]

// Categorias de serviços
const categorias = [
  { id: "todos", nome: "Todos os Serviços" },
  { id: "transporte", nome: "Transporte" },
  { id: "informatica", nome: "Informática" },
  { id: "paisagismo", nome: "Paisagismo" },
  { id: "mecanica", nome: "Mecânica" },
  { id: "reparos", nome: "Reparos Domésticos" },
  { id: "montagem", nome: "Montagem" },
  { id: "instalacao", nome: "Instalação" },
  { id: "marketing", nome: "Marketing" },
  { id: "hidraulica", nome: "Hidráulica" },
]

export default function ServicosPage() {
  const searchParams = useSearchParams()
  const initialQuery = searchParams.get("q") || ""

  const [searchTerm, setSearchTerm] = useState(initialQuery)
  const [categoria, setCategoria] = useState("todos")
  const [distanciaMax, setDistanciaMax] = useState(10)
  const [avaliacaoMin, setAvaliacaoMin] = useState(0)
  const [showFilters, setShowFilters] = useState(false)

  // Filtrar prestadores
  const prestadoresFiltrados = prestadoresData.filter((prestador) => {
    // Filtro de busca
    const matchesSearch =
      searchTerm === "" ||
      prestador.empresa.toLowerCase().includes(searchTerm.toLowerCase()) ||
      prestador.servico.toLowerCase().includes(searchTerm.toLowerCase()) ||
      prestador.descricao.toLowerCase().includes(searchTerm.toLowerCase())

    // Filtro de categoria
    const matchesCategoria = categoria === "todos" || prestador.servico.toLowerCase().includes(categoria.toLowerCase())

    // Filtro de distância
    const matchesDistancia = prestador.distancia <= distanciaMax

    // Filtro de avaliação
    const matchesAvaliacao = prestador.avaliacao >= avaliacaoMin

    return matchesSearch && matchesCategoria && matchesDistancia && matchesAvaliacao
  })

  // Ordenar prestadores: primeiro Premium + Top Avaliados, depois Premium, depois Top Avaliados, depois os demais
  const prestadoresOrdenados = [...prestadoresFiltrados].sort((a, b) => {
    if (a.isPremium && a.isTopRated && !(b.isPremium && b.isTopRated)) return -1
    if (b.isPremium && b.isTopRated && !(a.isPremium && a.isTopRated)) return 1
    if (a.isPremium && !b.isPremium) return -1
    if (b.isPremium && !a.isPremium) return 1
    if (a.isTopRated && !b.isTopRated) return -1
    if (b.isTopRated && !a.isTopRated) return 1
    return b.avaliacao - a.avaliacao
  })

  // Adicionar o Footer no final da página
  return (
    <div className="flex-grow bg-background py-8">
      <div className="caldas-container">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Serviços Disponíveis</h1>
          <p className="text-gray-600">Encontre os melhores prestadores de serviços em Caldas</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-[300px_1fr] gap-8">
          {/* Filtros */}
          <div className="space-y-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-semibold">Filtros</h2>
                  <Button variant="ghost" size="sm" className="lg:hidden" onClick={() => setShowFilters(!showFilters)}>
                    <Filter className="h-4 w-4 mr-2" />
                    {showFilters ? "Ocultar" : "Mostrar"}
                  </Button>
                </div>

                <div className={`space-y-6 ${showFilters ? "block" : "hidden lg:block"}`}>
                  <div className="space-y-2">
                    <label className="font-medium">Buscar</label>
                    <div className="relative">
                      <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
                      <Input
                        placeholder="Buscar serviços..."
                        className="pl-8"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="font-medium">Categoria</label>
                    <Select value={categoria} onValueChange={setCategoria}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione uma categoria" />
                      </SelectTrigger>
                      <SelectContent>
                        {categorias.map((cat) => (
                          <SelectItem key={cat.id} value={cat.id}>
                            {cat.nome}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="font-medium">Distância Máxima</label>
                      <span className="text-sm text-gray-500">{distanciaMax} km</span>
                    </div>
                    <Slider
                      defaultValue={[distanciaMax]}
                      max={20}
                      step={1}
                      onValueChange={(value) => setDistanciaMax(value[0])}
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="font-medium">Avaliação Mínima</label>
                      <div className="flex items-center">
                        <Star className="h-4 w-4 text-yellow-500 mr-1" />
                        <span className="text-sm text-gray-500">{avaliacaoMin}</span>
                      </div>
                    </div>
                    <Slider
                      defaultValue={[avaliacaoMin]}
                      max={5}
                      step={0.5}
                      onValueChange={(value) => setAvaliacaoMin(value[0])}
                    />
                  </div>

                  <Button
                    className="w-full bg-primary hover:bg-primary-dark"
                    onClick={() => {
                      // Reset filters
                      setSearchTerm("")
                      setCategoria("todos")
                      setDistanciaMax(10)
                      setAvaliacaoMin(0)
                    }}
                  >
                    Limpar Filtros
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="hidden lg:block">
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold mb-4">Serviços Populares</h2>
                <div className="space-y-2">
                  {categorias.slice(1, 6).map((cat) => (
                    <Button
                      key={cat.id}
                      variant="outline"
                      className="w-full justify-start"
                      onClick={() => setCategoria(cat.id)}
                    >
                      {cat.nome}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Lista de Prestadores */}
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <p className="text-gray-600">{prestadoresOrdenados.length} prestadores encontrados</p>
              <Select defaultValue="avaliacao">
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Ordenar por" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="avaliacao">Melhor Avaliação</SelectItem>
                  <SelectItem value="distancia">Menor Distância</SelectItem>
                  <SelectItem value="recentes">Mais Recentes</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {prestadoresOrdenados.length === 0 ? (
              <div className="bg-white p-8 rounded-lg text-center">
                <p className="text-gray-500 mb-4">Nenhum prestador encontrado com os filtros selecionados.</p>
                <Button
                  variant="outline"
                  onClick={() => {
                    setSearchTerm("")
                    setCategoria("todos")
                    setDistanciaMax(10)
                    setAvaliacaoMin(0)
                  }}
                >
                  Limpar Filtros
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {prestadoresOrdenados.map((prestador) => (
                  <Link href={`/prestador/${prestador.id}`} key={prestador.id}>
                    <Card className="hover:shadow-md transition-shadow">
                      <CardContent className="p-6">
                        <div className="flex flex-col md:flex-row md:items-center">
                          <div className="relative w-20 h-20 rounded-full overflow-hidden mb-4 md:mb-0 md:mr-6">
                            <Image
                              src={prestador.imagem || "/placeholder.svg"}
                              alt={prestador.empresa}
                              fill
                              className="object-cover"
                            />
                          </div>

                          <div className="flex-grow">
                            <div className="flex flex-col md:flex-row md:justify-between md:items-start">
                              <div>
                                <h3 className="text-xl font-semibold">{prestador.empresa}</h3>
                                <p className="text-gray-600">{prestador.servico}</p>
                                <div className="flex items-center mt-1 mb-2">
                                  <Star className="h-4 w-4 text-yellow-500 mr-1" />
                                  <span className="mr-4">{prestador.avaliacao}</span>
                                  <MapPin className="h-4 w-4 text-gray-400 mr-1" />
                                  <span className="text-gray-600">{prestador.distancia} km</span>
                                </div>
                              </div>

                              <div className="flex flex-wrap gap-2 mt-2 md:mt-0">
                                {prestador.isPremium && <Badge className="bg-secondary text-white">Premium</Badge>}
                                {prestador.isTopRated && <Badge className="bg-primary text-white">Top Avaliado</Badge>}
                              </div>
                            </div>

                            <p className="text-gray-600 mt-2 line-clamp-2">{prestador.descricao}</p>

                            <div className="mt-4 flex justify-end">
                              <Button className="bg-primary hover:bg-primary-dark">Ver Perfil</Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
      <Footer />
    </div>
  )
}
