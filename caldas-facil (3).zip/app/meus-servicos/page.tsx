import { AuthCheck } from "@/components/auth-check"
// Corrigir a importação do Navbar
import Navbar from "@/components/navbar"
// Remover a importação incorreta
// import { Navbar } from "@/components/navbar"
// Importar o componente Footer
import { Footer } from "@/components/footer"

export default function MeusServicos() {
  // Adicionar o Footer no final da página
  return (
    <AuthCheck>
      <main className="min-h-screen flex flex-col">
        <Navbar />

        <div className="flex-grow bg-background py-8">{/* Conteúdo existente */}</div>

        <Footer />
      </main>
    </AuthCheck>
  )
}
