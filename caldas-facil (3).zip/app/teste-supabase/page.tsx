"use client"

import { useState, useEffect } from "react"
import { getSupabase } from "@/lib/supabase-client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function TesteSupabase() {
  const [status, setStatus] = useState<"carregando" | "sucesso" | "erro">("carregando")
  const [message, setMessage] = useState("")
  const [tables, setTables] = useState<string[]>([])
  const supabase = getSupabase()

  useEffect(() => {
    async function testConnection() {
      try {
        // Testar a conexão com o Supabase
        const { data, error } = await supabase.from("usuarios").select("count()", { count: "exact" })

        if (error) {
          throw error
        }

        // Buscar lista de tabelas
        const { data: tableData, error: tableError } = await supabase
          .from("information_schema.tables")
          .select("table_name")
          .eq("table_schema", "public")

        if (tableError) {
          console.error("Erro ao buscar tabelas:", tableError)
        } else {
          setTables(tableData.map((t) => t.table_name).sort())
        }

        setStatus("sucesso")
        setMessage("Conexão com o Supabase estabelecida com sucesso!")
      } catch (error: any) {
        console.error("Erro ao conectar com o Supabase:", error)
        setStatus("erro")
        setMessage(`Erro ao conectar: ${error.message || "Verifique suas credenciais"}`)
      }
    }

    testConnection()
  }, [])

  return (
    <div className="container mx-auto py-10">
      <Card className="max-w-md mx-auto">
        <CardHeader>
          <CardTitle>Teste de Conexão Supabase</CardTitle>
          <CardDescription>Verificando a conexão com o banco de dados</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div
                className={`w-3 h-3 rounded-full ${
                  status === "carregando" ? "bg-yellow-500" : status === "sucesso" ? "bg-green-500" : "bg-red-500"
                }`}
              ></div>
              <span className="font-medium">
                {status === "carregando"
                  ? "Testando conexão..."
                  : status === "sucesso"
                    ? "Conectado"
                    : "Erro na conexão"}
              </span>
            </div>
            <p>{message}</p>

            {tables.length > 0 && (
              <div className="mt-4">
                <h3 className="font-medium mb-2">Tabelas encontradas:</h3>
                <ul className="list-disc pl-5 space-y-1">
                  {tables.map((table) => (
                    <li key={table}>{table}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={() => window.location.reload()} variant="outline" className="w-full">
            Testar novamente
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
