"use client"

import { useState, useEffect } from "react"
import Navbar from "@/components/navbar"
import { ChatList, type ChatContact } from "@/components/chat/chat-list"
import { ChatWindow, type Message } from "@/components/chat/chat-window"
import { OrçamentoModal, type OrçamentoData } from "@/components/chat/orcamento-modal"
import { FinalizarServicoModal, type FinalizarServicoData } from "@/components/chat/finalizar-servico-modal"
import { toast } from "@/hooks/use-toast"
import { v4 as uuidv4 } from "uuid"

// Dados simulados
const mockContacts: ChatContact[] = [
  {
    id: "1",
    name: "Silva Jardinagem",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "Podemos agendar para a próxima semana",
    timestamp: new Date(Date.now() - 1000 * 60 * 30),
    unreadCount: 2,
    online: true,
    type: "provider",
  },
  {
    id: "2",
    name: "Transportes Rápidos",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "O serviço foi finalizado com sucesso",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 3),
    unreadCount: 0,
    online: false,
    type: "provider",
  },
  {
    id: "3",
    name: "Suporte Caldas Fácil",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "Como podemos ajudar?",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24),
    unreadCount: 0,
    online: true,
    type: "support",
  },
]

const mockMessages: Record<string, Message[]> = {
  "1": [
    {
      id: "m1",
      content: "Olá, gostaria de solicitar um serviço de jardinagem para minha residência",
      sender: "user",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2),
      status: "read",
    },
    {
      id: "m2",
      content: "Olá! Claro, podemos ajudar. Que tipo de serviço de jardinagem você precisa?",
      sender: "other",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 1.5),
    },
    {
      id: "m3",
      content: "Preciso de poda de árvores e manutenção do gramado",
      sender: "user",
      timestamp: new Date(Date.now() - 1000 * 60 * 60),
      status: "read",
    },
    {
      id: "m4",
      content:
        "Entendi. Podemos agendar uma visita para avaliar o trabalho. Você poderia me informar o endereço e quando seria um bom momento para visitarmos?",
      sender: "other",
      timestamp: new Date(Date.now() - 1000 * 60 * 30),
    },
  ],
  "2": [
    {
      id: "m1",
      content: "Preciso transportar alguns móveis para meu novo apartamento",
      sender: "user",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2),
      status: "read",
    },
    {
      id: "m2",
      content: "Olá! Podemos ajudar com o transporte. Quantos móveis você precisa transportar?",
      sender: "other",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2 + 1000 * 60 * 30),
    },
    {
      id: "m3",
      content: "São 3 móveis grandes: um sofá, uma cama e um armário",
      sender: "user",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24),
      status: "read",
    },
    {
      id: "m4",
      content: "Perfeito. O serviço foi realizado com sucesso. Obrigado pela preferência!",
      sender: "other",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 3),
    },
  ],
  "3": [
    {
      id: "m1",
      content: "Olá, estou com dúvidas sobre como funciona o sistema de pontos",
      sender: "user",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3),
      status: "read",
    },
    {
      id: "m2",
      content:
        "Olá! O sistema de pontos funciona da seguinte forma: a cada serviço contratado pelo aplicativo, você ganha 5 pontos. Cada 5 pontos equivalem a R$ 5,00 de desconto em serviços futuros. Os pontos são acumulativos até o limite de 50 reais (50 pontos).",
      sender: "other",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3 + 1000 * 60 * 30),
    },
    {
      id: "m3",
      content: "Entendi. E como faço para utilizar esses pontos?",
      sender: "user",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2),
      status: "read",
    },
    {
      id: "m4",
      content:
        "Para utilizar os pontos, basta selecionar a opção 'Usar Pontos' na hora de finalizar um serviço com valor mínimo de R$ 101,00. Os pontos serão automaticamente descontados do valor total.",
      sender: "other",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24),
    },
    {
      id: "m5",
      content: "Perfeito! Obrigado pela explicação.",
      sender: "user",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 - 1000 * 60 * 30),
      status: "read",
    },
    {
      id: "m6",
      content: "Estamos sempre à disposição para ajudar. Tem mais alguma dúvida?",
      sender: "other",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24),
    },
  ],
}

export default function MensagensCliente() {
  const [contacts, setContacts] = useState<ChatContact[]>(mockContacts)
  const [activeContactId, setActiveContactId] = useState<string | undefined>(mockContacts[0]?.id)
  const [messages, setMessages] = useState<Record<string, Message[]>>(mockMessages)
  const [isOrçamentoModalOpen, setIsOrçamentoModalOpen] = useState(false)
  const [isFinalizarModalOpen, setIsFinalizarModalOpen] = useState(false)

  const activeContact = contacts.find((contact) => contact.id === activeContactId)
  const activeMessages = activeContactId ? messages[activeContactId] || [] : []

  const handleSendMessage = (content: string) => {
    if (!activeContactId) return

    const newMessage: Message = {
      id: uuidv4(),
      content,
      sender: "user",
      timestamp: new Date(),
      status: "sent",
    }

    setMessages((prev) => ({
      ...prev,
      [activeContactId]: [...(prev[activeContactId] || []), newMessage],
    }))

    // Atualizar o último contato com a última mensagem
    setContacts((prev) =>
      prev.map((contact) =>
        contact.id === activeContactId
          ? {
              ...contact,
              lastMessage: content,
              timestamp: new Date(),
              unreadCount: 0,
            }
          : contact,
      ),
    )

    // Simular resposta após 1-3 segundos
    if (activeContactId !== "3") {
      // Não simular resposta automática para o suporte
      setTimeout(
        () => {
          const responseMessages = [
            "Entendi, vou verificar e retorno em breve.",
            "Claro, podemos ajudar com isso!",
            "Vou verificar a disponibilidade e te aviso.",
            "Obrigado pela mensagem. Podemos agendar uma visita para avaliar melhor.",
          ]

          const randomResponse = responseMessages[Math.floor(Math.random() * responseMessages.length)]

          const responseMessage: Message = {
            id: uuidv4(),
            content: randomResponse,
            sender: "other",
            timestamp: new Date(),
          }

          setMessages((prev) => ({
            ...prev,
            [activeContactId]: [...(prev[activeContactId] || []), responseMessage],
          }))

          // Atualizar o contato com a resposta
          setContacts((prev) =>
            prev.map((contact) =>
              contact.id === activeContactId
                ? {
                    ...contact,
                    lastMessage: randomResponse,
                    timestamp: new Date(),
                  }
                : contact,
            ),
          )
        },
        1000 + Math.random() * 2000,
      )
    }
  }

  const handleAttachFile = (file: File) => {
    if (!activeContactId) return

    // Simular upload de arquivo
    toast({
      title: "Enviando arquivo",
      description: `Enviando ${file.name}...`,
    })

    setTimeout(() => {
      const newMessage: Message = {
        id: uuidv4(),
        content: `Arquivo: ${file.name}`,
        sender: "user",
        timestamp: new Date(),
        status: "sent",
        attachment: {
          type: file.type.startsWith("image/") ? "image" : "file",
          url: file.type.startsWith("image/") ? "/placeholder.svg?height=200&width=300" : "#",
          name: file.name,
        },
      }

      setMessages((prev) => ({
        ...prev,
        [activeContactId]: [...(prev[activeContactId] || []), newMessage],
      }))

      toast({
        title: "Arquivo enviado",
        description: `${file.name} enviado com sucesso!`,
      })
    }, 1500)
  }

  const handleOrçamentoSubmit = (data: OrçamentoData) => {
    if (!activeContactId || !activeContact) return

    setIsOrçamentoModalOpen(false)

    const message = `Solicitação de Orçamento:
Serviço: ${data.descricao}
Endereço: ${data.endereco}
Data: ${data.data}
${data.valor ? `Valor Estimado: R$ ${data.valor}` : ""}`

    // Enviar mensagem com a solicitação de orçamento
    handleSendMessage(message)

    toast({
      title: "Orçamento solicitado",
      description: `Sua solicitação de orçamento foi enviada para ${activeContact.name}.`,
    })
  }

  const handleFinalizarSubmit = (data: FinalizarServicoData) => {
    if (!activeContactId || !activeContact) return

    setIsFinalizarModalOpen(false)

    // Enviar mensagem de finalização
    const message = `Serviço finalizado com avaliação de ${data.avaliacao} estrelas.
${data.comentario ? `Comentário: ${data.comentario}` : ""}
Método de pagamento: ${data.metodoPagamento === "app" ? "Pelo aplicativo" : "Externo"}`

    handleSendMessage(message)

    // Adicionar pontos se pagamento for pelo app
    if (data.metodoPagamento === "app") {
      toast({
        title: "Serviço finalizado",
        description: `Você ganhou 5 pontos por finalizar o serviço pelo aplicativo!`,
      })
    } else {
      toast({
        title: "Serviço finalizado",
        description: `O serviço com ${activeContact.name} foi finalizado com sucesso.`,
      })
    }
  }

  // Marcar mensagens como lidas quando mudar de contato
  useEffect(() => {
    if (activeContactId) {
      setContacts((prev) =>
        prev.map((contact) =>
          contact.id === activeContactId && contact.unreadCount ? { ...contact, unreadCount: 0 } : contact,
        ),
      )
    }
  }, [activeContactId])

  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />

      <div className="flex-grow bg-background py-8">
        <div className="caldas-container">
          <div className="mb-6">
            <h1 className="text-2xl font-bold">Mensagens</h1>
            <p className="text-gray-600">Gerencie suas conversas com prestadores de serviços</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-[350px_1fr] gap-6 h-[calc(100vh-250px)]">
            <ChatList
              contacts={contacts}
              activeContactId={activeContactId}
              onSelectContact={setActiveContactId}
              className="bg-white"
            />

            {activeContactId && activeContact ? (
              <ChatWindow
                title={activeContact.name}
                recipient={{
                  name: activeContact.name,
                  avatar: activeContact.avatar,
                  online: activeContact.online,
                }}
                messages={activeMessages}
                onSendMessage={handleSendMessage}
                onAttachFile={handleAttachFile}
                showOrçamentoButton={activeContact.type === "provider"}
                onOrçamentoClick={() => setIsOrçamentoModalOpen(true)}
                showFinalizarButton={activeContact.type === "provider"}
                onFinalizarClick={() => setIsFinalizarModalOpen(true)}
              />
            ) : (
              <div className="flex items-center justify-center h-full bg-white rounded-lg border">
                <div className="text-center p-6">
                  <h3 className="text-lg font-medium text-gray-900">Nenhuma conversa selecionada</h3>
                  <p className="mt-2 text-sm text-gray-500">Selecione uma conversa para começar a enviar mensagens.</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {activeContact && (
        <>
          <OrçamentoModal
            isOpen={isOrçamentoModalOpen}
            onClose={() => setIsOrçamentoModalOpen(false)}
            onSubmit={handleOrçamentoSubmit}
            prestadorName={activeContact.name}
          />

          <FinalizarServicoModal
            isOpen={isFinalizarModalOpen}
            onClose={() => setIsFinalizarModalOpen(false)}
            onSubmit={handleFinalizarSubmit}
            prestadorName={activeContact.name}
            servicoInfo={`Serviço com ${activeContact.name}`}
          />
        </>
      )}
    </main>
  )
}
