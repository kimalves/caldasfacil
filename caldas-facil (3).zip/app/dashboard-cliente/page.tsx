"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import Navbar from "@/components/navbar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Star, MessageSquare, Settings, User, FileText, Home, Clock } from "lucide-react"
import { SearchBar } from "@/components/search-bar"

export default function DashboardCliente() {
  const [activeTab, setActiveTab] = useState("servicos")

  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />

      <div className="flex-grow bg-background py-8">
        <div className="caldas-container">
          <div className="grid grid-cols-1 md:grid-cols-[250px_1fr] gap-8">
            {/* Sidebar */}
            <div className="space-y-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex flex-col items-center">
                    <div className="relative w-24 h-24 rounded-full overflow-hidden mb-4 mt-2">
                      <Image src="/placeholder.svg?height=96&width=96" alt="Perfil" fill className="object-cover" />
                    </div>
                    <h2 className="text-xl font-semibold">Ana Souza</h2>
                    <p className="text-sm text-gray-500">Cliente desde 2025</p>
                    <div className="flex items-center mt-1">
                      <Star className="h-4 w-4 text-yellow-500 mr-1" />
                      <span className="text-sm">25 pontos</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="space-y-2">
                <Link href="/dashboard-cliente">
                  <Button variant="ghost" className="w-full justify-start">
                    <Home className="mr-2 h-5 w-5" />
                    Dashboard
                  </Button>
                </Link>
                <Link href="/dashboard-cliente/servicos">
                  <Button variant="ghost" className="w-full justify-start">
                    <FileText className="mr-2 h-5 w-5" />
                    Meus Serviços
                  </Button>
                </Link>
                <Link href="/dashboard-cliente/mensagens">
                  <Button variant="ghost" className="w-full justify-start">
                    <MessageSquare className="mr-2 h-5 w-5" />
                    Mensagens
                  </Button>
                </Link>
                <Link href="/dashboard-cliente/perfil">
                  <Button variant="ghost" className="w-full justify-start">
                    <User className="mr-2 h-5 w-5" />
                    Meu Perfil
                  </Button>
                </Link>
                <Link href="/dashboard-cliente/configuracoes">
                  <Button variant="ghost" className="w-full justify-start">
                    <Settings className="mr-2 h-5 w-5" />
                    Configurações
                  </Button>
                </Link>
              </div>

              <Card>
                <CardContent className="p-4">
                  <h3 className="font-medium mb-2">Seus Pontos</h3>
                  <div className="bg-secondary/10 p-3 rounded-md">
                    <p className="font-medium text-secondary">25 pontos</p>
                    <p className="text-sm text-gray-500">Equivalente a R$ 25,00</p>
                    <Button size="sm" className="mt-2 w-full bg-secondary hover:bg-secondary-dark">
                      Usar Pontos
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Main Content */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Dashboard do Cliente</CardTitle>
                  <CardDescription>Encontre prestadores de serviços e gerencie seus pedidos</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card>
                      <CardContent className="p-4 flex flex-col items-center">
                        <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-2">
                          <FileText className="h-6 w-6 text-blue-600" />
                        </div>
                        <h3 className="font-medium">Serviços</h3>
                        <p className="text-2xl font-bold">5</p>
                        <p className="text-sm text-gray-500">Serviços contratados</p>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardContent className="p-4 flex flex-col items-center">
                        <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-2">
                          <MessageSquare className="h-6 w-6 text-green-600" />
                        </div>
                        <h3 className="font-medium">Mensagens</h3>
                        <p className="text-2xl font-bold">3</p>
                        <p className="text-sm text-gray-500">Novas mensagens</p>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardContent className="p-4 flex flex-col items-center">
                        <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mb-2">
                          <Star className="h-6 w-6 text-yellow-600" />
                        </div>
                        <h3 className="font-medium">Pontos</h3>
                        <p className="text-2xl font-bold">25</p>
                        <p className="text-sm text-gray-500">Pontos acumulados</p>
                      </CardContent>
                    </Card>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Buscar Serviços</CardTitle>
                  <CardDescription>Encontre os melhores prestadores de serviços</CardDescription>
                </CardHeader>
                <CardContent>
                  <SearchBar />
                </CardContent>
              </Card>

              <Tabs defaultValue="servicos" onValueChange={setActiveTab}>
                <TabsList className="grid grid-cols-2">
                  <TabsTrigger value="servicos">Serviços Contratados</TabsTrigger>
                  <TabsTrigger value="historico">Histórico</TabsTrigger>
                </TabsList>

                <TabsContent value="servicos" className="mt-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>Serviços em Andamento</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="border rounded-md p-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-medium">Jardinagem Completa</h3>
                              <p className="text-sm text-gray-600">Silva Jardinagem</p>
                              <div className="flex items-center mt-1">
                                <Clock className="h-4 w-4 text-orange-500 mr-1" />
                                <span className="text-sm text-orange-500">Em andamento</span>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="font-medium">R$ 150,00</p>
                              <p className="text-sm text-gray-500">12/05/2025</p>
                            </div>
                          </div>
                          <div className="mt-4 flex space-x-2">
                            <Button size="sm" variant="outline">
                              Ver Detalhes
                            </Button>
                            <Button size="sm" className="bg-primary hover:bg-primary-dark">
                              Mensagem
                            </Button>
                          </div>
                        </div>

                        <div className="border rounded-md p-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-medium">Instalação de Suporte para TV</h3>
                              <p className="text-sm text-gray-600">Montagem Profissional</p>
                              <div className="flex items-center mt-1">
                                <Clock className="h-4 w-4 text-orange-500 mr-1" />
                                <span className="text-sm text-orange-500">Agendado</span>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="font-medium">R$ 120,00</p>
                              <p className="text-sm text-gray-500">15/05/2025</p>
                            </div>
                          </div>
                          <div className="mt-4 flex space-x-2">
                            <Button size="sm" variant="outline">
                              Ver Detalhes
                            </Button>
                            <Button size="sm" className="bg-primary hover:bg-primary-dark">
                              Mensagem
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="historico" className="mt-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>Histórico de Serviços</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="border rounded-md p-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-medium">Formatação de Computador</h3>
                              <p className="text-sm text-gray-600">TechSupport</p>
                              <div className="flex items-center mt-1">
                                <Star className="h-4 w-4 text-green-500 mr-1" />
                                <span className="text-sm text-green-500">Concluído</span>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="font-medium">R$ 100,00</p>
                              <p className="text-sm text-gray-500">01/05/2025</p>
                            </div>
                          </div>
                          <div className="mt-2">
                            <div className="flex">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <Star
                                  key={star}
                                  className={`h-4 w-4 ${star <= 5 ? "text-yellow-500" : "text-gray-300"}`}
                                  fill={star <= 5 ? "currentColor" : "none"}
                                />
                              ))}
                            </div>
                            <p className="text-sm text-gray-600 mt-1">Serviço excelente, rápido e eficiente!</p>
                          </div>
                          <div className="mt-4 flex space-x-2">
                            <Button size="sm" variant="outline">
                              Ver Detalhes
                            </Button>
                            <Button size="sm" className="bg-secondary hover:bg-secondary-dark">
                              Contratar Novamente
                            </Button>
                          </div>
                        </div>

                        <div className="border rounded-md p-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-medium">Transporte de Móveis</h3>
                              <p className="text-sm text-gray-600">Transportes Rápidos</p>
                              <div className="flex items-center mt-1">
                                <Star className="h-4 w-4 text-green-500 mr-1" />
                                <span className="text-sm text-green-500">Concluído</span>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="font-medium">R$ 200,00</p>
                              <p className="text-sm text-gray-500">20/04/2025</p>
                            </div>
                          </div>
                          <div className="mt-2">
                            <div className="flex">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <Star
                                  key={star}
                                  className={`h-4 w-4 ${star <= 4 ? "text-yellow-500" : "text-gray-300"}`}
                                  fill={star <= 4 ? "currentColor" : "none"}
                                />
                              ))}
                            </div>
                            <p className="text-sm text-gray-600 mt-1">Bom serviço, mas atrasou um pouco.</p>
                          </div>
                          <div className="mt-4 flex space-x-2">
                            <Button size="sm" variant="outline">
                              Ver Detalhes
                            </Button>
                            <Button size="sm" className="bg-secondary hover:bg-secondary-dark">
                              Contratar Novamente
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>

              <Card>
                <CardHeader>
                  <CardTitle>Prestadores Recomendados</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Link href="/prestador/1">
                      <Card className="h-full hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-center">
                            <div className="relative w-12 h-12 rounded-full overflow-hidden mr-3">
                              <Image
                                src="/placeholder.svg?height=48&width=48"
                                alt="Prestador"
                                fill
                                className="object-cover"
                              />
                            </div>
                            <div>
                              <h3 className="font-medium">Silva Jardinagem</h3>
                              <p className="text-sm text-gray-500">Paisagismo e Jardinagem</p>
                              <div className="flex items-center mt-1">
                                <Star className="h-3 w-3 text-yellow-500 mr-1" />
                                <span className="text-xs">4.8</span>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </Link>

                    <Link href="/prestador/2">
                      <Card className="h-full hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-center">
                            <div className="relative w-12 h-12 rounded-full overflow-hidden mr-3">
                              <Image
                                src="/placeholder.svg?height=48&width=48"
                                alt="Prestador"
                                fill
                                className="object-cover"
                              />
                            </div>
                            <div>
                              <h3 className="font-medium">Hidráulica Express</h3>
                              <p className="text-sm text-gray-500">Serviços de Hidráulica</p>
                              <div className="flex items-center mt-1">
                                <Star className="h-3 w-3 text-yellow-500 mr-1" />
                                <span className="text-xs">4.6</span>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
