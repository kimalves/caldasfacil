"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import {
  Settings,
  Users,
  ShoppingBag,
  MessageSquare,
  BarChart2,
  Edit3,
  Eye,
  LogOut,
  Bell,
  Database,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"

export default function AdminPanelPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [editModeEnabled, setEditModeEnabled] = useState(false)
  const [maintenanceMode, setMaintenanceMode] = useState(false)
  const [notificationsEnabled, setNotificationsEnabled] = useState(true)
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    // Verificar autenticação
    const adminAuth = localStorage.getItem("adminAuthenticated") === "true"
    setIsAuthenticated(adminAuth)
    setIsLoading(false)

    if (!adminAuth) {
      router.push("/admin-login")
    }
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("adminAuthenticated")
    document.cookie = "adminAuthenticated=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;"
    router.push("/admin-login")
  }

  const toggleEditMode = () => {
    setEditModeEnabled(!editModeEnabled)
    toast({
      title: editModeEnabled ? "Modo de edição desativado" : "Modo de edição ativado",
      description: editModeEnabled ? "O site voltou ao modo normal." : "Agora você pode editar o conteúdo do site.",
      variant: "default",
    })
  }

  const toggleMaintenanceMode = () => {
    setMaintenanceMode(!maintenanceMode)
    toast({
      title: maintenanceMode ? "Modo de manutenção desativado" : "Modo de manutenção ativado",
      description: maintenanceMode
        ? "O site está acessível para todos os usuários."
        : "O site está em modo de manutenção. Apenas administradores podem acessá-lo.",
      variant: "default",
    })
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (!isAuthenticated) {
    return null
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Painel Administrativo</h1>
        <Button variant="outline" onClick={handleLogout}>
          <LogOut className="mr-2 h-4 w-4" /> Sair
        </Button>
      </div>

      <Tabs defaultValue="geral">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="geral">Geral</TabsTrigger>
          <TabsTrigger value="usuarios">Usuários</TabsTrigger>
          <TabsTrigger value="servicos">Serviços</TabsTrigger>
          <TabsTrigger value="mensagens">Mensagens</TabsTrigger>
          <TabsTrigger value="estatisticas">Estatísticas</TabsTrigger>
        </TabsList>

        <TabsContent value="geral" className="mt-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Modo de Edição</CardTitle>
                <CardDescription>Ative para editar o conteúdo do site em tempo real</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-2">
                  <Switch id="edit-mode" checked={editModeEnabled} onCheckedChange={toggleEditMode} />
                  <Label htmlFor="edit-mode">
                    {editModeEnabled ? (
                      <span className="flex items-center text-green-600">
                        <Edit3 className="mr-2 h-4 w-4" /> Ativado
                      </span>
                    ) : (
                      <span className="flex items-center text-gray-500">
                        <Eye className="mr-2 h-4 w-4" /> Desativado
                      </span>
                    )}
                  </Label>
                </div>
              </CardContent>
              <CardFooter>
                <Button
                  variant={editModeEnabled ? "default" : "outline"}
                  onClick={() => router.push("/editor")}
                  className="w-full"
                >
                  Ir para o Editor
                </Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Modo de Manutenção</CardTitle>
                <CardDescription>Ative para bloquear o acesso ao site durante manutenções</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-2">
                  <Switch id="maintenance-mode" checked={maintenanceMode} onCheckedChange={toggleMaintenanceMode} />
                  <Label htmlFor="maintenance-mode">
                    {maintenanceMode ? (
                      <span className="flex items-center text-amber-600">
                        <Settings className="mr-2 h-4 w-4" /> Ativado
                      </span>
                    ) : (
                      <span className="flex items-center text-gray-500">
                        <Eye className="mr-2 h-4 w-4" /> Desativado
                      </span>
                    )}
                  </Label>
                </div>
              </CardContent>
              <CardFooter>
                <p className="text-sm text-gray-500">
                  {maintenanceMode
                    ? "O site está em manutenção. Apenas administradores podem acessá-lo."
                    : "O site está acessível para todos os usuários."}
                </p>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Notificações</CardTitle>
                <CardDescription>Gerencie as notificações do sistema</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-2">
                  <Switch id="notifications" checked={notificationsEnabled} onCheckedChange={setNotificationsEnabled} />
                  <Label htmlFor="notifications">
                    {notificationsEnabled ? (
                      <span className="flex items-center text-blue-600">
                        <Bell className="mr-2 h-4 w-4" /> Ativadas
                      </span>
                    ) : (
                      <span className="flex items-center text-gray-500">
                        <Bell className="mr-2 h-4 w-4" /> Desativadas
                      </span>
                    )}
                  </Label>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" onClick={() => router.push("/admin-panel/notificacoes")}>
                  Configurar Notificações
                </Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Banco de Dados</CardTitle>
                <CardDescription>Gerencie o banco de dados do sistema</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-2">
                  <Database className="h-5 w-5 text-primary" />
                  <span>Supabase</span>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" onClick={() => router.push("/admin-panel/database")}>
                  Gerenciar Banco de Dados
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="usuarios" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Gerenciamento de Usuários</CardTitle>
              <CardDescription>Gerencie os usuários do sistema</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center p-8">
                <Users className="h-16 w-16 text-gray-300" />
              </div>
              <p className="text-center text-gray-500">Funcionalidade em desenvolvimento</p>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline">Ver Clientes</Button>
              <Button variant="outline">Ver Prestadores</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="servicos" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Gerenciamento de Serviços</CardTitle>
              <CardDescription>Gerencie os serviços oferecidos na plataforma</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center p-8">
                <ShoppingBag className="h-16 w-16 text-gray-300" />
              </div>
              <p className="text-center text-gray-500">Funcionalidade em desenvolvimento</p>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline">Categorias</Button>
              <Button variant="outline">Serviços</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="mensagens" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Gerenciamento de Mensagens</CardTitle>
              <CardDescription>Gerencie as mensagens e chats do sistema</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center p-8">
                <MessageSquare className="h-16 w-16 text-gray-300" />
              </div>
              <p className="text-center text-gray-500">Funcionalidade em desenvolvimento</p>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline">Chat de Ajuda</Button>
              <Button variant="outline">Mensagens</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="estatisticas" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Estatísticas</CardTitle>
              <CardDescription>Visualize estatísticas e métricas do sistema</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center p-8">
                <BarChart2 className="h-16 w-16 text-gray-300" />
              </div>
              <p className="text-center text-gray-500">Funcionalidade em desenvolvimento</p>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                Ver Relatórios
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
