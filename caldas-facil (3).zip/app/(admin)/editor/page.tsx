"use client"

import { useState } from "react"
import Navbar from "@/components/navbar"
import { EditorProvider } from "@/components/admin/page-builder/editor-context"
import { EditorControls } from "@/components/admin/page-builder/editor-controls"
import { EditableSection } from "@/components/admin/page-builder/editable-section"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Footer } from "@/components/footer"

export default function EditorPage() {
  const [previewMode, setPreviewMode] = useState<"desktop" | "mobile">("desktop")

  return (
    <EditorProvider>
      <main className="min-h-screen flex flex-col">
        <Navbar />

        <div className="bg-gray-100 p-4 border-b">
          <div className="max-w-7xl mx-auto flex justify-between items-center">
            <h1 className="text-xl font-bold">Editor de Layout</h1>
            <div className="flex space-x-2">
              <Button
                variant={previewMode === "desktop" ? "default" : "outline"}
                size="sm"
                onClick={() => setPreviewMode("desktop")}
              >
                Desktop
              </Button>
              <Button
                variant={previewMode === "mobile" ? "default" : "outline"}
                size="sm"
                onClick={() => setPreviewMode("mobile")}
              >
                Mobile
              </Button>
            </div>
          </div>
        </div>

        <div className="flex-grow bg-gray-200 p-8">
          <div
            className={`mx-auto bg-white shadow-lg transition-all ${
              previewMode === "mobile" ? "max-w-sm" : "max-w-7xl"
            }`}
          >
            <div className="min-h-[calc(100vh-16rem)]">
              <EditableSection id="hero" className="bg-primary-50 py-16 px-8">
                <div className="max-w-3xl mx-auto text-center">
                  <h1 className="text-4xl font-bold text-gray-900 mb-4">
                    Encontre os melhores profissionais para seus serviços
                  </h1>
                  <p className="text-xl text-gray-600 mb-8">
                    Conectamos você aos melhores prestadores de serviço da sua região
                  </p>
                  <div className="flex flex-col sm:flex-row justify-center gap-4">
                    <Button size="lg">Encontrar Serviços</Button>
                    <Button variant="outline" size="lg">
                      Seja um Prestador
                    </Button>
                  </div>
                </div>
              </EditableSection>

              <EditableSection id="search" className="py-12 px-8 bg-white">
                <div className="max-w-3xl mx-auto">
                  <div className="bg-white rounded-lg shadow-md p-6">
                    <h2 className="text-2xl font-bold text-center mb-6">O que você precisa?</h2>
                    <div className="flex flex-col md:flex-row gap-4">
                      <div className="flex-grow">
                        <Label htmlFor="service">Serviço</Label>
                        <Input id="service" placeholder="Ex: Eletricista, Encanador..." />
                      </div>
                      <div className="flex-grow">
                        <Label htmlFor="location">Localização</Label>
                        <Input id="location" placeholder="Sua cidade" />
                      </div>
                      <div className="flex items-end">
                        <Button className="w-full md:w-auto">Buscar</Button>
                      </div>
                    </div>
                  </div>
                </div>
              </EditableSection>

              <EditableSection id="categories" className="py-16 px-8 bg-gray-50">
                <div className="max-w-7xl mx-auto">
                  <h2 className="text-3xl font-bold text-center mb-12">Categorias Populares</h2>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                    {["Eletricista", "Encanador", "Diarista", "Pintor"].map((category) => (
                      <Card key={category} className="text-center hover:shadow-md transition-shadow">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-xl">{category}</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-gray-500">Profissionais verificados</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </EditableSection>

              <EditableSection id="features" className="py-16 px-8 bg-white">
                <div className="max-w-7xl mx-auto">
                  <h2 className="text-3xl font-bold text-center mb-12">Por que escolher o Caldas Fácil?</h2>
                  <div className="grid md:grid-cols-3 gap-8">
                    <Card>
                      <CardHeader>
                        <CardTitle>Profissionais Verificados</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <CardDescription>
                          Todos os prestadores passam por um processo de verificação para garantir qualidade e
                          segurança.
                        </CardDescription>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardHeader>
                        <CardTitle>Pagamento Seguro</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <CardDescription>
                          Realize pagamentos com segurança através da nossa plataforma protegida.
                        </CardDescription>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardHeader>
                        <CardTitle>Avaliações Reais</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <CardDescription>
                          Veja avaliações de outros clientes para escolher o melhor profissional para seu serviço.
                        </CardDescription>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </EditableSection>

              <EditableSection id="testimonials" className="py-16 px-8 bg-gray-50">
                <div className="max-w-5xl mx-auto">
                  <h2 className="text-3xl font-bold text-center mb-12">O que nossos clientes dizem</h2>
                  <div className="grid md:grid-cols-2 gap-8">
                    <Card>
                      <CardContent className="pt-6">
                        <p className="italic mb-4">
                          "Encontrei um ótimo eletricista que resolveu meu problema em menos de uma hora. Recomendo!"
                        </p>
                        <p className="font-medium">Maria Silva</p>
                        <p className="text-sm text-gray-500">Cliente desde 2023</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="pt-6">
                        <p className="italic mb-4">
                          "Como prestador, consegui aumentar minha clientela em mais de 30% desde que me cadastrei na
                          plataforma."
                        </p>
                        <p className="font-medium">João Oliveira</p>
                        <p className="text-sm text-gray-500">Prestador desde 2023</p>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </EditableSection>

              <EditableSection id="cta" className="py-16 px-8 bg-primary-50">
                <div className="max-w-3xl mx-auto text-center">
                  <h2 className="text-3xl font-bold mb-4">Pronto para começar?</h2>
                  <p className="text-xl text-gray-600 mb-8">
                    Cadastre-se agora e encontre os melhores profissionais para seus serviços
                  </p>
                  <div className="flex flex-col sm:flex-row justify-center gap-4">
                    <Button size="lg">Cadastre-se Grátis</Button>
                    <Button variant="outline" size="lg">
                      Saiba Mais
                    </Button>
                  </div>
                </div>
              </EditableSection>
            </div>

            <Footer />
          </div>
        </div>

        <EditorControls />
      </main>
    </EditorProvider>
  )
}
