"use client"

import { useState, useEffect } from "react"
import { supabase } from "@/lib/supabase-client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function TesteConexao() {
  const [status, setStatus] = useState<"loading" | "success" | "error">("loading")
  const [tables, setTables] = useState<string[]>([])
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function testConnection() {
      try {
        // Testar conexão com o Supabase
        const { data, error } = await supabase.from("usuarios").select("count").limit(1)

        if (error) throw error

        // Listar tabelas disponíveis
        const { data: tableData, error: tableError } = await supabase
          .from("pg_catalog.pg_tables")
          .select("tablename")
          .eq("schemaname", "public")

        if (tableError) throw tableError

        setTables(tableData.map((t: any) => t.tablename).sort())
        setStatus("success")
      } catch (err: any) {
        console.error("Erro ao testar conexão:", err)
        setError(err.message || "Erro desconhecido ao conectar com o Supabase")
        setStatus("error")
      }
    }

    testConnection()
  }, [])

  return (
    <div className="container mx-auto py-12">
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>Teste de Conexão com o Supabase</CardTitle>
          <CardDescription>
            Verificando a conexão com o banco de dados e listando as tabelas disponíveis
          </CardDescription>
        </CardHeader>

        <CardContent>
          {status === "loading" && (
            <div className="flex items-center justify-center p-8">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
            </div>
          )}

          {status === "error" && (
            <div className="bg-red-50 border border-red-200 rounded-md p-4 text-red-700">
              <h3 className="font-semibold mb-2">Erro de conexão</h3>
              <p>{error}</p>
              <div className="mt-4">
                <h4 className="font-medium mb-2">Possíveis soluções:</h4>
                <ul className="list-disc pl-5 space-y-1">
                  <li>
                    Verifique se as variáveis de ambiente NEXT_PUBLIC_SUPABASE_URL e NEXT_PUBLIC_SUPABASE_ANON_KEY estão
                    configuradas corretamente
                  </li>
                  <li>Verifique se o projeto Supabase está ativo</li>
                  <li>Verifique se as políticas de segurança (RLS) estão configuradas corretamente</li>
                </ul>
              </div>
            </div>
          )}

          {status === "success" && (
            <div>
              <div className="bg-green-50 border border-green-200 rounded-md p-4 text-green-700 mb-6">
                <p className="font-medium">✅ Conexão estabelecida com sucesso!</p>
              </div>

              <h3 className="font-medium mb-3">Tabelas disponíveis:</h3>
              {tables.length === 0 ? (
                <p className="text-amber-600">Nenhuma tabela encontrada. Execute o script SQL para criar as tabelas.</p>
              ) : (
                <ul className="grid grid-cols-2 gap-2">
                  {tables.map((table) => (
                    <li key={table} className="bg-gray-100 px-3 py-2 rounded text-sm">
                      {table}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}
        </CardContent>

        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={() => (window.location.href = "/")}>
            Voltar para o início
          </Button>

          {status === "success" && (
            <Button onClick={() => (window.location.href = "/api/init")}>Inicializar Sistema</Button>
          )}
        </CardFooter>
      </Card>
    </div>
  )
}
