"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import Navbar from "@/components/navbar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Star, Upload, MessageSquare, Settings, User, FileText, Home } from "lucide-react"
import { toast } from "@/hooks/use-toast"

export default function DashboardPrestador() {
  const [profileData, setProfileData] = useState({
    nomeEmpresa: "Silva Jardinagem",
    servico: "Paisagismo e Jardinagem",
    telefone: "(XX) XXXXX-XXXX",
    email: "contato@silvajardinagem.com.br",
    site: "www.silvajardinagem.com.br",
    descricao:
      "Oferecemos serviços completos de jardinagem e paisagismo para residências e empresas. Trabalhamos com plantio, poda, manutenção e projetos personalizados.",
  })

  const [isUploading, setIsUploading] = useState(false)
  const [uploadedImages, setUploadedImages] = useState<string[]>([
    "/placeholder.svg?height=200&width=300",
    "/placeholder.svg?height=200&width=300",
  ])

  const handleProfileChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setProfileData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSaveProfile = () => {
    toast({
      title: "Perfil atualizado",
      description: "Suas informações foram atualizadas com sucesso.",
    })
  }

  const handleImageUpload = () => {
    setIsUploading(true)

    // Simulação de upload
    setTimeout(() => {
      setUploadedImages((prev) => [...prev, "/placeholder.svg?height=200&width=300"].slice(0, 3)) // Máximo de 3 imagens

      setIsUploading(false)

      toast({
        title: "Imagem enviada",
        description: "Sua imagem foi enviada com sucesso.",
      })
    }, 1500)
  }

  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />

      <div className="flex-grow bg-background py-8">
        <div className="caldas-container">
          <div className="grid grid-cols-1 md:grid-cols-[250px_1fr] gap-8">
            {/* Sidebar */}
            <div className="space-y-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex flex-col items-center">
                    <div className="relative w-24 h-24 rounded-full overflow-hidden mb-4 mt-2">
                      <Image src="/placeholder.svg?height=96&width=96" alt="Perfil" fill className="object-cover" />
                    </div>
                    <h2 className="text-xl font-semibold">João Silva</h2>
                    <p className="text-sm text-gray-500">{profileData.nomeEmpresa}</p>
                    <div className="flex items-center mt-1">
                      <Star className="h-4 w-4 text-yellow-500 mr-1" />
                      <span className="text-sm">4.8</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="space-y-2">
                <Link href="/dashboard-prestador">
                  <Button variant="ghost" className="w-full justify-start">
                    <Home className="mr-2 h-5 w-5" />
                    Dashboard
                  </Button>
                </Link>
                <Link href="/dashboard-prestador/perfil">
                  <Button variant="ghost" className="w-full justify-start">
                    <User className="mr-2 h-5 w-5" />
                    Meu Perfil
                  </Button>
                </Link>
                <Link href="/dashboard-prestador/servicos">
                  <Button variant="ghost" className="w-full justify-start">
                    <FileText className="mr-2 h-5 w-5" />
                    Meus Serviços
                  </Button>
                </Link>
                <Link href="/dashboard-prestador/mensagens">
                  <Button variant="ghost" className="w-full justify-start">
                    <MessageSquare className="mr-2 h-5 w-5" />
                    Mensagens
                  </Button>
                </Link>
                <Link href="/dashboard-prestador/configuracoes">
                  <Button variant="ghost" className="w-full justify-start">
                    <Settings className="mr-2 h-5 w-5" />
                    Configurações
                  </Button>
                </Link>
              </div>

              <Card>
                <CardContent className="p-4">
                  <h3 className="font-medium mb-2">Seu Plano</h3>
                  <div className="bg-primary/10 p-3 rounded-md">
                    <p className="font-medium text-primary">Plano Básico</p>
                    <p className="text-sm text-gray-500">Válido até: 15/06/2025</p>
                    <Button size="sm" className="mt-2 w-full bg-primary hover:bg-primary-dark">
                      Upgrade
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Main Content */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Dashboard do Prestador</CardTitle>
                  <CardDescription>Gerencie seu perfil, serviços e mensagens</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card>
                      <CardContent className="p-4 flex flex-col items-center">
                        <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-2">
                          <FileText className="h-6 w-6 text-blue-600" />
                        </div>
                        <h3 className="font-medium">Serviços</h3>
                        <p className="text-2xl font-bold">12</p>
                        <p className="text-sm text-gray-500">Total de serviços</p>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardContent className="p-4 flex flex-col items-center">
                        <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-2">
                          <MessageSquare className="h-6 w-6 text-green-600" />
                        </div>
                        <h3 className="font-medium">Mensagens</h3>
                        <p className="text-2xl font-bold">5</p>
                        <p className="text-sm text-gray-500">Novas mensagens</p>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardContent className="p-4 flex flex-col items-center">
                        <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mb-2">
                          <Star className="h-6 w-6 text-yellow-600" />
                        </div>
                        <h3 className="font-medium">Avaliações</h3>
                        <p className="text-2xl font-bold">4.8</p>
                        <p className="text-sm text-gray-500">Média de avaliações</p>
                      </CardContent>
                    </Card>
                  </div>
                </CardContent>
              </Card>

              <Tabs defaultValue="perfil">
                <TabsList className="grid grid-cols-2">
                  <TabsTrigger value="perfil">Meu Perfil</TabsTrigger>
                  <TabsTrigger value="fotos">Minhas Fotos</TabsTrigger>
                </TabsList>

                <TabsContent value="perfil" className="mt-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>Informações do Perfil</CardTitle>
                      <CardDescription>Atualize as informações do seu perfil</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="nomeEmpresa">Nome da Empresa</Label>
                            <Input
                              id="nomeEmpresa"
                              name="nomeEmpresa"
                              value={profileData.nomeEmpresa}
                              onChange={handleProfileChange}
                            />
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="servico">Serviço Principal</Label>
                            <Input
                              id="servico"
                              name="servico"
                              value={profileData.servico}
                              onChange={handleProfileChange}
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="telefone">Telefone</Label>
                            <Input
                              id="telefone"
                              name="telefone"
                              value={profileData.telefone}
                              onChange={handleProfileChange}
                            />
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="email">E-mail</Label>
                            <Input id="email" name="email" value={profileData.email} onChange={handleProfileChange} />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="site">Site</Label>
                          <Input id="site" name="site" value={profileData.site} onChange={handleProfileChange} />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="descricao">Descrição</Label>
                          <Textarea
                            id="descricao"
                            name="descricao"
                            rows={4}
                            value={profileData.descricao}
                            onChange={handleProfileChange}
                          />
                        </div>

                        <Button onClick={handleSaveProfile} className="bg-primary hover:bg-primary-dark">
                          Salvar Alterações
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="fotos" className="mt-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>Minhas Fotos</CardTitle>
                      <CardDescription>Adicione até 3 fotos dos seus serviços</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-6">
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                          {uploadedImages.map((image, index) => (
                            <div key={index} className="relative aspect-video bg-gray-100 rounded-md overflow-hidden">
                              <Image
                                src={image || "/placeholder.svg"}
                                alt={`Foto ${index + 1}`}
                                fill
                                className="object-cover"
                              />
                              <Button
                                variant="destructive"
                                size="sm"
                                className="absolute top-2 right-2"
                                onClick={() => {
                                  setUploadedImages(uploadedImages.filter((_, i) => i !== index))
                                  toast({
                                    title: "Imagem removida",
                                    description: "A imagem foi removida com sucesso.",
                                  })
                                }}
                              >
                                Remover
                              </Button>
                            </div>
                          ))}

                          {uploadedImages.length < 3 && (
                            <div className="aspect-video bg-gray-100 rounded-md flex flex-col items-center justify-center border-2 border-dashed border-gray-300 p-4">
                              <Upload className="h-8 w-8 text-gray-400 mb-2" />
                              <p className="text-sm text-gray-500 text-center mb-2">Clique para adicionar uma foto</p>
                              <Button
                                onClick={handleImageUpload}
                                disabled={isUploading}
                                className="bg-primary hover:bg-primary-dark"
                              >
                                {isUploading ? "Enviando..." : "Adicionar Foto"}
                              </Button>
                            </div>
                          )}
                        </div>

                        <div className="bg-yellow-50 p-4 rounded-md">
                          <p className="text-sm text-yellow-800">
                            <strong>Nota:</strong> As fotos devem mostrar seus serviços realizados. Não são permitidas
                            imagens com conteúdo inadequado ou que violem os termos de uso.
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>

              <Card>
                <CardHeader>
                  <CardTitle>Últimas Avaliações</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="border rounded-md p-4">
                      <div className="flex justify-between mb-2">
                        <div className="flex items-center">
                          <div className="w-8 h-8 rounded-full bg-gray-200 mr-2"></div>
                          <span className="font-medium">Maria Oliveira</span>
                        </div>
                        <div className="flex">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star
                              key={star}
                              className={`h-4 w-4 ${star <= 5 ? "text-yellow-500" : "text-gray-300"}`}
                              fill={star <= 5 ? "currentColor" : "none"}
                            />
                          ))}
                        </div>
                      </div>
                      <p className="text-sm text-gray-600">
                        Serviço excelente! Muito profissional e pontual. Recomendo!
                      </p>
                      <div className="mt-2 text-sm text-gray-500">10/05/2025</div>
                      <div className="mt-2 bg-gray-50 p-2 rounded-md">
                        <p className="text-sm text-gray-600">
                          <span className="font-medium">Sua resposta:</span> Obrigado pelo feedback, Maria! Ficamos
                          felizes em atender suas expectativas.
                        </p>
                      </div>
                    </div>

                    <div className="border rounded-md p-4">
                      <div className="flex justify-between mb-2">
                        <div className="flex items-center">
                          <div className="w-8 h-8 rounded-full bg-gray-200 mr-2"></div>
                          <span className="font-medium">Carlos Santos</span>
                        </div>
                        <div className="flex">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star
                              key={star}
                              className={`h-4 w-4 ${star <= 4 ? "text-yellow-500" : "text-gray-300"}`}
                              fill={star <= 4 ? "currentColor" : "none"}
                            />
                          ))}
                        </div>
                      </div>
                      <p className="text-sm text-gray-600">Bom trabalho, mas poderia ter sido mais rápido.</p>
                      <div className="mt-2 text-sm text-gray-500">05/05/2025</div>
                      <div className="mt-2">
                        <Button variant="outline" size="sm">
                          Responder
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
