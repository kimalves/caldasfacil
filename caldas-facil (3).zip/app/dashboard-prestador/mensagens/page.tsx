"use client"

import { useState, useEffect } from "react"
import Navbar from "@/components/navbar"
import { ChatList, type ChatContact } from "@/components/chat/chat-list"
import { ChatWindow, type Message } from "@/components/chat/chat-window"
import { toast } from "@/hooks/use-toast"
import { v4 as uuidv4 } from "uuid"

// Dados simulados
const mockContacts: ChatContact[] = [
  {
    id: "1",
    name: "Ana Souza",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "Preciso de poda de árvores e manutenção do gramado",
    timestamp: new Date(Date.now() - 1000 * 60 * 60),
    unreadCount: 1,
    online: true,
    type: "client",
  },
  {
    id: "2",
    name: "Carlos Mendes",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "Quando vocês poderiam fazer o serviço?",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 5),
    unreadCount: 0,
    online: false,
    type: "client",
  },
  {
    id: "3",
    name: "Suporte Caldas Fácil",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "Como podemos ajudar?",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24),
    unreadCount: 0,
    online: true,
    type: "support",
  },
]

const mockMessages: Record<string, Message[]> = {
  "1": [
    {
      id: "m1",
      content: "Olá, gostaria de solicitar um serviço de jardinagem para minha residência",
      sender: "other",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2),
    },
    {
      id: "m2",
      content: "Olá! Claro, podemos ajudar. Que tipo de serviço de jardinagem você precisa?",
      sender: "user",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 1.5),
      status: "read",
    },
    {
      id: "m3",
      content: "Preciso de poda de árvores e manutenção do gramado",
      sender: "other",
      timestamp: new Date(Date.now() - 1000 * 60 * 60),
    },
  ],
  "2": [
    {
      id: "m1",
      content: "Bom dia! Vocês fazem serviço de jardinagem em condomínios?",
      sender: "other",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24),
    },
    {
      id: "m2",
      content: "Bom dia! Sim, atendemos condomínios. Qual seria o tamanho da área?",
      sender: "user",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 23),
      status: "read",
    },
    {
      id: "m3",
      content: "É um condomínio pequeno, com aproximadamente 500m² de área verde",
      sender: "other",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 22),
    },
    {
      id: "m4",
      content:
        "Perfeito. Podemos atender sim. Qual seria o serviço específico? Manutenção regular, paisagismo, plantio?",
      sender: "user",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 21),
      status: "read",
    },
    {
      id: "m5",
      content: "Manutenção regular mensal. Quando vocês poderiam fazer o serviço?",
      sender: "other",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 5),
    },
  ],
  "3": [
    {
      id: "m1",
      content: "Olá, estou com dúvidas sobre como funciona o sistema de planos",
      sender: "user",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3),
      status: "read",
    },
    {
      id: "m2",
      content:
        "Olá! Temos três planos disponíveis: Gratuito, Básico (R$ 29,90/mês) e Premium (R$ 299,00/ano). O plano Básico permite que você apareça no topo da página de serviços, tenha perfil verificado e possa adicionar até 5 fotos. O plano Premium inclui uma página exclusiva para sua empresa, posição em destaque na página inicial, suporte prioritário e até 10 fotos.",
      sender: "other",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3 + 1000 * 60 * 30),
    },
    {
      id: "m3",
      content: "E como funciona o plano Básico Top Avaliado?",
      sender: "user",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2),
      status: "read",
    },
    {
      id: "m4",
      content:
        "O plano Básico Top Avaliado oferece 50% de desconto no plano Básico (R$ 14,95/mês) para prestadores que mantêm uma avaliação de 4.5 estrelas ou mais. O desconto é renovado mensalmente, desde que a avaliação seja mantida. Além disso, prestadores com 4.7 estrelas ou mais aparecem em destaque sem custo adicional.",
      sender: "other",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24),
    },
  ],
}

export default function MensagensPrestador() {
  const [contacts, setContacts] = useState<ChatContact[]>(mockContacts)
  const [activeContactId, setActiveContactId] = useState<string | undefined>(mockContacts[0]?.id)
  const [messages, setMessages] = useState<Record<string, Message[]>>(mockMessages)

  const activeContact = contacts.find((contact) => contact.id === activeContactId)
  const activeMessages = activeContactId ? messages[activeContactId] || [] : []

  const handleSendMessage = (content: string) => {
    if (!activeContactId) return

    const newMessage: Message = {
      id: uuidv4(),
      content,
      sender: "user",
      timestamp: new Date(),
      status: "sent",
    }

    setMessages((prev) => ({
      ...prev,
      [activeContactId]: [...(prev[activeContactId] || []), newMessage],
    }))

    // Atualizar o último contato com a última mensagem
    setContacts((prev) =>
      prev.map((contact) =>
        contact.id === activeContactId
          ? {
              ...contact,
              lastMessage: content,
              timestamp: new Date(),
              unreadCount: 0,
            }
          : contact,
      ),
    )

    // Simular resposta após 1-3 segundos para o suporte
    if (activeContactId === "3") {
      setTimeout(
        () => {
          const responseMessages = [
            "Entendi, vou verificar e retorno em breve.",
            "Claro, podemos ajudar com isso!",
            "Vou verificar e te aviso.",
            "Obrigado pela mensagem. Nossa equipe está à disposição para ajudar.",
          ]

          const randomResponse = responseMessages[Math.floor(Math.random() * responseMessages.length)]

          const responseMessage: Message = {
            id: uuidv4(),
            content: randomResponse,
            sender: "other",
            timestamp: new Date(),
          }

          setMessages((prev) => ({
            ...prev,
            [activeContactId]: [...(prev[activeContactId] || []), responseMessage],
          }))

          // Atualizar o contato com a resposta
          setContacts((prev) =>
            prev.map((contact) =>
              contact.id === activeContactId
                ? {
                    ...contact,
                    lastMessage: randomResponse,
                    timestamp: new Date(),
                  }
                : contact,
            ),
          )
        },
        1000 + Math.random() * 2000,
      )
    }
  }

  const handleAttachFile = (file: File) => {
    if (!activeContactId) return

    // Simular upload de arquivo
    toast({
      title: "Enviando arquivo",
      description: `Enviando ${file.name}...`,
    })

    setTimeout(() => {
      const newMessage: Message = {
        id: uuidv4(),
        content: `Arquivo: ${file.name}`,
        sender: "user",
        timestamp: new Date(),
        status: "sent",
        attachment: {
          type: file.type.startsWith("image/") ? "image" : "file",
          url: file.type.startsWith("image/") ? "/placeholder.svg?height=200&width=300" : "#",
          name: file.name,
        },
      }

      setMessages((prev) => ({
        ...prev,
        [activeContactId]: [...(prev[activeContactId] || []), newMessage],
      }))

      toast({
        title: "Arquivo enviado",
        description: `${file.name} enviado com sucesso!`,
      })
    }, 1500)
  }

  // Marcar mensagens como lidas quando mudar de contato
  useEffect(() => {
    if (activeContactId) {
      setContacts((prev) =>
        prev.map((contact) =>
          contact.id === activeContactId && contact.unreadCount ? { ...contact, unreadCount: 0 } : contact,
        ),
      )
    }
  }, [activeContactId])

  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />

      <div className="flex-grow bg-background py-8">
        <div className="caldas-container">
          <div className="mb-6">
            <h1 className="text-2xl font-bold">Mensagens</h1>
            <p className="text-gray-600">Gerencie suas conversas com clientes</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-[350px_1fr] gap-6 h-[calc(100vh-250px)]">
            <ChatList
              contacts={contacts}
              activeContactId={activeContactId}
              onSelectContact={setActiveContactId}
              className="bg-white"
            />

            {activeContactId && activeContact ? (
              <ChatWindow
                title={activeContact.name}
                recipient={{
                  name: activeContact.name,
                  avatar: activeContact.avatar,
                  online: activeContact.online,
                }}
                messages={activeMessages}
                onSendMessage={handleSendMessage}
                onAttachFile={handleAttachFile}
              />
            ) : (
              <div className="flex items-center justify-center h-full bg-white rounded-lg border">
                <div className="text-center p-6">
                  <h3 className="text-lg font-medium text-gray-900">Nenhuma conversa selecionada</h3>
                  <p className="mt-2 text-sm text-gray-500">Selecione uma conversa para começar a enviar mensagens.</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </main>
  )
}
