"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter, useSearchParams } from "next/navigation"
import Navbar from "@/components/navbar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "@/hooks/use-toast"
import { updatePassword } from "@/lib/auth"

export default function RedefinirSenha() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [senha, setSenha] = useState("")
  const [confirmarSenha, setConfirmarSenha] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  // Verificar se há token na URL
  useEffect(() => {
    const hasToken = searchParams.has("token")
    if (!hasToken) {
      toast({
        title: "Link inválido",
        description: "O link de redefinição de senha é inválido ou expirou.",
        variant: "destructive",
      })
      router.push("/recuperar-senha")
    }
  }, [searchParams, router])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!senha || !confirmarSenha) {
      toast({
        title: "Erro",
        description: "Por favor, preencha todos os campos.",
        variant: "destructive",
      })
      return
    }

    if (senha !== confirmarSenha) {
      toast({
        title: "Erro",
        description: "As senhas não coincidem.",
        variant: "destructive",
      })
      return
    }

    if (senha.length < 6) {
      toast({
        title: "Erro",
        description: "A senha deve ter pelo menos 6 caracteres.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      await updatePassword(senha)
      setIsSuccess(true)
      toast({
        title: "Senha redefinida",
        description: "Sua senha foi redefinida com sucesso.",
      })

      // Redirecionar após 3 segundos
      setTimeout(() => {
        router.push("/login-cliente")
      }, 3000)
    } catch (error) {
      console.error("Erro ao redefinir senha:", error)
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao redefinir sua senha. Tente novamente.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />

      <div className="flex-grow bg-background py-12">
        <div className="caldas-container max-w-md">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl text-center">Redefinir Senha</CardTitle>
              <CardDescription className="text-center">Digite sua nova senha para continuar</CardDescription>
            </CardHeader>

            <CardContent>
              {isSuccess ? (
                <div className="text-center space-y-4">
                  <div className="bg-green-50 p-4 rounded-md">
                    <p className="text-green-700">
                      Sua senha foi redefinida com sucesso! Você será redirecionado para a página de login.
                    </p>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="senha">Nova Senha</Label>
                    <Input
                      id="senha"
                      name="senha"
                      type="password"
                      placeholder="Digite sua nova senha"
                      value={senha}
                      onChange={(e) => setSenha(e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="confirmarSenha">Confirmar Senha</Label>
                    <Input
                      id="confirmarSenha"
                      name="confirmarSenha"
                      type="password"
                      placeholder="Confirme sua nova senha"
                      value={confirmarSenha}
                      onChange={(e) => setConfirmarSenha(e.target.value)}
                      required
                    />
                  </div>

                  <Button type="submit" className="w-full bg-primary hover:bg-primary-dark" disabled={isLoading}>
                    {isLoading ? "Redefinindo..." : "Redefinir Senha"}
                  </Button>
                </form>
              )}
            </CardContent>

            <CardFooter className="flex justify-center">
              <div className="text-sm text-center">
                Lembrou sua senha?{" "}
                <Link href="/login-cliente" className="text-primary hover:underline">
                  Voltar para o login
                </Link>
              </div>
            </CardFooter>
          </Card>
        </div>
      </div>
    </main>
  )
}
