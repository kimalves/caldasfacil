"use client"

import { useState } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"
import Navbar from "@/components/navbar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Star, MapPin, Phone, Mail, Globe, MessageSquare, Calendar, Clock } from "lucide-react"
import { OrçamentoModal, type OrçamentoData } from "@/components/chat/orcamento-modal"
import { toast } from "@/hooks/use-toast"

// Dados simulados do prestador
const prestadorData = {
  id: "1",
  nome: "João Silva",
  empresa: "Silva Jardinagem",
  servico: "Paisagismo e Jardinagem",
  descricao:
    "Oferecemos serviços completos de jardinagem e paisagismo para residências e empresas. Trabalhamos com plantio, poda, manutenção e projetos personalizados. Nossa equipe é qualificada e utiliza equipamentos modernos para garantir o melhor resultado para seu jardim.",
  avaliacao: 4.8,
  totalAvaliacoes: 47,
  endereco: "Caldas, MG",
  distancia: 2.5,
  telefone: "(XX) XXXXX-XXXX",
  email: "contato@silvajardinagem.com.br",
  site: "www.silvajardinagem.com.br",
  horarioAtendimento: "Segunda a Sábado, das 8h às 18h",
  isPremium: true,
  isTopRated: true,
  fotos: [
    "/placeholder.svg?height=300&width=500",
    "/placeholder.svg?height=300&width=500",
    "/placeholder.svg?height=300&width=500",
  ],
  avaliacoes: [
    {
      id: "a1",
      cliente: "Maria Oliveira",
      avatar: "/placeholder.svg?height=40&width=40",
      avaliacao: 5,
      comentario: "Excelente serviço! Muito profissional e pontual. Recomendo!",
      data: "10/05/2025",
      resposta: "Obrigado pelo feedback, Maria! Ficamos felizes em atender suas expectativas.",
    },
    {
      id: "a2",
      cliente: "Carlos Santos",
      avatar: "/placeholder.svg?height=40&width=40",
      avaliacao: 4,
      comentario: "Bom trabalho, mas poderia ter sido mais rápido.",
      data: "05/05/2025",
    },
    {
      id: "a3",
      cliente: "Ana Pereira",
      avatar: "/placeholder.svg?height=40&width=40",
      avaliacao: 5,
      comentario: "Jardim ficou lindo! Superou minhas expectativas.",
      data: "28/04/2025",
      resposta: "Obrigado, Ana! Foi um prazer trabalhar em seu jardim.",
    },
  ],
}

export default function PrestadorPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [isOrçamentoModalOpen, setIsOrçamentoModalOpen] = useState(false)

  const handleOrçamentoSubmit = (data: OrçamentoData) => {
    setIsOrçamentoModalOpen(false)

    toast({
      title: "Orçamento solicitado",
      description: `Sua solicitação de orçamento foi enviada para ${prestadorData.empresa}.`,
    })

    // Redirecionar para o chat após 1.5 segundos
    setTimeout(() => {
      router.push("/dashboard-cliente/mensagens")
    }, 1500)
  }

  const handleChatClick = () => {
    router.push("/dashboard-cliente/mensagens")
  }

  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />

      <div className="flex-grow bg-background py-8">
        <div className="caldas-container">
          <div className="grid grid-cols-1 lg:grid-cols-[1fr_350px] gap-8">
            {/* Conteúdo Principal */}
            <div className="space-y-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row md:items-center">
                    <div className="relative w-24 h-24 rounded-full overflow-hidden mb-4 md:mb-0 md:mr-6">
                      <Image
                        src="/placeholder.svg?height=96&width=96"
                        alt={prestadorData.empresa}
                        fill
                        className="object-cover"
                      />
                    </div>

                    <div className="flex-grow">
                      <div className="flex flex-col md:flex-row md:justify-between md:items-start">
                        <div>
                          <h1 className="text-2xl font-bold">{prestadorData.empresa}</h1>
                          <p className="text-gray-600">{prestadorData.servico}</p>
                          <div className="flex items-center mt-1 mb-2">
                            <Star className="h-5 w-5 text-yellow-500 mr-1" />
                            <span className="mr-1">{prestadorData.avaliacao}</span>
                            <span className="text-gray-500">({prestadorData.totalAvaliacoes} avaliações)</span>
                          </div>
                        </div>

                        <div className="flex flex-wrap gap-2 mt-2 md:mt-0">
                          {prestadorData.isPremium && <Badge className="bg-secondary text-white">Premium</Badge>}
                          {prestadorData.isTopRated && <Badge className="bg-primary text-white">Top Avaliado</Badge>}
                        </div>
                      </div>

                      <div className="flex items-center mt-2 text-gray-600">
                        <MapPin className="h-4 w-4 mr-1" />
                        <span className="mr-4">
                          {prestadorData.endereco} ({prestadorData.distancia} km)
                        </span>
                        <Clock className="h-4 w-4 mr-1 ml-2" />
                        <span>{prestadorData.horarioAtendimento}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Tabs defaultValue="sobre">
                <TabsList className="grid grid-cols-3">
                  <TabsTrigger value="sobre">Sobre</TabsTrigger>
                  <TabsTrigger value="fotos">Fotos</TabsTrigger>
                  <TabsTrigger value="avaliacoes">Avaliações</TabsTrigger>
                </TabsList>

                <TabsContent value="sobre" className="mt-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Sobre {prestadorData.empresa}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-700 mb-6">{prestadorData.descricao}</p>

                      <h3 className="font-semibold text-lg mb-3">Serviços Oferecidos</h3>
                      <ul className="list-disc pl-5 mb-6 space-y-1 text-gray-700">
                        <li>Manutenção de jardins</li>
                        <li>Poda de árvores e arbustos</li>
                        <li>Plantio de grama e plantas</li>
                        <li>Projetos de paisagismo</li>
                        <li>Instalação de sistemas de irrigação</li>
                        <li>Controle de pragas em plantas</li>
                      </ul>

                      <h3 className="font-semibold text-lg mb-3">Área de Atendimento</h3>
                      <p className="text-gray-700 mb-6">
                        Atendemos Caldas e região em um raio de até 30km. Para locais mais distantes, entre em contato
                        para verificar disponibilidade.
                      </p>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="fotos" className="mt-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Galeria de Fotos</CardTitle>
                      <CardDescription>Veja alguns dos nossos trabalhos realizados</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {prestadorData.fotos.map((foto, index) => (
                          <div key={index} className="relative aspect-video rounded-md overflow-hidden">
                            <Image
                              src={foto || "/placeholder.svg"}
                              alt={`Trabalho ${index + 1}`}
                              fill
                              className="object-cover"
                            />
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="avaliacoes" className="mt-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Avaliações</CardTitle>
                      <CardDescription>
                        {prestadorData.totalAvaliacoes} avaliações, média {prestadorData.avaliacao} estrelas
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-6">
                        {prestadorData.avaliacoes.map((avaliacao) => (
                          <div key={avaliacao.id} className="border-b pb-6 last:border-b-0 last:pb-0">
                            <div className="flex items-start">
                              <div className="relative w-10 h-10 rounded-full overflow-hidden mr-3">
                                <Image
                                  src={avaliacao.avatar || "/placeholder.svg"}
                                  alt={avaliacao.cliente}
                                  fill
                                  className="object-cover"
                                />
                              </div>
                              <div className="flex-grow">
                                <div className="flex justify-between items-center">
                                  <h3 className="font-medium">{avaliacao.cliente}</h3>
                                  <span className="text-sm text-gray-500">{avaliacao.data}</span>
                                </div>
                                <div className="flex mt-1 mb-2">
                                  {[1, 2, 3, 4, 5].map((star) => (
                                    <Star
                                      key={star}
                                      className={`h-4 w-4 ${
                                        star <= avaliacao.avaliacao
                                          ? "text-yellow-500 fill-yellow-500"
                                          : "text-gray-300"
                                      }`}
                                    />
                                  ))}
                                </div>
                                <p className="text-gray-700">{avaliacao.comentario}</p>

                                {avaliacao.resposta && (
                                  <div className="mt-3 bg-gray-50 p-3 rounded-md">
                                    <p className="text-sm text-gray-700">
                                      <span className="font-medium">Resposta do prestador:</span> {avaliacao.resposta}
                                    </p>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Contato</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center">
                    <Phone className="h-5 w-5 text-primary mr-3" />
                    <span>{prestadorData.telefone}</span>
                  </div>
                  <div className="flex items-center">
                    <Mail className="h-5 w-5 text-primary mr-3" />
                    <span>{prestadorData.email}</span>
                  </div>
                  {prestadorData.site && (
                    <div className="flex items-center">
                      <Globe className="h-5 w-5 text-primary mr-3" />
                      <a
                        href={`https://${prestadorData.site}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-primary hover:underline"
                      >
                        {prestadorData.site}
                      </a>
                    </div>
                  )}

                  <div className="pt-4 space-y-3">
                    <Button
                      className="w-full bg-primary hover:bg-primary-dark"
                      onClick={() => setIsOrçamentoModalOpen(true)}
                    >
                      <Calendar className="h-5 w-5 mr-2" />
                      Solicitar Orçamento
                    </Button>
                    <Button className="w-full bg-secondary hover:bg-secondary-dark" onClick={handleChatClick}>
                      <MessageSquare className="h-5 w-5 mr-2" />
                      Enviar Mensagem
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Horário de Atendimento</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Segunda a Sexta</span>
                      <span>8h às 18h</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Sábado</span>
                      <span>8h às 12h</span>
                    </div>
                    <div className="flex justify-between text-gray-500">
                      <span>Domingo</span>
                      <span>Fechado</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Localização</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="relative aspect-square rounded-md overflow-hidden bg-gray-100 flex items-center justify-center">
                    <MapPin className="h-12 w-12 text-primary opacity-50" />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-sm text-gray-500">Mapa indisponível</span>
                    </div>
                  </div>
                  <p className="mt-2 text-sm text-gray-600">{prestadorData.endereco}</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      <OrçamentoModal
        isOpen={isOrçamentoModalOpen}
        onClose={() => setIsOrçamentoModalOpen(false)}
        onSubmit={handleOrçamentoSubmit}
        prestadorName={prestadorData.empresa}
      />
    </main>
  )
}
