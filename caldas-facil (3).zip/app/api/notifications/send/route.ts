import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase"
import webpush from "web-push"

// Configurar web-push
webpush.setVapidDetails(
  "mailto:contato@caldasfacil.shop",
  process.env.NEXT_PUBLIC_VAPID_KEY || "",
  process.env.PRIVATE_VAPID_KEY || "",
)

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { usuarioId, titulo, mensagem, icone, url } = body

    // Verificar se o remetente está autenticado
    const {
      data: { session },
    } = await supabase.auth.getSession()

    if (!session) {
      return NextResponse.json({ error: "Não autenticado" }, { status: 401 })
    }

    // Buscar subscriptions do usuário
    const { data: subscriptions, error } = await supabase
      .from("notificacoes_subscriptions")
      .select("subscription")
      .eq("usuario_id", usuarioId)

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 400 })
    }

    if (!subscriptions || subscriptions.length === 0) {
      return NextResponse.json({ error: "Usuário não possui subscriptions" }, { status: 404 })
    }

    // Enviar notificação para cada subscription
    const notificationPayload = {
      notification: {
        title: titulo,
        body: mensagem,
        icon: icone || "/logo.png",
        data: {
          url: url || "/",
        },
      },
    }

    const results = await Promise.all(
      subscriptions.map(async (sub) => {
        try {
          await webpush.sendNotification(sub.subscription, JSON.stringify(notificationPayload))
          return { success: true }
        } catch (error) {
          console.error("Erro ao enviar notificação:", error)

          // Se a subscription não for mais válida, remover do banco
          if (error.statusCode === 410) {
            await supabase.from("notificacoes_subscriptions").delete().eq("subscription", sub.subscription)
          }

          return { success: false, error }
        }
      }),
    )

    // Registrar notificação no banco
    await supabase.from("notificacoes").insert({
      remetente_id: session.user.id,
      destinatario_id: usuarioId,
      titulo,
      mensagem,
      url,
      lida: false,
    })

    return NextResponse.json({
      success: true,
      results,
    })
  } catch (error) {
    console.error("Erro ao enviar notificação:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
