import { NextResponse } from "next/server"
import { getServiceSupabase } from "@/lib/supabase-client"

export async function GET() {
  // Verificar se a inicialização está permitida
  if (process.env.ALLOW_INIT !== "true") {
    return NextResponse.json(
      { error: "Inicialização não permitida. Configure ALLOW_INIT=true no arquivo .env.local" },
      { status: 403 },
    )
  }

  try {
    const supabase = getServiceSupabase()

    // Verificar se o usuário admin já existe
    const { data: existingAdmin } = await supabase
      .from("usuarios")
      .select("*")
      .eq("email", process.env.ADMIN_EMAIL)
      .single()

    if (existingAdmin) {
      return NextResponse.json({ message: "Usuário admin já existe", user: existingAdmin }, { status: 200 })
    }

    // Criar usuário admin no Auth
    const { data: authUser, error: authError } = await supabase.auth.admin.createUser({
      email: process.env.ADMIN_EMAIL!,
      password: process.env.ADMIN_PASSWORD!,
      email_confirm: true,
    })

    if (authError) {
      return NextResponse.json({ error: "Erro ao criar usuário admin no Auth", details: authError }, { status: 500 })
    }

    // Criar perfil de admin
    const { data: profile, error: profileError } = await supabase
      .from("usuarios")
      .insert({
        id: authUser.user.id,
        email: process.env.ADMIN_EMAIL,
        nome: "Administrador",
        tipo: "admin",
        created_at: new Date().toISOString(),
      })
      .select()
      .single()

    if (profileError) {
      return NextResponse.json({ error: "Erro ao criar perfil admin", details: profileError }, { status: 500 })
    }

    return NextResponse.json(
      {
        message: "Sistema inicializado com sucesso",
        user: profile,
      },
      { status: 200 },
    )
  } catch (error) {
    console.error("Erro ao inicializar o sistema:", error)
    return NextResponse.json({ error: "Erro ao inicializar o sistema", details: error }, { status: 500 })
  }
}
