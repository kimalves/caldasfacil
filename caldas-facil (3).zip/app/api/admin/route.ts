import { NextResponse } from "next/server"
import { getServiceSupabase } from "@/lib/supabase"

// Middleware para verificar se o usuário é admin
async function isAdmin(request: Request) {
  try {
    const authHeader = request.headers.get("Authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return false
    }

    const token = authHeader.split(" ")[1]
    const supabase = getServiceSupabase()

    const { data, error } = await supabase.auth.getUser(token)

    if (error || !data.user) {
      return false
    }

    // Verificar se o usuário é admin
    const { data: usuario, error: userError } = await supabase
      .from("usuarios")
      .select("tipo")
      .eq("id", data.user.id)
      .single()

    if (userError || usuario.tipo !== "admin") {
      return false
    }

    return true
  } catch (error) {
    console.error("Erro ao verificar admin:", error)
    return false
  }
}

export async function GET(request: Request) {
  if (!(await isAdmin(request))) {
    return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  }

  try {
    const supabase = getServiceSupabase()

    // Obter estatísticas da plataforma
    const { data, error } = await supabase.rpc("obter_estatisticas_plataforma")

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 400 })
    }

    return NextResponse.json(data)
  } catch (error) {
    console.error("Erro ao obter estatísticas:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  if (!(await isAdmin(request))) {
    return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
  }

  try {
    const body = await request.json()
    const { action, id, data } = body
    const supabase = getServiceSupabase()

    switch (action) {
      case "verificarPrestador":
        const { error: verifyError } = await supabase
          .from("prestadores")
          .update({ verificado: data.verificado })
          .eq("id", id)

        if (verifyError) {
          return NextResponse.json({ error: verifyError.message }, { status: 400 })
        }

        return NextResponse.json({ success: true })

      case "atualizarStatusPrestador":
        const { error: prestadorError } = await supabase
          .from("prestadores")
          .update({ status: data.status })
          .eq("id", id)

        if (prestadorError) {
          return NextResponse.json({ error: prestadorError.message }, { status: 400 })
        }

        return NextResponse.json({ success: true })

      case "atualizarStatusCliente":
        const { error: clienteError } = await supabase.from("clientes").update({ status: data.status }).eq("id", id)

        if (clienteError) {
          return NextResponse.json({ error: clienteError.message }, { status: 400 })
        }

        return NextResponse.json({ success: true })

      case "resolverDenuncia":
        const { error: denunciaError } = await supabase.from("denuncias").update({ status: data.status }).eq("id", id)

        if (denunciaError) {
          return NextResponse.json({ error: denunciaError.message }, { status: 400 })
        }

        return NextResponse.json({ success: true })

      default:
        return NextResponse.json({ error: "Ação não reconhecida" }, { status: 400 })
    }
  } catch (error) {
    console.error("Erro na ação de admin:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
