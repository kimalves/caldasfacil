import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase"

export async function GET(request: Request) {
  try {
    const url = new URL(request.url)
    const lat = Number.parseFloat(url.searchParams.get("lat") || "0")
    const lng = Number.parseFloat(url.searchParams.get("lng") || "0")
    const raio = Number.parseFloat(url.searchParams.get("raio") || "10")

    if (isNaN(lat) || isNaN(lng) || isNaN(raio)) {
      return NextResponse.json({ error: "Parâmetros inválidos" }, { status: 400 })
    }

    // Buscar prestadores próximos
    const { data, error } = await supabase.rpc("prestadores_proximos", {
      lat,
      lng,
      raio,
    })

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 400 })
    }

    return NextResponse.json(data)
  } catch (error) {
    console.error("Erro ao buscar prestadores próximos:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { prestadorId, latitude, longitude, endereco } = body

    // Atualizar localização do prestador
    const { error } = await supabase
      .from("prestadores")
      .update({
        latitude,
        longitude,
        endereco,
      })
      .eq("id", prestadorId)

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 400 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Erro ao atualizar localização:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
