import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase-client"

export async function GET() {
  try {
    // Testar a conexão com o Supabase
    const { data, error } = await supabase.from("usuarios").select("count").single()

    if (error) {
      return NextResponse.json(
        {
          success: false,
          message: "Erro ao conectar com o Supabase",
          error: error.message,
        },
        { status: 500 },
      )
    }

    // Verificar tabelas existentes
    const { data: tables, error: tablesError } = await supabase
      .from("pg_tables")
      .select("tablename")
      .eq("schemaname", "public")

    if (tablesError) {
      return NextResponse.json({
        success: true,
        message: "Conexão com Supabase estabelecida, mas não foi possível listar tabelas",
        error: tablesError.message,
        data,
      })
    }

    return NextResponse.json({
      success: true,
      message: "Conexão com Supabase estabelecida com sucesso",
      data,
      tables,
    })
  } catch (error) {
    console.error("Erro ao testar conexão:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Erro ao testar conexão",
        error: String(error),
      },
      { status: 500 },
    )
  }
}
