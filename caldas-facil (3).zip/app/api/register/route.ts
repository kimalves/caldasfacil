import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { email, password, userData, tipo } = body

    // Criar usuário na autenticação do Supabase
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email,
      password,
    })

    if (authError) {
      return NextResponse.json({ error: authError.message }, { status: 400 })
    }

    if (!authData.user) {
      return NextResponse.json({ error: "Erro ao criar usuário" }, { status: 400 })
    }

    // Criar perfil do usuário
    const { error: profileError } = await supabase.from("usuarios").insert([
      {
        id: authData.user.id,
        email: authData.user.email,
        nome: userData.nome,
        tipo,
        telefone: userData.telefone,
      },
    ])

    if (profileError) {
      return NextResponse.json({ error: profileError.message }, { status: 400 })
    }

    // Se for prestador, criar registro na tabela de prestadores
    if (tipo === "prestador") {
      const { error: prestadorError } = await supabase.from("prestadores").insert([
        {
          usuario_id: authData.user.id,
          empresa: userData.empresa,
          servico: userData.servico,
          descricao: userData.descricao || "",
          documento: userData.documento,
          tipo_documento: userData.tipoDocumento,
          plano: "gratuito",
          avaliacao: 0,
          total_avaliacoes: 0,
          verificado: false,
          status: "pendente",
          is_premium: false,
          is_top_rated: false,
        },
      ])

      if (prestadorError) {
        return NextResponse.json({ error: prestadorError.message }, { status: 400 })
      }
    }

    // Se for cliente, criar registro na tabela de clientes
    if (tipo === "cliente") {
      const { error: clienteError } = await supabase.from("clientes").insert([
        {
          usuario_id: authData.user.id,
          pontos: 0,
          servicos_contratados: 0,
          status: "ativo",
        },
      ])

      if (clienteError) {
        return NextResponse.json({ error: clienteError.message }, { status: 400 })
      }
    }

    return NextResponse.json({ success: true, userId: authData.user.id })
  } catch (error) {
    console.error("Erro ao registrar usuário:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
