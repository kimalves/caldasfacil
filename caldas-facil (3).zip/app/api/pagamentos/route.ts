import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { servicoId, valor, descontoPontos, valorFinal, metodo } = body

    // Verificar se o usuário está autenticado
    const {
      data: { session },
    } = await supabase.auth.getSession()

    if (!session) {
      return NextResponse.json({ error: "Não autenticado" }, { status: 401 })
    }

    // Buscar serviço para verificar se o cliente é o usuário logado
    const { data: servico, error: servicoError } = await supabase
      .from("servicos")
      .select("cliente_id")
      .eq("id", servicoId)
      .single()

    if (servicoError) {
      return NextResponse.json({ error: servicoError.message }, { status: 400 })
    }

    // Verificar se o cliente do serviço é o usuário logado
    const { data: cliente, error: clienteError } = await supabase
      .from("clientes")
      .select("id")
      .eq("usuario_id", session.user.id)
      .single()

    if (clienteError) {
      return NextResponse.json({ error: clienteError.message }, { status: 400 })
    }

    if (servico.cliente_id !== cliente.id) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    // Criar pagamento
    const { data: pagamento, error: pagamentoError } = await supabase
      .from("pagamentos")
      .insert({
        servico_id: servicoId,
        valor,
        desconto_pontos: descontoPontos,
        valor_final: valorFinal,
        metodo,
        status: "pendente",
      })
      .select()
      .single()

    if (pagamentoError) {
      return NextResponse.json({ error: pagamentoError.message }, { status: 400 })
    }

    // Se houver desconto de pontos, atualizar pontos do cliente
    if (descontoPontos > 0) {
      const { error: pontosError } = await supabase.rpc("usar_pontos", {
        cliente_id: cliente.id,
        pontos_usar: descontoPontos,
      })

      if (pontosError) {
        return NextResponse.json({ error: pontosError.message }, { status: 400 })
      }
    }

    return NextResponse.json({
      success: true,
      pagamento,
    })
  } catch (error) {
    console.error("Erro ao processar pagamento:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json()
    const { pagamentoId, status } = body

    // Verificar se o usuário está autenticado
    const {
      data: { session },
    } = await supabase.auth.getSession()

    if (!session) {
      return NextResponse.json({ error: "Não autenticado" }, { status: 401 })
    }

    // Atualizar status do pagamento
    const { data: pagamento, error: pagamentoError } = await supabase
      .from("pagamentos")
      .update({ status })
      .eq("id", pagamentoId)
      .select()
      .single()

    if (pagamentoError) {
      return NextResponse.json({ error: pagamentoError.message }, { status: 400 })
    }

    // Se o pagamento foi concluído, adicionar pontos ao cliente
    if (status === "concluido") {
      // Buscar serviço para obter o cliente
      const { data: servico, error: servicoError } = await supabase
        .from("servicos")
        .select("cliente_id")
        .eq("id", pagamento.servico_id)
        .single()

      if (servicoError) {
        return NextResponse.json({ error: servicoError.message }, { status: 400 })
      }

      // Adicionar 5 pontos ao cliente
      const { error: pontosError } = await supabase.rpc("adicionar_pontos", {
        cliente_id: servico.cliente_id,
        pontos_adicionar: 5,
      })

      if (pontosError) {
        return NextResponse.json({ error: pontosError.message }, { status: 400 })
      }
    }

    return NextResponse.json({
      success: true,
      pagamento,
    })
  } catch (error) {
    console.error("Erro ao atualizar pagamento:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
