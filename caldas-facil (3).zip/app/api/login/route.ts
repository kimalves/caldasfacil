import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { email, password } = body

    // Autenticar usuário
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 400 })
    }

    // Buscar dados adicionais do usuário
    const { data: usuario, error: userError } = await supabase
      .from("usuarios")
      .select("*")
      .eq("id", data.user?.id)
      .single()

    if (userError) {
      return NextResponse.json({ error: userError.message }, { status: 400 })
    }

    // Buscar dados específicos baseado no tipo de usuário
    let profileData = null

    if (usuario.tipo === "prestador") {
      const { data: prestador, error: prestadorError } = await supabase
        .from("prestadores")
        .select("*")
        .eq("usuario_id", data.user?.id)
        .single()

      if (!prestadorError) {
        profileData = prestador
      }
    } else if (usuario.tipo === "cliente") {
      const { data: cliente, error: clienteError } = await supabase
        .from("clientes")
        .select("*")
        .eq("usuario_id", data.user?.id)
        .single()

      if (!clienteError) {
        profileData = cliente
      }
    }

    return NextResponse.json({
      user: data.user,
      profile: usuario,
      profileData,
      session: data.session,
    })
  } catch (error) {
    console.error("Erro ao fazer login:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
