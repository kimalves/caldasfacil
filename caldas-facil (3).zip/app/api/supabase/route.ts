import { createClient } from "@supabase/supabase-js"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
    const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

    if (!supabaseUrl || !supabaseKey) {
      return NextResponse.json(
        { error: "Variáveis de ambiente NEXT_PUBLIC_SUPABASE_URL ou NEXT_PUBLIC_SUPABASE_ANON_KEY não definidas" },
        { status: 500 },
      )
    }

    const supabase = createClient(supabaseUrl, supabaseKey)

    // Testar conexão obtendo a lista de tabelas
    const { data, error } = await supabase.rpc("list_tables")

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({
      message: "Conexão com Supabase estabelecida com sucesso",
      tables: data,
    })
  } catch (error) {
    return NextResponse.json(
      { error: `Erro ao conectar com Supabase: ${error instanceof Error ? error.message : String(error)}` },
      { status: 500 },
    )
  }
}
