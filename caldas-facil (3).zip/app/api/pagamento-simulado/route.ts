import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Simulação de processamento de pagamento
    // Em um sistema real, aqui seria a integração com um gateway de pagamento

    // Simulando um pequeno atraso para parecer mais realista
    await new Promise((resolve) => setTimeout(resolve, 1500))

    // Simulando uma taxa de sucesso de 90%
    const success = Math.random() < 0.9

    if (success) {
      return NextResponse.json({
        success: true,
        message: "Pagamento processado com sucesso!",
        transactionId: `TRANS-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        data: {
          ...data,
          processedAt: new Date().toISOString(),
        },
      })
    } else {
      return NextResponse.json(
        {
          success: false,
          message: "Falha no processamento do pagamento. Por favor, tente novamente.",
          errorCode: "PAYMENT_FAILED",
        },
        { status: 400 },
      )
    }
  } catch (error) {
    console.error("Erro ao processar pagamento:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Erro interno ao processar pagamento",
        errorCode: "INTERNAL_ERROR",
      },
      { status: 500 },
    )
  }
}
