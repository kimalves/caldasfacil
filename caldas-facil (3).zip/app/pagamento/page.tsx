"use client"

import { useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { PaymentForm } from "@/components/payment/payment-form"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Navbar from "@/components/navbar"
import { CheckCircle } from "lucide-react"

export default function PagamentoPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [paymentSuccess, setPaymentSuccess] = useState(false)
  const [transactionId, setTransactionId] = useState("")

  const plano = searchParams.get("plano") || "básico"
  const valor = searchParams.get("valor") ? Number.parseFloat(searchParams.get("valor") as string) : 49.9
  const descricao = searchParams.get("descricao") || "Assinatura do plano"

  const handlePaymentSuccess = (id: string) => {
    setTransactionId(id)
    setPaymentSuccess(true)

    // Em um sistema real, aqui você atualizaria o status do pagamento no banco de dados

    // Redirecionar após 3 segundos
    setTimeout(() => {
      router.push("/dashboard-prestador")
    }, 3000)
  }

  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />

      <div className="flex-grow bg-gray-50 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900">Finalizar Pagamento</h1>
            <p className="mt-2 text-lg text-gray-600">
              Complete seu pagamento para ativar o plano {plano.charAt(0).toUpperCase() + plano.slice(1)}
            </p>
          </div>

          <div className="max-w-3xl mx-auto">
            {paymentSuccess ? (
              <Card className="w-full max-w-md mx-auto bg-green-50 border-green-200">
                <CardHeader>
                  <div className="flex justify-center mb-4">
                    <CheckCircle className="h-16 w-16 text-green-500" />
                  </div>
                  <CardTitle className="text-center text-green-800">Pagamento Confirmado!</CardTitle>
                  <CardDescription className="text-center text-green-700">
                    Seu pagamento foi processado com sucesso.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center">
                    <p className="text-sm text-green-700 mb-2">ID da Transação: {transactionId}</p>
                    <p className="text-sm text-green-700">Você será redirecionado para o dashboard em instantes...</p>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="md:col-span-2">
                  <PaymentForm
                    amount={valor}
                    description={`${descricao} - ${plano.charAt(0).toUpperCase() + plano.slice(1)}`}
                    onSuccess={handlePaymentSuccess}
                  />
                </div>

                <div className="md:col-span-1">
                  <Card>
                    <CardHeader>
                      <CardTitle>Resumo do Pedido</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Plano</span>
                          <span className="font-medium">{plano.charAt(0).toUpperCase() + plano.slice(1)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Período</span>
                          <span className="font-medium">Mensal</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Subtotal</span>
                          <span className="font-medium">R$ {valor.toFixed(2)}</span>
                        </div>
                        <div className="border-t pt-4 flex justify-between">
                          <span className="text-gray-800 font-medium">Total</span>
                          <span className="text-primary font-bold">R$ {valor.toFixed(2)}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </main>
  )
}
