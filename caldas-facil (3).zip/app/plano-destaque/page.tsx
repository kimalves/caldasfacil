import Navbar from "@/components/navbar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Check } from "lucide-react"

export default function PlanoDestaque() {
  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />

      <div className="flex-grow bg-background py-12">
        <div className="caldas-container">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-4">Planos para Prestadores</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Escolha o plano ideal para destacar seus serviços e alcançar mais clientes
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Plano Gratuito */}
            <Card className="border-2 border-gray-200">
              <CardHeader>
                <CardTitle className="text-2xl text-center">Plano Gratuito</CardTitle>
                <CardDescription className="text-center">Perfeito para começar</CardDescription>
                <div className="text-center mt-4">
                  <span className="text-4xl font-bold">R$ 0</span>
                  <span className="text-gray-500">/mês</span>
                </div>
              </CardHeader>

              <CardContent>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                    <span>Perfil básico na plataforma</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                    <span>Listagem na página de serviços</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                    <span>1 foto de serviço</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                    <span>Receba avaliações de clientes</span>
                  </li>
                </ul>
              </CardContent>

              <CardFooter>
                <Button className="w-full bg-gray-500 hover:bg-gray-600">Começar Grátis</Button>
              </CardFooter>
            </Card>

            {/* Plano Básico */}
            <Card className="border-2 border-secondary">
              <CardHeader>
                <div className="bg-secondary text-white text-center py-1 px-4 rounded-full text-sm font-medium w-fit mx-auto mb-2">
                  Popular
                </div>
                <CardTitle className="text-2xl text-center">Plano Básico</CardTitle>
                <CardDescription className="text-center">Para prestadores que querem mais visibilidade</CardDescription>
                <div className="text-center mt-4">
                  <span className="text-4xl font-bold">R$ 29,90</span>
                  <span className="text-gray-500">/mês</span>
                </div>
              </CardHeader>

              <CardContent>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                    <span>Tudo do plano gratuito</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                    <span>Aparecer no topo da página de serviços</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                    <span>Perfil verificado</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                    <span>5 fotos de serviços</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                    <span>Chat de ajuda (horário comercial)</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                    <span>Suporte por email</span>
                  </li>
                </ul>
              </CardContent>

              <CardFooter>
                <Button className="w-full bg-secondary hover:bg-secondary-dark">Assinar Plano</Button>
              </CardFooter>
            </Card>

            {/* Plano Premium */}
            <Card className="border-2 border-primary">
              <CardHeader>
                <div className="bg-primary text-white text-center py-1 px-4 rounded-full text-sm font-medium w-fit mx-auto mb-2">
                  Recomendado
                </div>
                <CardTitle className="text-2xl text-center">Plano Premium</CardTitle>
                <CardDescription className="text-center">Para prestadores profissionais</CardDescription>
                <div className="text-center mt-4">
                  <span className="text-4xl font-bold">R$ 299,00</span>
                  <span className="text-gray-500">/ano</span>
                </div>
              </CardHeader>

              <CardContent>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                    <span>Tudo do plano básico</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                    <span>Página exclusiva para sua empresa</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                    <span>Posição em destaque na página inicial</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                    <span>Selo prestador Premium</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                    <span>10 fotos de serviços</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                    <span>Suporte prioritário</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                    <span>Mudanças na página (1 vez por semana)</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                    <span>Suporte 24 horas</span>
                  </li>
                </ul>
              </CardContent>

              <CardFooter>
                <Button className="w-full bg-primary hover:bg-primary-dark">Assinar Plano Premium</Button>
              </CardFooter>
            </Card>
          </div>

          {/* Plano Top Avaliado */}
          <div className="mt-12 bg-white p-8 rounded-lg shadow-md">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold">Plano Básico Top Avaliado</h2>
              <p className="text-gray-600 mt-2">Para prestadores com excelentes avaliações</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div>
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                    <div>
                      <span className="font-medium">50% de desconto no Plano Básico</span>
                      <p className="text-gray-600 text-sm">Pague apenas R$ 14,95/mês</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                    <div>
                      <span className="font-medium">Mantenha avaliação de 4.5 estrelas ou mais</span>
                      <p className="text-gray-600 text-sm">O desconto é renovado mensalmente se mantiver a avaliação</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                    <div>
                      <span className="font-medium">Apareça gratuitamente com 4.7 estrelas</span>
                      <p className="text-gray-600 text-sm">Prestadores com 4.7 estrelas ou mais aparecem sem custo</p>
                    </div>
                  </li>
                </ul>
              </div>

              <div className="bg-gray-50 p-6 rounded-lg">
                <div className="text-center mb-4">
                  <span className="text-3xl font-bold">R$ 14,95</span>
                  <span className="text-gray-500">/mês</span>
                </div>
                <p className="text-center text-gray-600 mb-6">
                  Para prestadores que mantêm avaliação de 4.5 estrelas ou mais
                </p>
                <Button className="w-full bg-primary hover:bg-primary-dark">Saiba Mais</Button>
              </div>
            </div>
          </div>

          {/* FAQ */}
          <div className="mt-16">
            <h2 className="text-3xl font-bold text-center mb-8">Perguntas Frequentes</h2>

            <div className="space-y-6 max-w-3xl mx-auto">
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="text-xl font-semibold mb-2">Como funciona o Plano Básico Top Avaliado?</h3>
                <p className="text-gray-600">
                  O Plano Básico Top Avaliado oferece 50% de desconto para prestadores que mantêm uma avaliação de 4.5
                  estrelas ou mais. O desconto é renovado mensalmente, desde que a avaliação seja mantida.
                </p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="text-xl font-semibold mb-2">Posso mudar de plano a qualquer momento?</h3>
                <p className="text-gray-600">
                  Sim, você pode fazer upgrade ou downgrade do seu plano a qualquer momento. Se fizer upgrade, o valor
                  proporcional do plano atual será descontado do novo plano.
                </p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="text-xl font-semibold mb-2">Como funciona a página exclusiva do Plano Premium?</h3>
                <p className="text-gray-600">
                  No Plano Premium, você terá uma página exclusiva para sua empresa, onde poderá mostrar seus serviços,
                  fotos, promoções e informações de contato. Você pode solicitar mudanças uma vez por semana através do
                  chat de ajuda.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
